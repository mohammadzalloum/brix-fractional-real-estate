import type { Config } from "tailwindcss";

export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Cairo", "ui-sans-serif", "system-ui", "Segoe UI", "Arial", "Noto Sans Arabic", "sans-serif"],
      },
      colors: {
        brand: {
          50: "#eef6ff",
          100: "#d9ecff",
          200: "#b8d9ff",
          300: "#86baff",
          400: "#5698ff",
          500: "#2f74ff",
          600: "#1f58ea",
          700: "#1b46bd",
          800: "#1b3b95",
          900: "#1b3377",
        },
        gold: {
          50: "#fff9e6",
          100: "#fff1c2",
          200: "#ffe08a",
          300: "#ffd15a",
          400: "#f6c33b",
          500: "#e7b022",
          600: "#c08a12",
          700: "#996b0f",
          800: "#775512",
          900: "#5b4313",
        },
        metal: {
          50: "#f8fafc",
          100: "#f1f5f9",
          200: "#e2e8f0",
          300: "#cbd5e1",
          400: "#94a3b8",
          500: "#64748b",
          600: "#475569",
          700: "#334155",
          800: "#1f2937",
          900: "#0f172a",
        },
      },
      boxShadow: {
        soft: "0 12px 40px rgba(2, 6, 23, 0.10)",
        glow: "0 0 0 6px rgba(47, 116, 255, 0.15)",
        glowGold: "0 0 0 6px rgba(231, 176, 34, 0.18)",
        luxe: "0 22px 60px rgba(2, 6, 23, 0.14)",
      },
      backgroundImage: {
        // Blue + gold signature background
        "brix-radial":
          "radial-gradient(1100px 520px at 82% 18%, rgba(47,116,255,.20), transparent 62%), radial-gradient(900px 520px at 12% 6%, rgba(231,176,34,.14), transparent 62%), radial-gradient(900px 520px at 12% 92%, rgba(16,185,129,.08), transparent 62%)",
        "grid":
          "linear-gradient(to right, rgba(148,163,184,.12) 1px, transparent 1px), linear-gradient(to bottom, rgba(148,163,184,.12) 1px, transparent 1px)",
        "gold-sheen":
          "linear-gradient(120deg, rgba(255,255,255,.0) 0%, rgba(255,255,255,.12) 45%, rgba(255,255,255,.0) 85%)",
      },
    },
  },
  plugins: [],
} satisfies Config;
