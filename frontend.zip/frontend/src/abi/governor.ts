export const governorAbi = [
  {
    "type": "function",
    "name": "name",
    "stateMutability": "view",
    "inputs": [],
    "outputs": [
      {
        "name": "",
        "type": "string"
      }
    ]
  },
  {
    "type": "function",
    "name": "proposalThreshold",
    "stateMutability": "view",
    "inputs": [],
    "outputs": [
      {
        "name": "",
        "type": "uint256"
      }
    ]
  },
  {
    "type": "function",
    "name": "quorum",
    "stateMutability": "view",
    "inputs": [
      {
        "name": "timepoint",
        "type": "uint256"
      }
    ],
    "outputs": [
      {
        "name": "",
        "type": "uint256"
      }
    ]
  },
  {
    "type": "function",
    "name": "state",
    "stateMutability": "view",
    "inputs": [
      {
        "name": "proposalId",
        "type": "uint256"
      }
    ],
    "outputs": [
      {
        "name": "",
        "type": "uint8"
      }
    ]
  },
  {
    "type": "function",
    "name": "proposalSnapshot",
    "stateMutability": "view",
    "inputs": [
      {
        "name": "proposalId",
        "type": "uint256"
      }
    ],
    "outputs": [
      {
        "name": "",
        "type": "uint256"
      }
    ]
  },
  {
    "type": "function",
    "name": "proposalDeadline",
    "stateMutability": "view",
    "inputs": [
      {
        "name": "proposalId",
        "type": "uint256"
      }
    ],
    "outputs": [
      {
        "name": "",
        "type": "uint256"
      }
    ]
  },
  {
    "type": "function",
    "name": "proposalVotes",
    "stateMutability": "view",
    "inputs": [
      {
        "name": "proposalId",
        "type": "uint256"
      }
    ],
    "outputs": [
      {
        "name": "againstVotes",
        "type": "uint256"
      },
      {
        "name": "forVotes",
        "type": "uint256"
      },
      {
        "name": "abstainVotes",
        "type": "uint256"
      }
    ]
  },
  {
    "type": "function",
    "name": "hasVoted",
    "stateMutability": "view",
    "inputs": [
      {
        "name": "proposalId",
        "type": "uint256"
      },
      {
        "name": "account",
        "type": "address"
      }
    ],
    "outputs": [
      {
        "name": "",
        "type": "bool"
      }
    ]
  },
  {
    "type": "function",
    "name": "castVote",
    "stateMutability": "nonpayable",
    "inputs": [
      {
        "name": "proposalId",
        "type": "uint256"
      },
      {
        "name": "support",
        "type": "uint8"
      }
    ],
    "outputs": [
      {
        "name": "",
        "type": "uint256"
      }
    ]
  },
  {
    "type": "function",
    "name": "propose",
    "stateMutability": "nonpayable",
    "inputs": [
      {
        "name": "targets",
        "type": "address[]"
      },
      {
        "name": "values",
        "type": "uint256[]"
      },
      {
        "name": "calldatas",
        "type": "bytes[]"
      },
      {
        "name": "description",
        "type": "string"
      }
    ],
    "outputs": [
      {
        "name": "",
        "type": "uint256"
      }
    ]
  },
  {
    "type": "event",
    "name": "ProposalCreated",
    "inputs": [
      {
        "indexed": true,
        "name": "proposalId",
        "type": "uint256"
      },
      {
        "indexed": true,
        "name": "proposer",
        "type": "address"
      },
      {
        "indexed": false,
        "name": "targets",
        "type": "address[]"
      },
      {
        "indexed": false,
        "name": "values",
        "type": "uint256[]"
      },
      {
        "indexed": false,
        "name": "signatures",
        "type": "string[]"
      },
      {
        "indexed": false,
        "name": "calldatas",
        "type": "bytes[]"
      },
      {
        "indexed": false,
        "name": "voteStart",
        "type": "uint256"
      },
      {
        "indexed": false,
        "name": "voteEnd",
        "type": "uint256"
      },
      {
        "indexed": false,
        "name": "description",
        "type": "string"
      }
    ]
  },
  {
    "type": "event",
    "name": "VoteCast",
    "inputs": [
      {
        "indexed": true,
        "name": "voter",
        "type": "address"
      },
      {
        "indexed": false,
        "name": "proposalId",
        "type": "uint256"
      },
      {
        "indexed": false,
        "name": "support",
        "type": "uint8"
      },
      {
        "indexed": false,
        "name": "weight",
        "type": "uint256"
      },
      {
        "indexed": false,
        "name": "reason",
        "type": "string"
      }
    ]
  }
] as const;
