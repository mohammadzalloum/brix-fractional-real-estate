export const vaultAbi = [
  {
    "type": "function",
    "name": "depositIncome",
    "stateMutability": "payable",
    "inputs": [],
    "outputs": []
  },
  {
    "type": "function",
    "name": "distributor",
    "stateMutability": "view",
    "inputs": [],
    "outputs": [
      {
        "name": "",
        "type": "address"
      }
    ]
  },
  {
    "type": "function",
    "name": "reserveBps",
    "stateMutability": "view",
    "inputs": [],
    "outputs": [
      {
        "name": "",
        "type": "uint16"
      }
    ]
  },
  {
    "type": "function",
    "name": "setReserveBps",
    "stateMutability": "nonpayable",
    "inputs": [
      {
        "name": "bps",
        "type": "uint16"
      }
    ],
    "outputs": []
  },
  {
    "type": "function",
    "name": "setDistributor",
    "stateMutability": "nonpayable",
    "inputs": [
      {
        "name": "distributor_",
        "type": "address"
      }
    ],
    "outputs": []
  },
  {
    "type": "function",
    "name": "payDividend",
    "stateMutability": "nonpayable",
    "inputs": [
      {
        "name": "to",
        "type": "address"
      },
      {
        "name": "amount",
        "type": "uint256"
      }
    ],
    "outputs": []
  },
  {
    "type": "function",
    "name": "executeGovernancePayment",
    "stateMutability": "nonpayable",
    "inputs": [
      {
        "name": "to",
        "type": "address"
      },
      {
        "name": "amount",
        "type": "uint256"
      },
      {
        "name": "memo",
        "type": "string"
      }
    ],
    "outputs": []
  },
  {
    "type": "function",
    "name": "PROPERTY_MANAGER_ROLE",
    "stateMutability": "view",
    "inputs": [],
    "outputs": [
      {
        "name": "",
        "type": "bytes32"
      }
    ]
  },
  {
    "type": "function",
    "name": "GOVERNANCE_ROLE",
    "stateMutability": "view",
    "inputs": [],
    "outputs": [
      {
        "name": "",
        "type": "bytes32"
      }
    ]
  },
  {
    "type": "function",
    "name": "DEFAULT_ADMIN_ROLE",
    "stateMutability": "view",
    "inputs": [],
    "outputs": [
      {
        "name": "",
        "type": "bytes32"
      }
    ]
  },
  {
    "type": "function",
    "name": "hasRole",
    "stateMutability": "view",
    "inputs": [
      {
        "name": "role",
        "type": "bytes32"
      },
      {
        "name": "account",
        "type": "address"
      }
    ],
    "outputs": [
      {
        "name": "",
        "type": "bool"
      }
    ]
  },
  {
    "type": "function",
    "name": "pause",
    "stateMutability": "nonpayable",
    "inputs": [],
    "outputs": []
  },
  {
    "type": "function",
    "name": "unpause",
    "stateMutability": "nonpayable",
    "inputs": [],
    "outputs": []
  }
] as const;
