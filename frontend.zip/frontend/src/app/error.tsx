"use client";

import { useEffect } from "react";
import Link from "next/link";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="container py-12">
      <div className="card p-8">
        <div className="text-2xl font-semibold">حدث خطأ غير متوقع</div>
        <p className="mt-3 text-sm text-gray-600">
          حاول تحديث الصفحة، أو تأكد من الشبكة وRPC. إن استمرت المشكلة تواصل معنا.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <button className="btn btn-primary" onClick={() => reset()}>إعادة المحاولة</button>
          <Link className="btn btn-ghost" href="/contact">الدعم</Link>
          <Link className="btn btn-ghost" href="/">الرئيسية</Link>
        </div>
      </div>
    </div>
  );
}
