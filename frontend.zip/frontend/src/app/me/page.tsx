import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth/session";

export default async function MePage() {
  const u = await getSessionUser();
  if (!u) redirect("/auth/login");

  if (u.role === "admin") redirect("/admin");
  if (u.role === "manager") redirect("/manager");

  redirect("/dashboard");
}
