"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Separator } from "@/components/ui/Separator";
import { setFlash } from "@/lib/flash";
import { emitAuthChanged } from "@/lib/auth/client";
import { useI18n } from "@/i18n/I18nProvider";

export default function LoginPage() {
  const router = useRouter();
  const { tr } = useI18n();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setBusy(true);
    try {
      const r = await fetch("/api/auth/login", {
        credentials: "include",
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) {
        setErr(j.code ?? "LOGIN_FAILED");
        return;
      }
      // Notify any listening components (Nav/UserMenu) immediately so UI updates without a full reload.
      emitAuthChanged();
      setFlash({ message: tr("تم تسجيل الدخول بنجاح ✅", "Logged in successfully ✅"), variant: "success" });
      router.push("/me");
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold">{tr("تسجيل الدخول", "Login")}</h1>
      <p className="mt-2 text-sm text-gray-600">
        {tr(
          "هذا حساب داخل الموقع (للأدوار/الإدارة). العمليات على البلوك تشين تتطلب ربط محفظتك أيضًا.",
          "This is an in-site account (roles/admin). On-chain actions still require connecting a wallet."
        )}
      </p>

      <form onSubmit={submit} className="mt-6 space-y-3">
        <div>
          <div className="text-xs text-gray-500">{tr("البريد الإلكتروني", "Email")}</div>
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-2 w-full rounded-2xl border border-gray-200 px-3 py-2 text-sm outline-none"
            placeholder="you@example.com"
            autoComplete="email"
          />
        </div>
        <div>
          <div className="text-xs text-gray-500">{tr("كلمة المرور", "Password")}</div>
          <input
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-2 w-full rounded-2xl border border-gray-200 px-3 py-2 text-sm outline-none"
            placeholder="********"
            type="password"
            autoComplete="current-password"
          />
        </div>

        {err ? (
          <div className="rounded-2xl border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-800">
            {tr("تعذر تسجيل الدخول", "Login failed")}: <b>{err}</b>
          </div>
        ) : null}

        <button className="btn btn-primary w-full" disabled={busy}>
          {busy ? tr("جارٍ الدخول…", "Signing in…") : tr("دخول", "Sign in")}
        </button>

        <Separator className="my-2" />

        <div className="text-sm text-gray-600">
          {tr("لا تملك حساباً؟", "Don't have an account?")}{" "}
          <Link className="underline" href="/auth/register">
            {tr("إنشاء حساب", "Create account")}
          </Link>
        </div>
      </form>


<div className="mt-6 surface p-5">
  <div className="text-sm font-extrabold text-metal-900">{tr("حسابات تجريبية جاهزة", "Ready demo accounts")}</div>
  <p className="mt-1 text-xs text-metal-600">{tr("استخدم هذه الحسابات للتجربة بسرعة (بيانات محلية داخل المشروع).", "Use these accounts to quickly try the portal (local project data).")}</p>

  <div className="mt-4 grid gap-3 md:grid-cols-2">
    <div className="card p-4">
      <div className="badge badge-blue w-fit">Admin</div>
      <div className="mt-3 text-xs text-metal-500">Email</div>
      <div className="font-mono text-sm text-metal-900">admin@demo.local</div>
      <div className="mt-2 text-xs text-metal-500">Password</div>
      <div className="font-mono text-sm text-metal-900">Admin12345!</div>
    </div>

    <div className="card p-4">
      <div className="badge badge-gold w-fit">Manager</div>
      <div className="mt-3 text-xs text-metal-500">Email</div>
      <div className="font-mono text-sm text-metal-900">manager@demo.local</div>
      <div className="mt-2 text-xs text-metal-500">Password</div>
      <div className="font-mono text-sm text-metal-900">Manager12345!</div>
    </div>
  </div>

  <div className="mt-4 text-xs text-metal-500">
    {tr("مسار تسجيل الدخول", "Login route")}: <span className="font-mono">/auth/login</span>
  </div>
</div>
    </div>
  );
}
