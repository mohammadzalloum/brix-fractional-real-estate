"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Separator } from "@/components/ui/Separator";
import { setFlash } from "@/lib/flash";
import { emitAuthChanged } from "@/lib/auth/client";
import { useI18n } from "@/i18n/I18nProvider";

export default function RegisterPage() {
  const router = useRouter();
  const { tr } = useI18n();
  const [fullName, setFullName] = useState("");
  const [country, setCountry] = useState("");
  const [phone, setPhone] = useState("");
  const [wallet, setWallet] = useState("");
  const [requestManager, setRequestManager] = useState(false);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [password2, setPassword2] = useState("");

  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);

    if (password !== password2) {
      setErr("PASSWORD_MISMATCH");
      return;
    }

    setBusy(true);
    try {
      const r = await fetch("/api/auth/register", {
        credentials: "include",
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, fullName, country, phone, wallet, requestManager }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) {
        setErr(j.code ?? "REGISTER_FAILED");
        return;
      }
      // Notify any listening components (Nav/UserMenu) immediately so UI updates without a full reload.
      emitAuthChanged();
      setFlash({ message: tr("تم إنشاء الحساب بنجاح ✅", "Account created ✅"), variant: "success" });
      router.push("/me");
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold">{tr("إنشاء حساب", "Create account")}</h1>
      <p className="mt-2 text-sm text-gray-600">
        {tr(
          "الحساب هنا يخص الموقع (لوحات الإدارة). ستُدخل عنوان محفظتك لأنه مطلوب للعقود (Whitelist / Claim).",
          "This is an in-site account (admin dashboards). You'll enter a wallet address because the contracts use it (Whitelist / Claim)."
        )}
      </p>

      <form onSubmit={submit} className="mt-6 space-y-3">
        
<div className="grid gap-3 md:grid-cols-2">
  <div>
    <div className="text-xs text-gray-500">{tr("الاسم الكامل (اختياري)", "Full name (optional)")}</div>
    <input
      value={fullName}
      onChange={(e) => setFullName(e.target.value)}
      className="mt-2 w-full rounded-2xl border border-gray-200 px-3 py-2 text-sm outline-none"
      placeholder={tr("محمد أحمد", "Jane Doe")}
      autoComplete="name"
    />
  </div>
  <div>
    <div className="text-xs text-gray-500">{tr("الدولة (اختياري)", "Country (optional)")}</div>
    <input
      value={country}
      onChange={(e) => setCountry(e.target.value)}
      className="mt-2 w-full rounded-2xl border border-gray-200 px-3 py-2 text-sm outline-none"
      placeholder="Jordan"
      autoComplete="country-name"
    />
  </div>
</div>

<div className="grid gap-3 md:grid-cols-2">
  <div>
    <div className="text-xs text-gray-500">{tr("رقم الهاتف (اختياري)", "Phone number (optional)")}</div>
    <input
      value={phone}
      onChange={(e) => setPhone(e.target.value)}
      className="mt-2 w-full rounded-2xl border border-gray-200 px-3 py-2 text-sm outline-none"
      placeholder="+9627XXXXXXXX"
      autoComplete="tel"
    />
  </div>
  <div>
    <div className="text-xs text-gray-500">{tr("عنوان المحفظة (مطلوب للعقود)", "Wallet address (required for contracts)")}</div>
    <input
      value={wallet}
      onChange={(e) => setWallet(e.target.value)}
      className="mt-2 w-full rounded-2xl border border-gray-200 px-3 py-2 text-sm outline-none"
      placeholder="0x..."
      autoComplete="off"
      required
    />
    <div className="mt-1 text-[11px] text-gray-500">
      {tr(
        "مثال: 0xAbc... (يُستخدم للـ Whitelist و Claim توزيعات الإيجار)",
        "Example: 0xAbc... (used for Whitelist and claiming rent distributions)"
      )}
    </div>
  </div>
</div>

<label className="flex items-start gap-2 rounded-2xl border border-gray-200 bg-white/60 p-3 text-sm text-gray-700">
  <input
    type="checkbox"
    checked={requestManager}
    onChange={(e) => setRequestManager(e.target.checked)}
    className="mt-1 h-4 w-4"
  />
  <span>
    {tr("أريد التسجيل كـ ", "I want to register as ")}
    <b>Manager</b>
    {tr(" (طلب فقط — يحتاج موافقة Admin)", " (request only — requires Admin approval)")}
  </span>
</label>

<Separator className="my-2" />

        <div>
          <div className="text-xs text-gray-500">{tr("البريد الإلكتروني", "Email")}</div>
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-2 w-full rounded-2xl border border-gray-200 px-3 py-2 text-sm outline-none"
            placeholder="you@example.com"
            autoComplete="email"
          />
        </div>
        <div>
          <div className="text-xs text-gray-500">{tr("كلمة المرور (8+ حروف)", "Password (8+ chars)")}</div>
          <input
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-2 w-full rounded-2xl border border-gray-200 px-3 py-2 text-sm outline-none"
            placeholder="********"
            type="password"
            autoComplete="new-password"
          />
        </div>
        <div>
          <div className="text-xs text-gray-500">{tr("تأكيد كلمة المرور", "Confirm password")}</div>
          <input
            value={password2}
            onChange={(e) => setPassword2(e.target.value)}
            className="mt-2 w-full rounded-2xl border border-gray-200 px-3 py-2 text-sm outline-none"
            placeholder="********"
            type="password"
            autoComplete="new-password"
          />
        </div>

        {err ? (
          <div className="rounded-2xl border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-800">
            {tr("تعذر إنشاء الحساب", "Couldn't create account")}: <b>{err}</b>
          </div>
        ) : null}

        <button className="btn btn-primary w-full" disabled={busy}>
          {busy ? tr("جارٍ الإنشاء…", "Creating…") : tr("إنشاء", "Create")}
        </button>

        <Separator className="my-2" />

        <div className="text-sm text-gray-600">
          {tr("لديك حساب؟", "Already have an account?")}{" "}
          <Link className="underline" href="/auth/login">
            {tr("تسجيل الدخول", "Login")}
          </Link>
        </div>
      </form>
    </div>
  );
}
