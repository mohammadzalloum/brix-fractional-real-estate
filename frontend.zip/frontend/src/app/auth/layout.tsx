import type { ReactNode } from "react";
export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div className="container py-12">
      <div className="mx-auto max-w-md card p-6">
        {children}
      </div>
    </div>
  );
}