export default function Loading() {
  return (
    <div className="container py-12">
      <div className="card p-6 animate-pulse">
        <div className="h-6 w-48 rounded bg-gray-200" />
        <div className="mt-4 h-4 w-full rounded bg-gray-200" />
        <div className="mt-2 h-4 w-2/3 rounded bg-gray-200" />
        <div className="mt-6 grid gap-3 md:grid-cols-3">
          <div className="h-24 rounded-2xl bg-gray-200" />
          <div className="h-24 rounded-2xl bg-gray-200" />
          <div className="h-24 rounded-2xl bg-gray-200" />
        </div>
      </div>
    </div>
  );
}
