export { default } from "../contact/page";
