import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { CtaBand } from "@/components/marketing/CtaBand";
import { RiskNote } from "@/components/marketing/RiskNote";
import { Building2, MapPinned, TrendingUp } from "lucide-react";

export const metadata = { title: "RM Communities | Brix" };

export default function CommunitiesPage() {
  return (
    <div>
      <PageHero
        eyebrow="Communities"
        title="Brix Communities (نموذج)"
        subtitle="مساحة لعرض فرص متعددة ضمن استراتيجية محددة (مثل: سكني/متعدد الوحدات) مع تحديثات تشغيلية."
        ctaHref="/marketplace"
        ctaLabel="استعرض الفرص"
        secondaryHref="/due-diligence-process"
        secondaryLabel="منهجية التدقيق"
        imageSrc="/images/property-1.jpg"
      />

      <Section title="ما الذي يميز Communities؟" subtitle="تجربة أقرب لمحفظة/برنامج—بدل صفقة واحدة فقط.">
        <div className="grid gap-4 md:grid-cols-3">
          <div className="surface p-6">
            <div className="badge badge-blue w-fit"><Building2 className="h-4 w-4" /><span className="font-semibold">تركيز قطاعي</span></div>
            <p className="mt-3 text-sm text-metal-600 leading-relaxed">مثلاً: سكني متعدد الوحدات أو مشاريع تطوير.</p>
          </div>
          <div className="surface p-6">
            <div className="badge badge-gold w-fit"><MapPinned className="h-4 w-4" /><span className="font-semibold">تنوع جغرافي</span></div>
            <p className="mt-3 text-sm text-metal-600 leading-relaxed">عرض مدن/مناطق متعددة ضمن نفس الاستراتيجية.</p>
          </div>
          <div className="surface p-6">
            <div className="badge w-fit"><TrendingUp className="h-4 w-4" /><span className="font-semibold">تحديثات أداء</span></div>
            <p className="mt-3 text-sm text-metal-600 leading-relaxed">تقارير دورية ومقترحات تشغيلية ضمن DAO.</p>
          </div>
        </div>
      </Section>

      <CtaBand
        title="حوّلها إلى منتج فعلي"
        subtitle="يمكننا ربط هذه الصفحة ببياناتك الحقيقية من العقود (Vault/Distributor) وإظهار الإيداعات والClaims."
        primaryHref="/docs"
        primaryLabel="التوثيق"
        secondaryHref="/contact-us"
        secondaryLabel="تواصل معنا"
      />

      <RiskNote />
    </div>
  );
}
