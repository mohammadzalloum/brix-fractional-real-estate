import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { RiskNote } from "@/components/marketing/RiskNote";
import Link from "next/link";

export const metadata = { title: "1031 Knowledge Center | Brix" };

const articles = [
  { slug: "what-is-1031", title: "ما هو 1031؟ (ملخص)", desc: "مقدمة سريعة لمفهوم الاستبدال ومتطلبات عامة." },
  { slug: "timeline", title: "الجدول الزمني", desc: "كيف تخطط للخطوات وتتفادى التأخير." },
  { slug: "common-mistakes", title: "أخطاء شائعة", desc: "قائمة تحقق مختصرة لتقليل المخاطر." },
];

export default function ExchangeKnowledgeCenter() {
  return (
    <div>
      <PageHero
        eyebrow="1031 • Learn"
        title="مركز معرفة 1031"
        subtitle="مواد تعليمية تساعدك على فهم المسار، المصطلحات، وخطوات التنظيم."
        ctaHref="/rm-1031-exchange"
        ctaLabel="العودة لصفحة 1031"
        secondaryHref="/knowledge-center"
        secondaryLabel="مركز المعرفة العام"
        imageSrc="/images/property-2.jpg"
      />

      <Section title="مقالات مختارة" subtitle="محتوى تجريبي—يمكنك استبداله بمحتوى قانوني/محلي لاحقًا.">
        <div className="grid gap-4 md:grid-cols-3">
          {articles.map((a) => (
            <Link key={a.slug} href={`/knowledge-center/articles/${a.slug}`} className="card p-6 hover-luxe">
              <div className="text-lg font-extrabold tracking-tight">{a.title}</div>
              <p className="mt-2 text-sm text-metal-600 leading-relaxed">{a.desc}</p>
              <div className="mt-4 text-sm font-semibold">اقرأ →</div>
            </Link>
          ))}
        </div>
      </Section>

      <RiskNote />
    </div>
  );
}
