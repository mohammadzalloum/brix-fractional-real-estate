import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { CtaBand } from "@/components/marketing/CtaBand";
import { RiskNote } from "@/components/marketing/RiskNote";
import Link from "next/link";
import { Layers, ClipboardList, Phone } from "lucide-react";

export const metadata = { title: "1031 Exchange | Brix" };

function Card({ title, desc, href }: { title: string; desc: string; href: string }) {
  return (
    <Link href={href} className="card p-6 hover-luxe">
      <div className="text-lg font-extrabold tracking-tight">{title}</div>
      <p className="mt-2 text-sm text-metal-600 leading-relaxed">{desc}</p>
      <div className="mt-4 text-sm font-semibold">اقرأ المزيد →</div>
    </Link>
  );
}

export default function ExchangePage() {
  return (
    <div>
      <PageHero
        eyebrow="1031"
        title="مسار 1031 Exchange (تعليمي)"
        subtitle="صفحة تعليمية لشرح المنهجية والمتطلبات العامة وكيفية تنظيم الصفقات ضمن نموذج شبيه بـ 1031."
        ctaHref="/rm-1031-exchange/knowledge-center"
        ctaLabel="مركز معرفة 1031"
        secondaryHref="/due-diligence-process"
        secondaryLabel="منهجية التدقيق"
        imageSrc="/images/hero.jpg"
      />

      <Section title="ماذا نوفر هنا؟" subtitle="هذه ليست استشارة ضريبية—لكنها بنية صفحات وتجربة مستخدم مماثلة من حيث التنظيم.">
        <div className="grid gap-4 md:grid-cols-3">
          <div className="surface p-6">
            <div className="badge badge-blue w-fit"><Layers className="h-4 w-4" /><span className="font-semibold">فرص مُهيكلة</span></div>
            <p className="mt-3 text-sm text-metal-600 leading-relaxed">
              عرض فرص ضمن فئات أصول مختلفة، مع صفحات تفاصيل ومواد داعمة.
            </p>
          </div>
          <div className="surface p-6">
            <div className="badge badge-gold w-fit"><ClipboardList className="h-4 w-4" /><span className="font-semibold">قائمة تحقق</span></div>
            <p className="mt-3 text-sm text-metal-600 leading-relaxed">
              خطوات واضحة للتأكد من المستندات، الجداول الزمنية، والتوافق العام.
            </p>
          </div>
          <div className="surface p-6">
            <div className="badge w-fit"><Phone className="h-4 w-4" /><span className="font-semibold">دعم/استشارة</span></div>
            <p className="mt-3 text-sm text-metal-600 leading-relaxed">
              يمكنك ربط هذه الصفحة لاحقًا بنموذج تواصل مع فريق متخصص.
            </p>
          </div>
        </div>

        <div className="mt-8 grid gap-4 md:grid-cols-2">
          <Card
            title="المفاهيم الأساسية"
            desc="تعريفات ومصطلحات وجدول زمني مقترح وخطوات عامة."
            href="/rm-1031-exchange/knowledge-center"
          />
          <Card
            title="كيف نختار الفرص"
            desc="منهجية التدقيق والتصفية قبل إدراج أي فرصة."
            href="/due-diligence-process"
          />
        </div>
      </Section>

      <CtaBand
        title="هل تريد ربط 1031 بصفقاتك؟"
        subtitle="أضف نموذج تواصل، ثم اجعل المدير يرفع فرصًا مخصصة ضمن هذه المساحة."
        primaryHref="/contact-us"
        primaryLabel="تواصل معنا"
        secondaryHref="/marketplace"
        secondaryLabel="استعرض الفرص"
      />

      <RiskNote />
    </div>
  );
}
