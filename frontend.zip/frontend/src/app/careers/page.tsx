import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { RiskNote } from "@/components/marketing/RiskNote";

export const metadata = { title: "وظائف | Brix" };

const roles = [
  { title: "Product Designer", desc: "تصميم واجهات وتجربة مستخدم عالية الجودة." },
  { title: "Full-Stack Engineer", desc: "Next.js + عقود + تكاملات بيانات." },
  { title: "Operations / Asset Mgmt", desc: "إدارة تشغيل الأصول والتقارير." },
];

export default function CareersPage() {
  return (
    <div>
      <PageHero
        eyebrow="Company"
        title="انضم إلى فريق Brix"
        subtitle="هذه صفحة قالب لعرض فرص العمل. يمكنك ربطها بنظام HR لاحقًا."
        ctaHref="/contact-us"
        ctaLabel="تواصل للتقديم"
        secondaryHref="/our-story"
        secondaryLabel="تعرف علينا"
        imageSrc="/images/property-1.jpg"
      />

      <Section title="الوظائف المفتوحة" subtitle="أمثلة—بدّلها حسب احتياجك.">
        <div className="grid gap-4 md:grid-cols-2">
          {roles.map((r) => (
            <div key={r.title} className="card p-6 hover-luxe">
              <div className="text-lg font-extrabold tracking-tight">{r.title}</div>
              <p className="mt-2 text-sm text-metal-600 leading-relaxed">{r.desc}</p>
              <div className="mt-4 text-sm font-semibold">تقديم →</div>
            </div>
          ))}
        </div>
      </Section>

      <RiskNote />
    </div>
  );
}
