import { SUPPORT_EMAIL } from "@/config/properties";

export default function ContactPage() {
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-semibold">تواصل معنا</h1>
      <p className="mt-2 text-sm text-gray-600">
        للاستفسارات التقنية/القانونية: <a className="underline" href={`mailto:${SUPPORT_EMAIL}`}>{SUPPORT_EMAIL}</a>
      </p>

      <div className="mt-6 card p-6">
        <div className="text-sm font-semibold">ملاحظات سريعة</div>
        <ul className="mt-3 space-y-2 text-sm text-gray-700">
          <li>• اذكر الشبكة (chain) وعناوين العقود عند طلب الدعم.</li>
          <li>• لا ترسل مفاتيح خاصة أو عبارات استرداد.</li>
          <li>• إذا تعذر Claim تأكد من أن هناك إيداعات في Vault وتم إشعار RentDistributor.</li>
        </ul>
      </div>
    </div>
  );
}
