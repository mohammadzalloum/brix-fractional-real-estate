export { default } from "../private-credit-investments/page";
