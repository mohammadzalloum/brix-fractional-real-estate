"use client";

import { useState } from "react";
import { useAccount } from "wagmi";
import { Separator } from "@/components/ui/Separator";
import { shortAddr } from "@/lib/utils";

export default function AccountClient({ user }: { user: { id: string; email: string; role: string; wallet: string | null } }) {
  const { address, isConnected } = useAccount();
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function link() {
    if (!address) return;
    setBusy(true);
    setMsg(null);
    try {
      const r = await fetch("/api/account/link-wallet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ wallet: address }),
      });
      const j = await r.json();
      if (!r.ok || !j.ok) {
        setMsg(j.code ?? "FAILED");
        return;
      }
      setMsg("تم ربط المحفظة بنجاح ✅ (أعد تحميل الصفحة لرؤية التحديث في كل مكان)");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-semibold">حسابي</h1>
      <p className="mt-2 text-sm text-gray-600">إدارة حساب الموقع وربط المحفظة (اختياري).</p>

      <Separator className="my-6" />

      <div className="card p-6">
        <div className="text-sm text-gray-500">Email</div>
        <div className="text-lg font-semibold">{user.email}</div>

        <div className="mt-4 text-sm text-gray-500">Role</div>
        <div className="text-lg font-semibold">{user.role}</div>

        <div className="mt-4 text-sm text-gray-500">Wallet (linked)</div>
        <div className="text-lg font-semibold">{user.wallet ? shortAddr(user.wallet) : "—"}</div>

        <Separator className="my-5" />

        <div className="text-sm font-semibold">ربط المحفظة الحالية</div>
        <p className="mt-1 text-sm text-gray-600">يتطلب أن تكون محفظتك متصلة في الموقع.</p>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          <div className="badge">{isConnected && address ? shortAddr(address) : "غير متصلة"}</div>
          <button className="btn btn-primary" onClick={link} disabled={!isConnected || busy}>
            {busy ? "جارٍ الربط…" : "Link Wallet"}
          </button>
        </div>

        {msg ? <div className="mt-4 text-sm text-gray-700">{msg}</div> : null}
      </div>
    </div>
  );
}
