import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth/session";
import AccountClient from "./account-client";

export default async function AccountPage() {
  const u = await getSessionUser();
  if (!u) redirect("/auth/login");
  return <AccountClient user={u} />;
}
