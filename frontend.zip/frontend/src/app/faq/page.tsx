import Link from "next/link";
import { Separator } from "@/components/ui/Separator";

const faqs = [
  { q: "هل هذه المنصة تجمع الإيجار تلقائياً؟", a: "لا. التحصيل يتم خارج السلسلة بواسطة مدير عقار، ثم يودِع الصافي في Vault." },
  { q: "كيف أستلم حصتي من الإيجار؟", a: "من صفحة العقار أو لوحة المستثمر اضغط Claim وسيتم الدفع من Vault عبر RentDistributor." },
  { q: "هل يمكن للحوكمة صرف أموال المستثمرين؟", a: "Vault يمنع صرف المبالغ المستحقة للمستثمرين (accrued - claimed) قبل أي مصروف." },
  { q: "لماذا لا تظهر المقترحات؟", a: "قد يكون نطاق البحث محدوداً أو RPC لا يسمح بالبحث الواسع. جرّب RPC أقوى أو قلّل fromBlock." },
];

export default function FAQPage() {
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-semibold">الأسئلة الشائعة</h1>
      <p className="mt-2 text-sm text-gray-600">إجابات سريعة قبل البدء.</p>

      <div className="mt-6 card p-6">
        <div className="space-y-5">
          {faqs.map((f, i) => (
            <div key={i}>
              <div className="text-sm font-semibold">{f.q}</div>
              <p className="mt-2 text-sm text-gray-700">{f.a}</p>
              {i !== faqs.length - 1 ? <Separator className="mt-5" /> : null}
            </div>
          ))}
        </div>
      </div>

      <div className="mt-6 flex gap-3">
        <Link href="/docs" className="btn btn-primary">التوثيق</Link>
        <Link href="/properties" className="btn btn-ghost">العقارات</Link>
      </div>
    </div>
  );
}
