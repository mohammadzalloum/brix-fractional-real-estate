"use client";

import Link from "next/link";
import { PropertyInstance } from "@/config/properties";
import { useAccount, useBalance, useReadContract } from "wagmi";
import { fractionTokenAbi } from "@/abi/fractionToken";
import { distributorAbi } from "@/abi/distributor";
import { vaultAbi } from "@/abi/vault";
import { formatToken } from "@/lib/format";
import { Separator } from "@/components/ui/Separator";
import { Wallet, ArrowUpRight } from "lucide-react";

export default function DashboardClient({ properties }: { properties: PropertyInstance[] }) {
  const { address, isConnected } = useAccount();

  return (
    <div className="container py-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold">لوحتي</h1>
          <p className="mt-2 text-sm text-gray-600">ملخص ممتلكاتك والتوزيعات القابلة للمطالبة عبر جميع العقارات.</p>
        </div>
        <div className="badge">
          <Wallet className="h-4 w-4" />
          {isConnected ? address : "غير متصل"}
        </div>
      </div>

      {!isConnected ? (
        <div className="mt-6 card p-6">
          اربط محفظتك لرؤية رصيدك وتوزيعاتك.
        </div>
      ) : (
        <div className="mt-6 grid gap-5">
          {properties.map((p) => (
            <Row key={p.id} id={p.id} token={p.token} distributor={p.distributor} vault={p.vault} title={p.title} />
          ))}
        </div>
      )}
    </div>
  );
}

function Row({ id, token, distributor, vault, title }: { id: string; token: `0x${string}`; distributor: `0x${string}`; vault: `0x${string}`; title: string; }) {
  const { address } = useAccount();

  const tokenDecimals = useReadContract({ address: token, abi: fractionTokenAbi, functionName: "decimals" });
  const tokenSymbol = useReadContract({ address: token, abi: fractionTokenAbi, functionName: "symbol" });
  const bal = useReadContract({ address: token, abi: fractionTokenAbi, functionName: "balanceOf", args: [address!] });
// ETH balance of the Vault (since this version uses an ETH Vault)
const vaultEthBal = useBalance({ address: vault, query: { refetchInterval: 10_000 } });

  const withdrawable = useReadContract({ address: distributor, abi: distributorAbi, functionName: "withdrawableDividendOf", args: [address!] });

  const decT = Number(tokenDecimals.data ?? 18);
  const decR = 18;
  const rentSymbol = "ETH";

  return (
    <div className="card p-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="text-lg font-semibold">{title}</div>
          <div className="mt-1 text-sm text-gray-600">
            حصصك: <b>{formatToken(bal.data, decT, 4)} {tokenSymbol.data ?? ""}</b>
          </div>
          <div className="mt-1 text-sm text-gray-600">
            قابل للمطالبة: <b>{formatToken(withdrawable.data, decR, 4)}</b>
          </div>
        </div>
        <Link className="btn btn-primary" href={`/properties/${id}`}>
          عرض التفاصيل <ArrowUpRight className="h-4 w-4" />
        </Link>
      </div>
      <Separator className="my-4" />
      <div className="text-xs text-gray-500">
        ملاحظة: إن كان لديك رصيد لكن القابل للمطالبة صفر، قد يكون بسبب عدم وجود إيداعات جديدة أو لأنك اشتريت بعد آخر توزيع.
      </div>
    </div>
  );
}
