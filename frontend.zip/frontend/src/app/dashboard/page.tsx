import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth/session";
import DashboardClient from "./dashboard-client";
import { getAllProperties } from "@/lib/properties";
import type { PropertyInstance } from "@/config/properties";

export default async function DashboardPage() {
  const u = await getSessionUser();
  if (!u) redirect("/auth/login");
  if (u.role === "admin") redirect("/admin");
  if (u.role === "manager") redirect("/manager");

  const properties = (await getAllProperties()) as unknown as PropertyInstance[];
  return <DashboardClient properties={properties} />;
}
