import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "http://localhost:3000";
  const routes = [
    "/", "/marketplace", "/investment-opportunities", "/investment-opportunity/demo-apartment-1", "/sponsor/demo-sponsor", "/investment-options", "/how-it-works", "/due-diligence-process",
    "/rm-1031-exchange", "/rm-1031-exchange/knowledge-center",
    "/rm-communities",
    "/knowledge-center", "/knowledge-center/faqs", "/knowledge-center/glossary", "/knowledge-center/press", "/newsworthy",
    "/knowledge-center/why-reits", "/knowledge-center/why-commercial-real-estate",
    "/private-credit-investments", "/real-estate-investing-with-your-ira",
    "/our-story", "/careers", "/contact-us",
    "/financing/jv-equity", "/apply-for-equity-capital",
    "/legal/terms", "/legal/privacy", "/legal/risk",
    "/auth/login", "/auth/register",
  ];
  return routes.map((url) => ({ url: base + url, lastModified: new Date() }));
}
