export { default } from "../properties/page";
