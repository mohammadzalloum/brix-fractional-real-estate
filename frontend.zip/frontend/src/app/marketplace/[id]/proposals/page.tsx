import { redirect } from "next/navigation";

export default function MarketplaceProposalsRedirect({ params }: { params: { id: string } }) {
  redirect(`/properties/${params.id}/proposals`);
}
