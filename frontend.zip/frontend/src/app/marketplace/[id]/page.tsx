import { redirect } from "next/navigation";

export default function MarketplacePropertyRedirect({ params }: { params: { id: string } }) {
  redirect(`/properties/${params.id}`);
}
