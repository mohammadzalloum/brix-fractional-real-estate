export { default } from "../knowledge-center/press/page";
