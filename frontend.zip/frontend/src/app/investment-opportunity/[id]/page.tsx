import { redirect } from "next/navigation";

export default function InvestmentOpportunityRedirect({ params }: { params: { id: string } }) {
  redirect(`/properties/${params.id}`);
}
