import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { RiskNote } from "@/components/marketing/RiskNote";
import { Coins, ShieldCheck, CalendarClock } from "lucide-react";

export const metadata = { title: "Private Credit | Brix" };

export default function PrivateCreditPage() {
  return (
    <div>
      <PageHero
        eyebrow="Research • Credit"
        title="Private Credit (تعليمي)"
        subtitle="صفحة توضيحية لفكرة منتجات الائتمان الخاص وكيف يمكن عرضها بشكل شفاف (شروط، آجال، مخاطر)."
        ctaHref="/investment-options"
        ctaLabel="عودة لخيارات الاستثمار"
        secondaryHref="/due-diligence-process"
        secondaryLabel="منهجية التدقيق"
        imageSrc="/images/property-3.jpg"
      />

      <Section title="كيف نعرضه بشكل مسؤول؟" subtitle="بدون مبالغة—الهدف هو الشفافية.">
        <div className="grid gap-4 md:grid-cols-3">
          <div className="surface p-6">
            <div className="badge badge-blue w-fit"><Coins className="h-4 w-4" /><span className="font-semibold">الشروط</span></div>
            <p className="mt-3 text-sm text-metal-600 leading-relaxed">معدل، رسوم، أولوية السداد، وضمانات إن وجدت.</p>
          </div>
          <div className="surface p-6">
            <div className="badge badge-gold w-fit"><CalendarClock className="h-4 w-4" /><span className="font-semibold">الأجل</span></div>
            <p className="mt-3 text-sm text-metal-600 leading-relaxed">جدول السداد، توزيع الفوائد، وخيارات الخروج.</p>
          </div>
          <div className="surface p-6">
            <div className="badge w-fit"><ShieldCheck className="h-4 w-4" /><span className="font-semibold">المخاطر</span></div>
            <p className="mt-3 text-sm text-metal-600 leading-relaxed">تعثر، سيولة، ومخاطر سوق/تشغيل.</p>
          </div>
        </div>
      </Section>

      <RiskNote />
    </div>
  );
}
