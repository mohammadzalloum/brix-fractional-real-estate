import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth/session";
import AdminClient from "./admin-client";
import { getAllProperties } from "@/lib/properties";
import type { PropertyInstance } from "@/config/properties";

export default async function AdminPage() {
  const u = await getSessionUser();
  if (!u) redirect("/auth/login");
  if (u.role !== "admin") redirect("/");
  const properties = (await getAllProperties()) as unknown as PropertyInstance[];
  return <AdminClient properties={properties} />;
}
