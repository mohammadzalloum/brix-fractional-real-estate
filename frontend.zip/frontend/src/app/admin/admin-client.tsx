"use client";

import Link from "next/link";
import { PropertyInstance } from "@/config/properties";
import { useAccount, useReadContract } from "wagmi";
import { vaultAbi } from "@/abi/vault";
import { Separator } from "@/components/ui/Separator";
import { ShieldCheck, Settings, Wrench } from "lucide-react";

export default function AdminClient({ properties }: { properties: PropertyInstance[] }) {
  const { address, isConnected } = useAccount();

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-semibold">لوحة الإدارة</h1>
      <div className="mt-3 flex flex-wrap gap-2">
        <Link href="/admin/users" className="btn btn-ghost">
          <Settings className="h-4 w-4" /> إدارة المستخدمين
        </Link>
      </div>
      <p className="mt-2 text-sm text-gray-600">
        هذه الصفحة تعرض صلاحياتك على مستوى الخزنة (Property Manager / Governance).
        التنفيذ الفعلي للمقترحات يُفضّل أن يتم عبر Timelock وبمراجعة أمنية.
      </p>

      <div className="mt-5 badge">
        <ShieldCheck className="h-4 w-4" />
        {isConnected ? address : "غير متصل"}
      </div>

      {!isConnected ? (
        <div className="mt-6 card p-6">اربط محفظتك أولاً.</div>
      ) : (
        <div className="mt-6 grid gap-5">
          {properties.map((p) => (
            <AdminRow key={p.id} id={p.id} title={p.title} vault={p.vault} />
          ))}
        </div>
      )}
    </div>
  );
}

function AdminRow({ id, title, vault }: { id: string; title: string; vault: `0x${string}` }) {
  const { address } = useAccount();

  const pmRole = useReadContract({ address: vault, abi: vaultAbi, functionName: "PROPERTY_MANAGER_ROLE" });
  const govRole = useReadContract({ address: vault, abi: vaultAbi, functionName: "GOVERNANCE_ROLE" });

  const isPM = useReadContract({
    address: vault,
    abi: vaultAbi,
    functionName: "hasRole",
    args: [pmRole.data ?? "0x0000000000000000000000000000000000000000000000000000000000000000", address!],
    query: { enabled: !!pmRole.data },
  });

  const isGov = useReadContract({
    address: vault,
    abi: vaultAbi,
    functionName: "hasRole",
    args: [govRole.data ?? "0x0000000000000000000000000000000000000000000000000000000000000000", address!],
    query: { enabled: !!govRole.data },
  });

  return (
    <div className="card p-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="text-lg font-semibold">{title}</div>
          <div className="mt-2 flex flex-wrap gap-2 text-xs">
            <span className={"badge " + (isPM.data ? "border-green-200 bg-green-50" : "")}>
              <Wrench className="h-4 w-4" /> Property Manager: {isPM.data ? "نعم" : "لا"}
            </span>
            <span className={"badge " + (isGov.data ? "border-green-200 bg-green-50" : "")}>
              <Settings className="h-4 w-4" /> Governance: {isGov.data ? "نعم" : "لا"}
            </span>
          </div>
        </div>
        <Link href={`/properties/${id}`} className="btn btn-ghost">إدارة من صفحة العقار</Link>
      </div>
      <Separator className="my-4" />
      <div className="text-xs text-gray-500">
        إذا كنت GOVERNANCE_ROLE مباشرة على الخزنة فهذا يعني أن العزل عبر Timelock غير مُفعّل أو أن الدور لم يُسحب من الأدمن بعد.
      </div>
    </div>
  );
}
