import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth/session";
import UsersClient from "./users-client";

export default async function AdminUsersPage() {
  const u = await getSessionUser();
  if (!u) redirect("/auth/login");
  if (u.role !== "admin") redirect("/");

  return <UsersClient />;
}
