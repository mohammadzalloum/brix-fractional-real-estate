"use client";

import { useEffect, useState } from "react";
import { Separator } from "@/components/ui/Separator";
import { Shield, User, Wrench, RefreshCw } from "lucide-react";

type Row = { id: string; email: string; role: "investor" | "manager" | "admin"; wallet: string | null; createdAt: string };

function RoleIcon({ role }: { role: Row["role"] }) {
  if (role === "admin") return <Shield className="h-4 w-4" />;
  if (role === "manager") return <Wrench className="h-4 w-4" />;
  return <User className="h-4 w-4" />;
}

export default function UsersClient() {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setErr(null);
    try {
      const r = await fetch("/api/admin/users", { cache: "no-store" });
      const j = await r.json();
      if (!r.ok || !j.ok) throw new Error(j.code ?? "FAILED");
      setRows(j.users ?? []);
    } catch (e: any) {
      setErr(e?.message ?? "FAILED");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function setRole(id: string, role: Row["role"]) {
    await fetch("/api/admin/users", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, role }),
    });
    await load();
  }

  return (
    <div className="container py-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold">إدارة المستخدمين</h1>
          <p className="mt-2 text-sm text-gray-600">
            إدارة أدوار الحسابات داخل الموقع (Investor/Manager/Admin). ملاحظة: صلاحيات العقود on-chain منفصلة وتحتاج Roles على العقود.
          </p>
        </div>
        <button className="btn btn-ghost" onClick={load} disabled={loading}>
          <RefreshCw className={"h-4 w-4 " + (loading ? "animate-spin" : "")} /> تحديث
        </button>
      </div>

      <Separator className="my-6" />

      {err ? (
        <div className="card p-6 border border-rose-200 bg-rose-50 text-rose-900">خطأ: {err}</div>
      ) : null}

      <div className="grid gap-3">
        {rows.map((u) => (
          <div key={u.id} className="card p-5">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <div className="text-sm text-gray-500">{new Date(u.createdAt).toLocaleString("ar")}</div>
                <div className="mt-1 text-lg font-semibold">{u.email}</div>
                <div className="mt-2 text-sm text-gray-600">
                  Wallet: <b>{u.wallet ?? "—"}</b>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="badge">
                  <RoleIcon role={u.role} /> {u.role}
                </span>
                <select
                  className="rounded-2xl border border-gray-200 bg-white px-3 py-2 text-sm"
                  value={u.role}
                  onChange={(e) => setRole(u.id, e.target.value as any)}
                >
                  <option value="investor">investor</option>
                  <option value="manager">manager</option>
                  <option value="admin">admin</option>
                </select>
              </div>
            </div>

            <div className="mt-3 text-xs text-gray-500">
              تغيير الدور هنا يغيّر وصول صفحات الموقع فقط، وليس أدوار العقود الذكية.
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
