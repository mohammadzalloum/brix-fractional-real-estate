import type { Metadata } from "next";
import "./globals.css";
import { Cairo } from "next/font/google";
import { Providers } from "./providers";
import type { ReactNode } from "react";


import { Nav } from "@/components/Nav";
import { Footer } from "@/components/Footer";
import { FlashHost } from "@/components/FlashHost";
import { getLang } from "@/i18n/server";
const cairo = Cairo({ subsets: ["arabic", "latin"], weight: ["400","600","700"], display: "swap" });

export const metadata: Metadata = {
  title: "Brix",
  description: "Brix — Fractional Real Estate DAO portal (rent distribution + on-chain governance).",
  icons: {
    icon: [{ url: "/favicon.png" }],
    apple: [{ url: "/apple-icon.png" }],
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  const lang = getLang();
  const dir = lang === "ar" ? "rtl" : "ltr";
  return (
    <html lang={lang} dir={dir} suppressHydrationWarning>
      <body className={cairo.className}>
        <Providers>
          <Nav />
          <FlashHost />
          <main>{children}</main>
          <Footer />
        </Providers>
      </body>
    </html>
  );
}