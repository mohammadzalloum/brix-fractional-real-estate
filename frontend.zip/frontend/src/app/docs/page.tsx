import Link from "next/link";
import { Separator } from "@/components/ui/Separator";

export default function DocsPage() {
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-semibold">التوثيق</h1>
      <p className="mt-2 text-sm text-gray-600">شرح مبسّط لكيفية عمل العقود والعمليات الأساسية داخل المنصة.</p>

      <div className="mt-6 grid gap-5 md:grid-cols-2">
        <div className="card p-6">
          <div className="text-lg font-semibold">كيف يعمل النظام؟</div>
          <Separator className="my-4" />
          <ol className="space-y-2 text-sm text-gray-700">
            <li>1) تملك حصصاً عبر <b>FractionToken</b> (ERC20Votes) — وهذه تمنحك قوة تصويت.</li>
            <li>2) مدير عقار يجمع الإيجار خارج السلسلة ويُودع الصافي في <b>PropertyVault</b>.</li>
            <li>3) الخزنة تُخبر <b>RentDistributor</b> بالمبلغ المخصص للمستثمرين (بعد الاحتياطي).</li>
            <li>4) كل مستثمر يضغط <b>Claim</b> لاستلام حصته من الإيجار.</li>
            <li>5) المصاريف تُمر عبر <b>Governor + Timelock</b> لضمان التأخير والشفافية.</li>
          </ol>
          <div className="mt-5 flex gap-3">
            <Link href="/legal/risk" className="btn btn-ghost">المخاطر</Link>
            <Link href="/properties" className="btn btn-primary">ابدأ من العقارات</Link>
          </div>
        </div>

        <div className="card p-6">
          <div className="text-lg font-semibold">أهم الصفحات</div>
          <Separator className="my-4" />
          <div className="grid gap-2 text-sm text-gray-700">
            <Link href="/properties" className="underline">/properties</Link>
            <Link href="/dashboard" className="underline">/dashboard</Link>
            <Link href="/admin" className="underline">/admin</Link>
            <Link href="/legal/terms" className="underline">/legal/terms</Link>
            <Link href="/legal/privacy" className="underline">/legal/privacy</Link>
            <Link href="/legal/risk" className="underline">/legal/risk</Link>
          </div>
          <div className="mt-5 text-sm text-gray-600">
            للتوسعة: فهرسة أحداث المقترحات (The Graph)، صفحة تداول ثانوية، KYC، لوحة تقارير مالية.
          </div>
        </div>
      </div>
    </div>
  );
}
