import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { RiskNote } from "@/components/marketing/RiskNote";
import { CheckCircle2, FileText, Users, MapPin, Shield } from "lucide-react";

export const metadata = { title: "منهجية التدقيق | Brix" };

const bullets = [
  { icon: <Users className="h-4 w-4" />, title: "مراجعة الراعي/المدير", desc: "الخبرة، السجل، الحوكمة، والقدرة التشغيلية." },
  { icon: <FileText className="h-4 w-4" />, title: "الخطة والافتراضات", desc: "نموذج العائد، السيناريوهات، استراتيجية الخروج، الرسوم." },
  { icon: <MapPin className="h-4 w-4" />, title: "العقار والسوق", desc: "الموقع، الطلب، المقارنات، حالة الأصل، مخاطر المنطقة." },
  { icon: <Shield className="h-4 w-4" />, title: "الوثائق والامتثال", desc: "عقود، تقارير، تأمينات، واعتبارات KYC/AML حسب الحاجة." },
];

export default function DueDiligencePage() {
  return (
    <div>
      <PageHero
        eyebrow="Research"
        title="ليس كل عقار يصلح للعرض"
        subtitle="نستخدم قائمة تحقق واضحة قبل إدراج أي فرصة: تدقيق الراعي، الخطة، العقار، والوثائق—لرفع جودة القرار."
        ctaHref="/marketplace"
        ctaLabel="استعرض الفرص"
        secondaryHref="/knowledge-center"
        secondaryLabel="مركز المعرفة"
        imageSrc="/images/property-3.jpg"
      />

      <Section title="ماذا نراجع؟" subtitle="هذه قائمة تعليمية قابلة للتخصيص وفق سياستك المحلية وقواعد الامتثال.">
        <div className="grid gap-4 md:grid-cols-2">
          {bullets.map((b) => (
            <div key={b.title} className="card p-6 hover-luxe">
              <div className="badge badge-blue w-fit">
                {b.icon}<span className="font-semibold">{b.title}</span>
              </div>
              <p className="mt-3 text-sm text-metal-600 leading-relaxed">{b.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-8 surface p-6">
          <div className="badge badge-gold w-fit"><CheckCircle2 className="h-4 w-4" /><span className="font-semibold">مخرجات التدقيق</span></div>
          <ul className="mt-3 list-disc pr-6 text-sm text-metal-600 leading-relaxed">
            <li>ملف ملخص قابل للمراجعة قبل التصويت</li>
            <li>شروط إدراج واضحة + تحديثات عند تغيير المعطيات</li>
            <li>مصفوفة مخاطر (معدل/مرتفع) تساعد المستثمرين</li>
          </ul>
        </div>
      </Section>

      <RiskNote />
    </div>
  );
}
