import PropertiesClient from "./properties-client";
import { getAllProperties } from "@/lib/properties";
import { PropertyInstance } from "@/config/properties";

export default async function PropertiesPage() {
  const properties = (await getAllProperties()) as unknown as PropertyInstance[];
  return <PropertiesClient properties={properties} />;
}
