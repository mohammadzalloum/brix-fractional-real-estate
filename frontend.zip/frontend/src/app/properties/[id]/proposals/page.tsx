import { notFound } from "next/navigation";
import { getAnyPropertyById } from "@/lib/properties";
import ProposalsClient from "./proposals-client";

export default async function ProposalsPage({ params }: { params: { id: string } }) {
  const p = await getAnyPropertyById(params.id);
  if (!p) return notFound();
  return <ProposalsClient property={p as any} />;
}
