"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useAccount, useReadContract, useWriteContract } from "wagmi";
import { PropertyInstance } from "@/config/properties";
import { governorAbi } from "@/abi/governor";
import { publicClient } from "@/lib/publicClient";
import { shortAddr } from "@/lib/utils";
import { formatToken } from "@/lib/format";
import { fractionTokenAbi } from "@/abi/fractionToken";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/Tabs";
import { Separator } from "@/components/ui/Separator";
import { Vote, ArrowRight, RefreshCw } from "lucide-react";

type Props = { property: PropertyInstance };

type ProposalRow = {
  proposalId: bigint;
  proposer: `0x${string}`;
  description: string;
  voteStart: bigint;
  voteEnd: bigint;
};

function stateLabel(s?: number) {
  // Governor.ProposalState enum (OZ)
  const map: Record<number, string> = {
    0: "Pending",
    1: "Active",
    2: "Canceled",
    3: "Defeated",
    4: "Succeeded",
    5: "Queued",
    6: "Expired",
    7: "Executed",
  };
  return s === undefined ? "—" : (map[s] ?? String(s));
}

export default function ProposalsClient({ property }: Props) {
  const { address } = useAccount();
  const [loading, setLoading] = useState(false);
  const [rows, setRows] = useState<ProposalRow[]>([]);
  const [selected, setSelected] = useState<ProposalRow | null>(null);

  const tokenDecimals = useReadContract({ address: property.token, abi: fractionTokenAbi, functionName: "decimals" });
  const tokenSymbol = useReadContract({ address: property.token, abi: fractionTokenAbi, functionName: "symbol" });

  const { writeContractAsync, isPending } = useWriteContract();

  async function load() {
  setLoading(true);
  try {
    const latest = await publicClient.getBlockNumber();
    const fromBlock = latest > 50_000n ? latest - 50_000n : 0n;

    const events = await publicClient.getContractEvents({
      address: property.governor,
      abi: governorAbi,
      eventName: "ProposalCreated",
      fromBlock,
      toBlock: "latest",
    });

    const parsed: ProposalRow[] = events.map((e: any) => ({
      proposalId: e.args.proposalId as bigint,
      proposer: e.args.proposer as `0x${string}`,
      description: (e.args.description as string) ?? "",
      voteStart: e.args.voteStart as bigint,
      voteEnd: e.args.voteEnd as bigint,
    }));

    parsed.sort((a, b) => (a.proposalId > b.proposalId ? -1 : 1));
    setRows(parsed);
    setSelected(parsed[0] ?? null);
  } catch {
    setRows([]);
    setSelected(null);
  } finally {
    setLoading(false);
  }
}

useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [property.governor]);

  const state = useReadContract({
    address: property.governor,
    abi: governorAbi,
    functionName: "state",
    args: [selected?.proposalId ?? 0n],
    query: { enabled: !!selected },
  });

  const votes = useReadContract({
    address: property.governor,
    abi: governorAbi,
    functionName: "proposalVotes",
    args: [selected?.proposalId ?? 0n],
    query: { enabled: !!selected },
  });

  const hasVoted = useReadContract({
    address: property.governor,
    abi: governorAbi,
    functionName: "hasVoted",
    args: [selected?.proposalId ?? 0n, address ?? "0x0000000000000000000000000000000000000000"],
    query: { enabled: !!selected && !!address },
  });

  const dec = Number(tokenDecimals.data ?? 18);

  async function cast(support: 0 | 1 | 2) {
    if (!selected) return;
    await writeContractAsync({
      address: property.governor,
      abi: governorAbi,
      functionName: "castVote",
      args: [selected.proposalId, support],
    });
  }

  return (
    <div className="container py-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="text-sm text-gray-500">
            <Link href={`/properties/${property.id}`} className="underline">العقار</Link> <ArrowRight className="inline h-4 w-4" /> المقترحات
          </div>
          <h1 className="mt-2 text-3xl font-semibold">مقترحات الحوكمة</h1>
          <p className="mt-2 text-sm text-gray-600">
            يتم جلب المقترحات عبر أحداث ProposalCreated من RPC (بدون فهرسة خارجية).
          </p>
        </div>
        <button className="btn btn-ghost" onClick={load} disabled={loading}>
          <RefreshCw className={"h-4 w-4 " + (loading ? "animate-spin" : "")} /> تحديث
        </button>
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-[.9fr_1.1fr]">
        <div className="card p-4">
          <div className="text-sm font-semibold">القائمة</div>
          <div className="mt-3 space-y-2">
            {rows.length === 0 ? (
              <div className="text-sm text-gray-600">لا توجد مقترحات ضمن نطاق البحث الحالي.</div>
            ) : null}
            {rows.map((r) => (
              <button
                key={String(r.proposalId)}
                className={
                  "w-full text-right rounded-2xl border px-4 py-3 transition " +
                  (selected?.proposalId === r.proposalId ? "border-gray-900 bg-gray-900 text-white" : "border-gray-200 hover:bg-gray-50")
                }
                onClick={() => setSelected(r)}
              >
                <div className="text-sm font-semibold">#{String(r.proposalId)}</div>
                <div className={"mt-1 text-xs " + (selected?.proposalId === r.proposalId ? "text-white/80" : "text-gray-500")}>
                  proposer: {shortAddr(r.proposer)}
                </div>
                <div className={"mt-2 line-clamp-2 text-sm " + (selected?.proposalId === r.proposalId ? "text-white" : "text-gray-700")}>
                  {r.description || "—"}
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center gap-2 text-lg font-semibold">
            <Vote className="h-5 w-5" /> تفاصيل المقترح
          </div>
          <Separator className="my-4" />

          {!selected ? (
            <div className="text-sm text-gray-600">اختر مقترحًا من القائمة.</div>
          ) : (
            <div className="space-y-5">
              <div className="grid gap-3 md:grid-cols-3">
                <div className="kpi">
                  <div className="text-xs text-gray-500">الحالة</div>
                  <div className="mt-1 text-xl font-semibold">{stateLabel(Number(state.data ?? 999))}</div>
                </div>
                <div className="kpi">
                  <div className="text-xs text-gray-500">For</div>
                  <div className="mt-1 text-xl font-semibold">{formatToken((votes.data as any)?.[1], dec, 2)} {tokenSymbol.data ?? ""}</div>
                </div>
                <div className="kpi">
                  <div className="text-xs text-gray-500">Against</div>
                  <div className="mt-1 text-xl font-semibold">{formatToken((votes.data as any)?.[0], dec, 2)} {tokenSymbol.data ?? ""}</div>
                </div>
              </div>

              <div className="rounded-2xl border border-gray-200 p-4">
                <div className="text-sm font-semibold">الوصف</div>
                <p className="mt-2 text-sm text-gray-700 whitespace-pre-wrap">{selected.description}</p>
              </div>

              <div className="rounded-2xl border border-gray-200 p-4">
                <div className="text-sm font-semibold">التصويت</div>
                <p className="mt-1 text-sm text-gray-600">
                  {address ? (
                    hasVoted.data ? "لقد صوتّ بالفعل على هذا المقترح." : "اختر موقفك (Against/For/Abstain)."
                  ) : (
                    "اربط محفظتك لتتمكن من التصويت."
                  )}
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button className="btn btn-ghost" disabled={!address || isPending || !!hasVoted.data} onClick={() => cast(0)}>
                    Against
                  </button>
                  <button className="btn btn-primary" disabled={!address || isPending || !!hasVoted.data} onClick={() => cast(1)}>
                    For
                  </button>
                  <button className="btn btn-ghost" disabled={!address || isPending || !!hasVoted.data} onClick={() => cast(2)}>
                    Abstain
                  </button>
                </div>
              </div>

              <div className="text-xs text-gray-500">
                ملاحظة: عرض Queue/Execute عبر Timelock يحتاج ABI إضافي وتحديد العملية (targets/values/calldata/descriptionHash). في MVP يتم التركيز على القراءة والتصويت.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
