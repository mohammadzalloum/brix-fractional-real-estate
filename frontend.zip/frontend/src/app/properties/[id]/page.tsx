import { notFound } from "next/navigation";
import { getAnyPropertyById } from "@/lib/properties";
import PropertyClient from "./property-client";

export default async function PropertyPage({ params }: { params: { id: string } }) {
  const p = await getAnyPropertyById(params.id);
  if (!p) return notFound();
  return <PropertyClient property={p as any} />;
}
