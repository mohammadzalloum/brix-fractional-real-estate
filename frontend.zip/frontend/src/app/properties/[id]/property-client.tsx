"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useAccount, useBalance, useReadContract, useWriteContract } from "wagmi";
import { parseUnits } from "viem";
import type { ReactNode } from "react";

import type { PropertyInstance } from "@/config/properties";
import { fractionTokenAbi } from "@/abi/fractionToken";
import { distributorAbi } from "@/abi/distributor";
import { vaultAbi } from "@/abi/vault";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/Tabs";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/Dialog";
import { Separator } from "@/components/ui/Separator";
import { formatToken } from "@/lib/format";
import { shortAddr } from "@/lib/utils";

import { Building2, Coins, ShieldCheck, ExternalLink, AlertTriangle } from "lucide-react";

type Props = { property: PropertyInstance };

type SiteMe =
  | { id: string; email: string; role: "investor" | "manager" | "admin"; wallet?: string | null }
  | null;

function Pill({ children }: { children: ReactNode }) {
  return <span className="badge">{children}</span>;
}

function SectionTitle({
  icon,
  title,
  subtitle,
}: {
  icon: ReactNode;
  title: string;
  subtitle?: string;
}) {
  return (
    <div className="flex items-start gap-3">
      <div className="mt-1 text-gray-900">{icon}</div>
      <div>
        <div className="text-lg font-semibold">{title}</div>
        {subtitle ? <div className="mt-1 text-sm text-gray-600">{subtitle}</div> : null}
      </div>
    </div>
  );
}

function AddressRow({
  label,
  value,
  hrefPrefix = "https://etherscan.io/address/",
}: {
  label: string;
  value?: string;
  hrefPrefix?: string;
}) {
  if (!value) return null;
  const isPlaceholder = /^0x0{39}/i.test(value);
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-gray-200 p-3">
      <div className="text-sm text-gray-600">{label}</div>
      <div className="flex items-center gap-2">
        <code className="text-xs">{shortAddr(value, 6)}</code>
        {!isPlaceholder ? (
          <a
            className="inline-flex items-center gap-1 text-xs text-blue-700 hover:underline"
            href={`${hrefPrefix}${value}`}
            target="_blank"
            rel="noreferrer"
          >
            <ExternalLink className="h-3.5 w-3.5" />
            عرض
          </a>
        ) : (
          <span className="text-xs text-gray-400">Demo</span>
        )}
      </div>
    </div>
  );
}

export default function PropertyClient({ property }: Props) {
  const { address } = useAccount();
  const { writeContractAsync, isPending } = useWriteContract();

  const [siteMe, setSiteMe] = useState<SiteMe>(null);

  // Manager/Admin actions
  const [depositAmount, setDepositAmount] = useState("0");
  const [govPayTo, setGovPayTo] = useState("0x");
  const [govPayAmount, setGovPayAmount] = useState("0");
  const [govPayMemo, setGovPayMemo] = useState("");

  // Load site session role (demo auth)
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const r = await fetch("/api/auth/me", { cache: "no-store", credentials: "include" });
        const j = await r.json();
        if (mounted) setSiteMe(j.user ?? null);
      } catch {
        if (mounted) setSiteMe(null);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  const tokenAddr = property.token as `0x${string}`;
  const vaultAddr = property.vault as `0x${string}`;
  const distAddr = property.distributor as `0x${string}`;

  const rentDec = 18;
  const rentSymbol = "ETH";

  // ===== Reads (token)
  const tokenSymbol = useReadContract({
    address: tokenAddr,
    abi: fractionTokenAbi,
    functionName: "symbol",
  });
  const tokenDecimals = useReadContract({
    address: tokenAddr,
    abi: fractionTokenAbi,
    functionName: "decimals",
  });
  const totalSupply = useReadContract({
    address: tokenAddr,
    abi: fractionTokenAbi,
    functionName: "totalSupply",
  });
  const myBal = useReadContract({
    address: tokenAddr,
    abi: fractionTokenAbi,
    functionName: "balanceOf",
    args: [address ?? "0x0000000000000000000000000000000000000000"],
    query: { enabled: !!address },
  });

  // ===== Reads (vault/distributor)
  const reserveBps = useReadContract({
    address: vaultAddr,
    abi: vaultAbi,
    functionName: "reserveBps",
  });

  const vaultEthBal = useBalance({
    address: vaultAddr,
    query: { refetchInterval: 10_000 },
  });

  const withdrawable = useReadContract({
    address: distAddr,
    abi: distributorAbi,
    functionName: "withdrawableDividendOf",
    args: [address ?? "0x0000000000000000000000000000000000000000"],
    query: { enabled: !!address },
  });

  const totalAccrued = useReadContract({
    address: distAddr,
    abi: distributorAbi,
    functionName: "totalDividendsAccrued",
  });
  const totalClaimed = useReadContract({
    address: distAddr,
    abi: distributorAbi,
    functionName: "totalDividendsClaimed",
  });
  const pendingUndistributed = useReadContract({
    address: distAddr,
    abi: distributorAbi,
    functionName: "pendingUndistributed",
  });

  // ===== Roles (optional; best-effort)
  const propertyManagerRole = useReadContract({
    address: vaultAddr,
    abi: vaultAbi,
    functionName: "PROPERTY_MANAGER_ROLE",
  });
  const governanceRole = useReadContract({
    address: vaultAddr,
    abi: vaultAbi,
    functionName: "GOVERNANCE_ROLE",
  });

  const isManagerOnChain = useReadContract({
    address: vaultAddr,
    abi: vaultAbi,
    functionName: "hasRole",
    args: [
      (propertyManagerRole.data as any) ?? ("0x" + "0".repeat(64)),
      address ?? "0x0000000000000000000000000000000000000000",
    ],
    query: { enabled: !!address && !!propertyManagerRole.data },
  });

  const isGovOnChain = useReadContract({
    address: vaultAddr,
    abi: vaultAbi,
    functionName: "hasRole",
    args: [
      (governanceRole.data as any) ?? ("0x" + "0".repeat(64)),
      address ?? "0x0000000000000000000000000000000000000000",
    ],
    query: { enabled: !!address && !!governanceRole.data },
  });

  const tokenDec = Number((tokenDecimals.data as any) ?? 18);

  const tokenSym = (tokenSymbol.data as string) || "SHARE";
  const myBalFmt = formatToken(myBal.data as any, tokenDec, 4);
  const supplyFmt = formatToken(totalSupply.data as any, tokenDec, 2);
  const withdrawFmt = formatToken(withdrawable.data as any, rentDec, 4);

  const reservePct = useMemo(() => {
    const bps = Number((reserveBps.data as any) ?? 0);
    return (bps / 100).toFixed(2);
  }, [reserveBps.data]);

  const canManagerActions = (siteMe?.role === "manager" || siteMe?.role === "admin") && !!address;
  const canAdminActions = siteMe?.role === "admin" && !!address;

  async function onClaim() {
    await writeContractAsync({
      address: distAddr,
      abi: distributorAbi,
      functionName: "claim",
      args: [],
    });
  }

  async function onDepositIncome() {
    const amt = parseUnits(depositAmount || "0", rentDec);
    await writeContractAsync({
      address: vaultAddr,
      abi: vaultAbi,
      functionName: "depositIncome",
      value: amt,
    });
  }

  async function onGovPayment() {
    const amt = parseUnits(govPayAmount || "0", rentDec);
    await writeContractAsync({
      address: vaultAddr,
      abi: vaultAbi,
      functionName: "executeGovernancePayment",
      args: [govPayTo as `0x${string}`, amt, govPayMemo],
    });
  }

  return (
    <div className="container py-8">
      <div className="grid gap-6 lg:grid-cols-[1.2fr_.8fr]">
        {/* Left: Overview */}
        <div className="space-y-6">
          <div className="card overflow-hidden">
            <div className="relative h-64">
              <Image
                src={property.coverImage}
                alt={property.title}
                fill
                className="object-cover object-top"
                priority
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/45 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4 flex flex-wrap gap-2">
                {property.tags?.slice(0, 6).map((t) => (
                  <span key={t} className="badge bg-white/90">
                    {t}
                  </span>
                ))}
              </div>
            </div>

            <div className="p-6">
              <div className="text-sm text-gray-500">{property.location}</div>
              <h1 className="mt-1 text-2xl font-semibold">{property.title}</h1>
              <p className="mt-3 text-sm text-gray-600">{property.description}</p>

              <div className="mt-5 grid gap-3 rounded-2xl bg-slate-50 p-4">
                <div className="flex items-center justify-between text-sm">
                  <div className="text-gray-600">رمز الحصص</div>
                  <div className="font-semibold">{tokenSym}</div>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <div className="text-gray-600">إجمالي الحصص</div>
                  <div className="font-semibold">{supplyFmt}</div>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <div className="text-gray-600">رصيدك</div>
                  <div className="font-semibold">{myBalFmt}</div>
                </div>
              </div>

              <div className="mt-5 flex flex-wrap gap-3">
                <Link href="/investment-opportunities" className="btn btn-secondary">
                  العودة للفرص
                </Link>
                <a
                  href={property.docsUrl || "#"}
                  className="btn btn-ghost"
                  target={property.docsUrl ? "_blank" : undefined}
                  rel={property.docsUrl ? "noreferrer" : undefined}
                >
                  المستندات
                </a>
              </div>
            </div>
          </div>

          <div className="card p-6">
            <Tabs defaultValue="overview">
              <TabsList>
                <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
                <TabsTrigger value="rent">الإيجار</TabsTrigger>
                <TabsTrigger value="contracts">العقود</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="mt-6 space-y-6">
                <SectionTitle
                  icon={<Building2 className="h-5 w-5" />}
                  title="ماذا يعني هذا الاستثمار؟"
                  subtitle="امتلاك حصص (ERC20Votes) مع توزيع إيجار قابل للمطالبة + حوكمة on-chain."
                />
                <Separator />

                <div className="grid gap-4 sm:grid-cols-3">
                  <div className="rounded-2xl border border-gray-200 p-4">
                    <div className="text-xs font-semibold text-gray-500">Reserve (bps)</div>
                    <div className="mt-2 text-xl font-semibold">{reservePct}%</div>
                    <div className="mt-2 text-xs text-gray-500">احتياطي يبقى داخل الـVault للمصاريف.</div>
                  </div>
                  <div className="rounded-2xl border border-gray-200 p-4">
                    <div className="text-xs font-semibold text-gray-500">Vault Balance</div>
                    <div className="mt-2 text-xl font-semibold">
                      {vaultEthBal.data ? `${Number(vaultEthBal.data.formatted).toFixed(4)} ${rentSymbol}` : "—"}
                    </div>
                    <div className="mt-2 text-xs text-gray-500">رصيد الـVault الحالي (ETH).</div>
                  </div>
                  <div className="rounded-2xl border border-gray-200 p-4">
                    <div className="text-xs font-semibold text-gray-500">قابل للمطالبة</div>
                    <div className="mt-2 text-xl font-semibold">{withdrawFmt} {rentSymbol}</div>
                    <div className="mt-2 text-xs text-gray-500">يمكنك المطالبة بالإيجار الآن.</div>
                  </div>
                </div>

                <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="mt-0.5 h-4 w-4" />
                    <div>
                      <div className="font-semibold">تنبيه</div>
                      <div className="mt-1 text-amber-900/90">
                        هذه واجهة Demo. تأكد من استبدال عناوين العقود في <code className="px-1">src/config/properties.ts</code>{" "}
                        بعناوينك الحقيقية قبل الاستخدام.
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="rent" className="mt-6 space-y-5">
                <SectionTitle
                  icon={<Coins className="h-5 w-5" />}
                  title="توزيعات الإيجار"
                  subtitle="عند إيداع الإيجار داخل الـVault، يصبح قابلًا للمطالبة عبر Distributor."
                />

                <div className="grid gap-3 rounded-2xl bg-slate-50 p-4 text-sm">
                  <div className="flex items-center justify-between">
                    <div className="text-gray-600">Total Accrued</div>
                    <div className="font-semibold">
                      {formatToken(totalAccrued.data as any, rentDec, 4)} {rentSymbol}
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="text-gray-600">Total Claimed</div>
                    <div className="font-semibold">
                      {formatToken(totalClaimed.data as any, rentDec, 4)} {rentSymbol}
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="text-gray-600">Pending Undistributed</div>
                    <div className="font-semibold">
                      {formatToken(pendingUndistributed.data as any, rentDec, 4)} {rentSymbol}
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <button className="btn btn-primary" disabled={!address || isPending} onClick={onClaim}>
                    مطالبة بالإيجار
                  </button>
                  {!address ? <span className="text-sm text-gray-500">اربط محفظتك أولاً.</span> : null}
                </div>

                <Separator />

                <div className="grid gap-4 lg:grid-cols-2">
                  <div className="rounded-2xl border border-gray-200 p-5">
                    <div className="flex items-center justify-between">
                      <div className="font-semibold">إيداع إيجار (Manager)</div>
                      <span className="text-xs text-gray-500">
                        On-chain: {isManagerOnChain.data ? "✅" : "—"}
                      </span>
                    </div>
                    <div className="mt-3 text-sm text-gray-600">
                      يتم إيداع صافي الإيجار إلى الـVault (ETH) ثم يتم إشعار الـDistributor للتوزيع.
                    </div>

                    <div className="mt-4 flex gap-2">
                      <input
                        value={depositAmount}
                        onChange={(e) => setDepositAmount(e.target.value)}
                        className="w-full rounded-2xl border border-gray-200 px-3 py-2 text-sm outline-none"
                        placeholder={`المبلغ (${rentSymbol})`}
                      />
                      <button
                        className="btn btn-secondary"
                        disabled={!canManagerActions || isPending}
                        onClick={onDepositIncome}
                      >
                        إيداع
                      </button>
                    </div>

                    {!canManagerActions ? (
                      <div className="mt-3 text-xs text-gray-500">
                        هذه العملية للـManager/Admin داخل الموقع + محفظة متصلة.
                      </div>
                    ) : null}
                  </div>

                  <div className="rounded-2xl border border-gray-200 p-5">
                    <div className="flex items-center justify-between">
                      <div className="font-semibold">صرف مصروف (Governance)</div>
                      <span className="text-xs text-gray-500">
                        On-chain: {isGovOnChain.data ? "✅" : "—"}
                      </span>
                    </div>
                    <div className="mt-3 text-sm text-gray-600">
                      هذه العملية يجب أن تتم عبر الحوكمة (Timelock). هنا واجهة Demo لنداء الدالة مباشرة.
                    </div>

                    <Dialog>
                      <DialogTrigger asChild>
                        <button className="btn btn-ghost mt-4" disabled={!canAdminActions}>
                          إعداد الدفع
                        </button>
                      </DialogTrigger>
                      <DialogContent>
                        <div className="text-lg font-semibold">Governance Payment</div>
                        <div className="mt-4 space-y-3">
                          <input
                            value={govPayTo}
                            onChange={(e) => setGovPayTo(e.target.value)}
                            className="w-full rounded-2xl border border-gray-200 px-3 py-2 text-sm outline-none"
                            placeholder="العنوان المستلم 0x..."
                          />
                          <input
                            value={govPayAmount}
                            onChange={(e) => setGovPayAmount(e.target.value)}
                            className="w-full rounded-2xl border border-gray-200 px-3 py-2 text-sm outline-none"
                            placeholder={`المبلغ (${rentSymbol})`}
                          />
                          <input
                            value={govPayMemo}
                            onChange={(e) => setGovPayMemo(e.target.value)}
                            className="w-full rounded-2xl border border-gray-200 px-3 py-2 text-sm outline-none"
                            placeholder="Memo (اختياري)"
                          />
                          <button className="btn btn-primary w-full" disabled={isPending} onClick={onGovPayment}>
                            تنفيذ (Demo)
                          </button>
                          {!canAdminActions ? (
                            <div className="text-xs text-gray-500">
                              متاح للأدمن داخل الموقع فقط (Demo gate).
                            </div>
                          ) : null}
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="contracts" className="mt-6 space-y-5">
                <SectionTitle
                  icon={<ShieldCheck className="h-5 w-5" />}
                  title="عناوين العقود"
                  subtitle="تأكد من تحديث العناوين عند النشر الفعلي."
                />
                <div className="grid gap-3">
                  <AddressRow label="FractionToken" value={property.token} />
                  <AddressRow label="PropertyVault" value={property.vault} />
                  <AddressRow label="RentDistributor" value={property.distributor} />
                  <AddressRow label="Governor" value={property.governor} />
                  <AddressRow label="Timelock" value={property.timelock} />
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Right: Sidebar */}
        <aside className="space-y-5">
          <div className="card p-6">
            <div className="flex items-center justify-between">
              <div className="text-sm font-semibold">حالتي</div>
              <Pill>{siteMe?.role ?? "زائر"}</Pill>
            </div>

            <div className="mt-4 space-y-2 text-sm text-gray-600">
              <div className="flex items-center justify-between">
                <span>محفظتي</span>
                <span className="font-semibold">{address ? shortAddr(address, 6) : "غير متصل"}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Email</span>
                <span className="font-semibold">{siteMe?.email ?? "—"}</span>
              </div>
            </div>

            <div className="mt-5 rounded-2xl bg-slate-50 p-4 text-sm text-slate-700">
              <div className="font-semibold">ماذا أستطيع أن أفعل؟</div>
              <ul className="mt-2 space-y-1 text-sm text-slate-700">
                <li>• المستثمر: مطالبة بالإيجار + متابعة البيانات.</li>
                <li>• المانيجر: إيداع الإيجار داخل الـVault.</li>
                <li>• الأدمن: إدارة المستخدمين + نشر عقارات + إعداد الحوكمة.</li>
              </ul>
            </div>
          </div>

          <div className="card p-6">
            <div className="text-sm font-semibold">مخاطر شائعة</div>
            <ul className="mt-3 space-y-2 text-sm text-gray-600">
              <li>• السيولة منخفضة: التوكن ليس وعدًا بإمكانية البيع الفوري.</li>
              <li>• الإيجار يعتمد على الإدارة خارج السلسلة وإيداعات المدير.</li>
              <li>• مخاطر تقنية/شبكة/عقود ذكية.</li>
            </ul>
            <Link href="/legal/risk" className="mt-4 inline-flex text-sm underline">
              تفاصيل أكثر
            </Link>
          </div>
        </aside>
      </div>
    </div>
  );
}
