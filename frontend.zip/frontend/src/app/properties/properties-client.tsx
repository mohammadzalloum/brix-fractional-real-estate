"use client";

import Link from "next/link";
import Image from "next/image";
import { useMemo, useState } from "react";
import { PropertyInstance } from "@/config/properties";
import { Search, SlidersHorizontal } from "lucide-react";

export default function PropertiesClient({ properties }: { properties: PropertyInstance[] }) {
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return properties;
    return properties.filter((p) =>
      (p.title + " " + p.location + " " + p.tags.join(" ")).toLowerCase().includes(s)
    );
  }, [q]);

  return (
    <div className="container py-8">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="text-3xl font-extrabold">العقارات</h1>
          <p className="mt-2 text-sm text-slate-600">
            استعرض الأصول المتاحة، وادخل على صفحة كل عقار لرؤية التوزيعات والحوكمة والخزنة.
          </p>
        </div>

        <div className="surface flex items-center gap-2 px-4 py-2">
          <Search className="h-4 w-4 text-slate-500" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="ابحث بالمدينة أو الاسم أو الوسوم…"
            className="w-72 max-w-full bg-transparent text-sm outline-none"
          />
          <div className="badge hidden sm:flex">
            <SlidersHorizontal className="h-4 w-4" />
            فلترة
          </div>
        </div>
      </div>

      <div className="mt-6 grid gap-5 md:grid-cols-3">
        {filtered.map((p) => (
          <Link key={p.id} href={`/properties/${p.id}`} className="group card overflow-hidden hover-luxe">
            <div className="relative h-48">
              <Image src={p.coverImage} alt={p.title} fill className="object-cover object-top" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/35 to-transparent" />
            </div>
            <div className="p-5">
              <div className="text-sm text-slate-500">{p.location}</div>
              <div className="mt-1 text-lg font-extrabold">{p.title}</div>
              <p className="mt-2 text-sm text-slate-600 line-clamp-2">{p.description}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {p.tags.map((t) => (
                  <span key={t} className="badge">{t}</span>
                ))}
              </div>
            </div>
          </Link>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="mt-8 surface p-6 text-sm text-slate-700">
          لا توجد نتائج مطابقة — جرّب كلمات مختلفة.
        </div>
      ) : null}
    </div>
  );
}
