"use client";

import { useMemo, useState } from "react";
import Link from "next/link";

type FormState = {
  // identifiers
  id?: string;

  // basics
  title: string;
  location: string;
  description: string;
  tags: string;

  // media
  coverImage: string;
  heroImage: string;
  gallery: string;

  // on-chain
  token: string;
  vault: string;
  distributor: string;
  governor: string;
  timelock: string;
  rentTokenSymbol: string;

  // docs/links
  docsUrl: string;

  // optional details
  propertyType: string;
  sponsorName: string;
  sponsorSlug: string;

  priceUsd: string;
  minInvestmentUsd: string;
  targetYieldPct: string;
  occupancyPct: string;
  yearBuilt: string;
  units: string;

  highlights: string;
  risks: string;
};

const empty: FormState = {
  id: "",
  title: "",
  location: "",
  description: "",
  tags: "",

  coverImage: "/images/property-1.jpg",
  heroImage: "/images/hero.jpg",
  gallery: "",

  token: "",
  vault: "",
  distributor: "",
  governor: "",
  timelock: "",
  rentTokenSymbol: "USDC",

  docsUrl: "",

  propertyType: "Residential",
  sponsorName: "",
  sponsorSlug: "",

  priceUsd: "",
  minInvestmentUsd: "",
  targetYieldPct: "",
  occupancyPct: "",
  yearBuilt: "",
  units: "",

  highlights: "",
  risks: "",
};

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <div className="text-xs font-semibold text-metal-600">{label}</div>
      {hint ? <div className="mt-1 text-xs text-metal-500">{hint}</div> : null}
      <div className="mt-2">{children}</div>
    </div>
  );
}

function inputClass() {
  return "w-full rounded-2xl border border-metal-200 bg-white px-3 py-2 text-sm outline-none focus:border-brand-400 focus:ring-4 focus:ring-brand-200/40";
}

function textareaClass() {
  return "w-full min-h-[110px] rounded-2xl border border-metal-200 bg-white px-3 py-2 text-sm outline-none focus:border-brand-400 focus:ring-4 focus:ring-brand-200/40";
}

function isAddress(x: string) {
  return /^0x[a-fA-F0-9]{40}$/.test(x.trim());
}

export default function PropertyCreateClient() {
  const [v, setV] = useState<FormState>(empty);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<{ id: string } | null>(null);

  const validation = useMemo(() => {
    const problems: string[] = [];
    if (!v.title.trim()) problems.push("العنوان مطلوب");
    if (!v.location.trim()) problems.push("الموقع مطلوب");
    if (!v.description.trim()) problems.push("الوصف مطلوب");
    if (!v.coverImage.trim()) problems.push("صورة الغلاف مطلوبة");
    if (!v.rentTokenSymbol.trim()) problems.push("رمز توكن الإيجار مطلوب (USDT/USDC)");

    for (const k of ["token", "vault", "distributor", "governor", "timelock"] as const) {
      if (!isAddress(v[k])) problems.push(`عنوان العقد غير صالح: ${k}`);
    }
    return problems;
  }, [v]);

  async function submit() {
    setErr(null);
    setOk(null);

    if (validation.length) {
      setErr(validation[0]);
      return;
    }

    setBusy(true);
    try {
      const res = await fetch("/api/properties", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          id: v.id?.trim() || undefined,
          title: v.title,
          location: v.location,
          description: v.description,
          tags: v.tags,
          coverImage: v.coverImage,
          heroImage: v.heroImage || undefined,
          gallery: v.gallery,

          token: v.token,
          vault: v.vault,
          distributor: v.distributor,
          governor: v.governor,
          timelock: v.timelock,
          rentTokenSymbol: v.rentTokenSymbol,

          docsUrl: v.docsUrl || undefined,

          propertyType: v.propertyType || undefined,
          sponsorName: v.sponsorName || undefined,
          sponsorSlug: v.sponsorSlug || undefined,

          priceUsd: v.priceUsd || undefined,
          minInvestmentUsd: v.minInvestmentUsd || undefined,
          targetYieldPct: v.targetYieldPct || undefined,
          occupancyPct: v.occupancyPct || undefined,
          yearBuilt: v.yearBuilt || undefined,
          units: v.units || undefined,

          highlights: v.highlights,
          risks: v.risks,
        }),
      });

      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(data?.error || "فشل إنشاء العقار");
      }

      setOk({ id: data.property.id });
      setV(empty);
    } catch (e: any) {
      setErr(e?.message || "حصل خطأ غير متوقع");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-6">
      <div className="card p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-lg font-extrabold tracking-tight">نموذج إضافة عقار</div>
            <div className="mt-1 text-sm text-metal-600">
              الحقول الأساسية + عناوين العقود مطلوبة. بقية الحقول اختيارية.
            </div>
          </div>
          <Link href="/manager" className="btn btn-ghost">
            رجوع لمركز المانيجر
          </Link>
        </div>

        {err ? (
          <div className="mt-4 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            {err}
          </div>
        ) : null}

        {ok ? (
          <div className="mt-4 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
            تم إنشاء العقار بنجاح ✅{" "}
            <Link className="underline" href={`/properties/${ok.id}`}>
              افتح صفحة العقار
            </Link>
          </div>
        ) : null}

        <div className="mt-8 grid gap-10">
          {/* Basics */}
          <section className="grid gap-5 md:grid-cols-2">
            <div className="md:col-span-2 text-xs font-extrabold tracking-[0.22em] text-metal-500">
              معلومات أساسية
            </div>

            <Field label="ID (اختياري)" hint="اتركه فارغًا وسيتم توليد ID تلقائيًا.">
              <input value={v.id} onChange={(e) => setV({ ...v, id: e.target.value })} className={inputClass()} placeholder="demo-apartment-1" />
            </Field>

            <Field label="نوع العقار" hint="مثال: Residential / Multifamily / Commercial">
              <input value={v.propertyType} onChange={(e) => setV({ ...v, propertyType: e.target.value })} className={inputClass()} />
            </Field>

            <Field label="العنوان (Title)">
              <input value={v.title} onChange={(e) => setV({ ...v, title: e.target.value })} className={inputClass()} placeholder="Brix Tower — Downtown" />
            </Field>

            <Field label="الموقع (Location)">
              <input value={v.location} onChange={(e) => setV({ ...v, location: e.target.value })} className={inputClass()} placeholder="Amman, Jordan" />
            </Field>

            <Field label="Tags" hint="افصل بفواصل: apartment, prime, stable">
              <input value={v.tags} onChange={(e) => setV({ ...v, tags: e.target.value })} className={inputClass()} placeholder="apartment, prime, stable" />
            </Field>

            <Field label="الوصف (Description)" hint="ملخص قصير يظهر في صفحة العقار.">
              <textarea value={v.description} onChange={(e) => setV({ ...v, description: e.target.value })} className={textareaClass()} />
            </Field>
          </section>

          {/* Media */}
          <section className="grid gap-5 md:grid-cols-2">
            <div className="md:col-span-2 text-xs font-extrabold tracking-[0.22em] text-metal-500">
              صور ووسائط
            </div>

            <Field label="Cover Image" hint="مسار داخل public مثل /images/property-1.jpg أو رابط خارجي.">
              <input value={v.coverImage} onChange={(e) => setV({ ...v, coverImage: e.target.value })} className={inputClass()} />
            </Field>

            <Field label="Hero Image (اختياري)" hint="صورة كبيرة للـHero داخل صفحة العقار.">
              <input value={v.heroImage} onChange={(e) => setV({ ...v, heroImage: e.target.value })} className={inputClass()} />
            </Field>

            <Field label="Gallery (اختياري)" hint="روابط/مسارات مفصولة بفواصل">
              <input value={v.gallery} onChange={(e) => setV({ ...v, gallery: e.target.value })} className={inputClass()} placeholder="/images/property-2.jpg, https://..." />
            </Field>
          </section>

          {/* On-chain */}
          <section className="grid gap-5 md:grid-cols-2">
            <div className="md:col-span-2 text-xs font-extrabold tracking-[0.22em] text-metal-500">
              عناوين العقود (On-chain)
            </div>

            <Field label="Fraction Token (ERC20Votes) address" hint="0x...">
              <input value={v.token} onChange={(e) => setV({ ...v, token: e.target.value })} className={inputClass()} placeholder="0x..." />
            </Field>

            <Field label="Property Vault address" hint="0x...">
              <input value={v.vault} onChange={(e) => setV({ ...v, vault: e.target.value })} className={inputClass()} placeholder="0x..." />
            </Field>

            <Field label="Rent Distributor address" hint="0x...">
              <input value={v.distributor} onChange={(e) => setV({ ...v, distributor: e.target.value })} className={inputClass()} placeholder="0x..." />
            </Field>

            <Field label="Governor address" hint="0x...">
              <input value={v.governor} onChange={(e) => setV({ ...v, governor: e.target.value })} className={inputClass()} placeholder="0x..." />
            </Field>

            <Field label="Timelock address" hint="0x...">
              <input value={v.timelock} onChange={(e) => setV({ ...v, timelock: e.target.value })} className={inputClass()} placeholder="0x..." />
            </Field>

            <Field label="Rent token symbol" hint="USDT / USDC (للعرض فقط)">
              <input value={v.rentTokenSymbol} onChange={(e) => setV({ ...v, rentTokenSymbol: e.target.value })} className={inputClass()} />
            </Field>
          </section>

          {/* Sponsor + links */}
          <section className="grid gap-5 md:grid-cols-2">
            <div className="md:col-span-2 text-xs font-extrabold tracking-[0.22em] text-metal-500">
              روابط + الراعي
            </div>

            <Field label="Docs URL (اختياري)" hint="رابط مستندات/ملفات للفرصة">
              <input value={v.docsUrl} onChange={(e) => setV({ ...v, docsUrl: e.target.value })} className={inputClass()} placeholder="https://..." />
            </Field>

            <Field label="Sponsor name (اختياري)">
              <input value={v.sponsorName} onChange={(e) => setV({ ...v, sponsorName: e.target.value })} className={inputClass()} placeholder="Brix Management LLC" />
            </Field>

            <Field label="Sponsor slug (اختياري)" hint="يستخدم لربط صفحة /sponsor/[slug]">
              <input value={v.sponsorSlug} onChange={(e) => setV({ ...v, sponsorSlug: e.target.value })} className={inputClass()} placeholder="brix-management" />
            </Field>
          </section>

          {/* Optional stats */}
          <section className="grid gap-5 md:grid-cols-3">
            <div className="md:col-span-3 text-xs font-extrabold tracking-[0.22em] text-metal-500">
              أرقام اختيارية (Stats)
            </div>

            <Field label="Price (USD)">
              <input value={v.priceUsd} onChange={(e) => setV({ ...v, priceUsd: e.target.value })} className={inputClass()} placeholder="2500000" />
            </Field>
            <Field label="Min Investment (USD)">
              <input value={v.minInvestmentUsd} onChange={(e) => setV({ ...v, minInvestmentUsd: e.target.value })} className={inputClass()} placeholder="100" />
            </Field>
            <Field label="Target Yield (%)">
              <input value={v.targetYieldPct} onChange={(e) => setV({ ...v, targetYieldPct: e.target.value })} className={inputClass()} placeholder="8.5" />
            </Field>
            <Field label="Occupancy (%)">
              <input value={v.occupancyPct} onChange={(e) => setV({ ...v, occupancyPct: e.target.value })} className={inputClass()} placeholder="95" />
            </Field>
            <Field label="Year Built">
              <input value={v.yearBuilt} onChange={(e) => setV({ ...v, yearBuilt: e.target.value })} className={inputClass()} placeholder="2019" />
            </Field>
            <Field label="Units">
              <input value={v.units} onChange={(e) => setV({ ...v, units: e.target.value })} className={inputClass()} placeholder="48" />
            </Field>
          </section>

          {/* Highlights / Risks */}
          <section className="grid gap-5 md:grid-cols-2">
            <div className="md:col-span-2 text-xs font-extrabold tracking-[0.22em] text-metal-500">
              Highlights & Risks (اختياري)
            </div>

            <Field label="Highlights" hint="افصل بفواصل">
              <textarea value={v.highlights} onChange={(e) => setV({ ...v, highlights: e.target.value })} className={textareaClass()} placeholder="قرب المترو, طلب عالي, ..."/>
            </Field>

            <Field label="Risks" hint="افصل بفواصل">
              <textarea value={v.risks} onChange={(e) => setV({ ...v, risks: e.target.value })} className={textareaClass()} placeholder="تقلبات سوق, مخاطر سيولة, ..."/>
            </Field>
          </section>

          <div className="flex flex-wrap items-center gap-3">
            <button onClick={submit} disabled={busy} className="btn btn-primary">
              {busy ? "جارٍ الحفظ…" : "حفظ العقار"}
            </button>
            <button
              type="button"
              onClick={() => { setV(empty); setErr(null); setOk(null); }}
              className="btn btn-ghost"
            >
              تفريغ الحقول
            </button>

            {validation.length ? (
              <div className="text-xs text-metal-500">
                ملاحظة: هناك حقول ناقصة/غير صحيحة ({validation.length})
              </div>
            ) : (
              <div className="text-xs text-metal-500">التحقق: جاهز للحفظ ✅</div>
            )}
          </div>
        </div>
      </div>

      <div className="text-xs text-metal-500">
        ملاحظة تقنية: هذه إضافة “MVP” وتُحفظ البيانات في ملف محلي. للإنتاج استخدم قاعدة بيانات (Postgres/SQLite) أو خدمة Backend.
      </div>
    </div>
  );
}
