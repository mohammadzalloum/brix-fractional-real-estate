import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth/session";
import PropertyCreateClient from "./property-create-client";

export default async function NewPropertyPage() {
  const user = await getSessionUser();
  if (!user) redirect("/auth/login");
  if (user.role !== "manager" && user.role !== "admin") redirect("/auth/login");

  return (
    <div className="container py-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">إضافة عقار جديد</h1>
          <p className="mt-2 text-sm text-metal-600 leading-relaxed">
            أدخل بيانات العقار (معلومات عامة + عناوين العقود + روابط). سيتم حفظها محليًا داخل{" "}
            <span className="font-mono">data/properties.json</span>.
          </p>
        </div>
      </div>

      <div className="mt-8">
        <PropertyCreateClient />
      </div>
    </div>
  );
}
