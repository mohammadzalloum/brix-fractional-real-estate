"use client";

import Link from "next/link";
import { useState } from "react";
import { PropertyInstance } from "@/config/properties";
import { useAccount, useBalance, useReadContract, useWriteContract } from "wagmi";
import { vaultAbi } from "@/abi/vault";
import { parseUnits } from "viem";
import { formatToken } from "@/lib/format";
import { cn } from "@/lib/utils";
import { Separator } from "@/components/ui/Separator";
import { AlertTriangle, ArrowUpRight } from "lucide-react";

export default function ManagerClient({ properties }: { properties: PropertyInstance[] }) {
  return (
    <>
      {properties.map((p) => (
        <DepositCard key={p.id} p={p} />
      ))}
    </>
  );
}

function DepositCard({ p }: { p: PropertyInstance }) {
  const { address, isConnected } = useAccount();
  const [depositAmt, setDepositAmt] = useState("0");
  const { writeContractAsync, isPending } = useWriteContract();

  // Roles
  const pmRole = useReadContract({ address: p.vault, abi: vaultAbi, functionName: "PROPERTY_MANAGER_ROLE" });

  const isPM = useReadContract({
    address: p.vault,
    abi: vaultAbi,
    functionName: "hasRole",
    args: [pmRole.data ?? "0x0000000000000000000000000000000000000000000000000000000000000000", address ?? "0x0000000000000000000000000000000000000000"],
    query: { enabled: !!pmRole.data && !!address },
  });

  // ETH balance of the Vault
  const vaultBalance = useBalance({ address: p.vault, query: { refetchInterval: 10_000 } });

  async function deposit() {
    const amt = parseUnits(depositAmt || "0", 18); // ETH has 18 decimals
    if (amt === 0n) return;

    await writeContractAsync({
      address: p.vault,
      abi: vaultAbi,
      functionName: "depositIncome",
      value: amt,
    });
  }

  return (
    <div className="card p-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="text-lg font-semibold">{p.title}</div>
          <div className="mt-1 text-sm text-gray-600">{p.location}</div>

          <div className="mt-3 flex flex-wrap gap-2 text-xs">
            <span className={cn("badge", isPM.data ? "border-green-200 bg-green-50" : "")}>
              PROPERTY_MANAGER_ROLE: {isPM.data ? "نعم" : "لا"}
            </span>
            <span className="badge">
              Vault Balance: {formatToken(vaultBalance.data?.value, 18, 4)} ETH
            </span>
          </div>
        </div>

        <Link className="btn btn-ghost" href={`/properties/${p.id}`}>
          فتح صفحة العقار <ArrowUpRight className="h-4 w-4" />
        </Link>
      </div>

      <Separator className="my-5" />

      {!isConnected ? (
        <div className="rounded-2xl border border-gray-200 bg-gray-50 p-4 text-sm text-gray-700">
          الرجاء ربط المحفظة أولاً.
        </div>
      ) : !isPM.data ? (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900 flex items-center gap-2">
          <AlertTriangle className="h-4 w-4" /> محفظتك لا تملك PROPERTY_MANAGER_ROLE على Vault لهذا العقار.
        </div>
      ) : (
        <div className="rounded-2xl border border-gray-200 p-4">
          <div className="text-sm font-semibold">إيداع صافي الإيجار (ETH)</div>
          <p className="mt-1 text-sm text-gray-600">
            سيتم توزيع الجزء غير المحجوز تلقائيًا عبر RentDistributor. (الدالة: <span className="font-mono">depositIncome()</span>)
          </p>

          <div className="mt-3 flex gap-2">
            <input
              value={depositAmt}
              onChange={(e) => setDepositAmt(e.target.value)}
              className="w-full rounded-2xl border border-gray-200 px-3 py-2 text-sm outline-none"
              placeholder="مثال: 0.25 (ETH)"
            />
            <button className="btn btn-primary" onClick={deposit} disabled={isPending}>
              Deposit
            </button>
          </div>

          <div className="mt-2 text-xs text-gray-500">
            ملاحظة: تأكد أن حساب MetaMask هو نفس حساب الـManager على الشبكة المحلية (Ganache account[1]).
          </div>
        </div>
      )}
    </div>
  );
}
