import Link from "next/link";
import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth/session";
import { getAllProperties } from "@/lib/properties";
import type { PropertyInstance } from "@/config/properties";
import { Separator } from "@/components/ui/Separator";
import ManagerClient from "./manager-client";

export default async function ManagerPage() {
  const user = await getSessionUser();
  if (!user) redirect("/auth/login");
  if (user.role !== "manager" && user.role !== "admin") redirect("/auth/login");

  const properties = (await getAllProperties()) as unknown as PropertyInstance[];

  return (
    <div className="container py-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold">مركز إيداع الإيجار</h1>
          <p className="mt-2 text-sm text-gray-600">
            هذه الصفحة مخصصة لمدير العقار/الأدمن لإيداع صافي الإيجار في Vault. ستحتاج أيضًا لمحفظة لديها PROPERTY_MANAGER_ROLE.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Link href="/manager/properties/new" className="btn btn-primary">إضافة عقار</Link>
          <div className="badge">الدور: {user.role}</div>
        </div>
      </div>

      <Separator className="my-6" />

      <div className="grid gap-6">
        <ManagerClient properties={properties} />
      </div>

      <div className="mt-8 text-xs text-gray-500">
        تذكير: العقود لا تجمع الإيجار تلقائياً — التحصيل يتم خارج السلسلة ثم إيداع الصافي داخل الخزنة.
      </div>
    </div>
  );
}
