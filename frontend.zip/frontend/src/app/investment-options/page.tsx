import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { CtaBand } from "@/components/marketing/CtaBand";
import { RiskNote } from "@/components/marketing/RiskNote";
import Link from "next/link";
import { Building2, ShieldCheck, Coins, LineChart, Layers, Landmark } from "lucide-react";
import type { ReactNode } from "react";

function OptionCard({
  icon,
  title,
  desc,
  href,
}: {
  icon: ReactNode;
  title: string;
  desc: string;
  href: string;
}) {
  return (
    <Link href={href} className="card p-6 hover-luxe">
      <div className="badge badge-blue w-fit">{icon}<span className="font-semibold">{title}</span></div>
      <p className="mt-3 text-sm text-metal-600 leading-relaxed">{desc}</p>
      <div className="mt-4 text-sm font-semibold">استكشف →</div>
    </Link>
  );
}

export const metadata = {
  title: "خيارات الاستثمار | Brix",
};

export default function InvestmentOptionsPage() {
  return (
    <div>
      <PageHero
        eyebrow="Research • Options"
        title="مجموعة خيارات استثمار مرنة"
        subtitle="اختر مسارًا يناسب أهدافك: دخل دوري، نمو رأسمالي، فرص مُهيكلة، أو منتجات متوافقة مع قيود ضريبية."
        ctaHref="/marketplace"
        ctaLabel="استعرض Marketplace"
        secondaryHref="/how-it-works"
        secondaryLabel="كيف تعمل المنصة؟"
        imageSrc="/images/property-2.jpg"
      />

      <Section
        title="كيف تفكر في التنويع"
        subtitle="بدل التركيز على نوع واحد، قدّم لنفسك مزيجًا مدروسًا عبر منتجات متعددة—كل منتج له مخاطره وأفقه الزمني."
      >
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <OptionCard
            icon={<Landmark className="h-4 w-4" />}
            title="REITs"
            desc="محافظ مُدارة تهدف للدخل أو النمو عبر أصول متعددة."
            href="/knowledge-center/why-reits"
          />
          <OptionCard
            icon={<Building2 className="h-4 w-4" />}
            title="Marketplace"
            desc="فرص عقارية مختارة مع صفحة تفاصيل ومقترحات DAO."
            href="/marketplace"
          />
          <OptionCard
            icon={<Layers className="h-4 w-4" />}
            title="1031 Exchange"
            desc="مسار خاص للصفقات المُهيكلة لتبديل الأصول وفق متطلبات معينة."
            href="/rm-1031-exchange"
          />
          <OptionCard
            icon={<Coins className="h-4 w-4" />}
            title="Private Credit"
            desc="منتجات دخل ثابت نسبيًا عبر قروض/تمويلات (نموذج تعليمي)."
            href="/private-credit-investments"
          />
          <OptionCard
            icon={<ShieldCheck className="h-4 w-4" />}
            title="Due Diligence"
            desc="منهجية تدقيق: الراعي، الخطة، العقار، والوثائق."
            href="/due-diligence-process"
          />
          <OptionCard
            icon={<LineChart className="h-4 w-4" />}
            title="استثمار التقاعد"
            desc="محتوى تعليمي حول الاستثمار عبر حسابات تقاعد (عام)."
            href="/real-estate-investing-with-your-ira"
          />
        </div>
      </Section>

      <CtaBand
        title="ابدأ بخطوات بسيطة"
        subtitle="أنشئ حسابًا، استعرض الفرص، ثم جرّب التصويت على مقترح أو تتبع توزيعات الإيجار (وضع تجريبي)."
        primaryHref="/auth/register"
        primaryLabel="إنشاء حساب"
        secondaryHref="/marketplace"
        secondaryLabel="مشاهدة الفرص"
      />

      <RiskNote />
    </div>
  );
}