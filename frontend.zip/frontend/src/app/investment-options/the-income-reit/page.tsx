import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { RiskNote } from "@/components/marketing/RiskNote";
import Link from "next/link";

export const metadata = { title: "Income REIT | Brix" };

export default function IncomeReitPage() {
  return (
    <div>
      <PageHero
        eyebrow="REIT"
        title="Income REIT (نموذج)"
        subtitle="قالب صفحة لمنتج REIT يستهدف الدخل: ملخص، أهداف، الرسوم، ونقاط المخاطر—مع أقسام قابلة للتخصيص."
        ctaHref="/auth/register"
        ctaLabel="إنشاء حساب"
        secondaryHref="/knowledge-center/why-reits"
        secondaryLabel="لماذا REITs؟"
        imageSrc="/images/property-2.jpg"
      />

      <Section title="نظرة عامة" subtitle="ضع هنا البيانات الحقيقية عندما تربط المنتج بقاعدة البيانات/العقود.">
        <div className="grid gap-4 md:grid-cols-3">
          <div className="kpi">
            <div className="text-sm text-metal-500">الهدف</div>
            <div className="mt-1 text-lg font-extrabold">دخل</div>
          </div>
          <div className="kpi">
            <div className="text-sm text-metal-500">الأفق الزمني</div>
            <div className="mt-1 text-lg font-extrabold">متوسط – طويل</div>
          </div>
          <div className="kpi">
            <div className="text-sm text-metal-500">الحد الأدنى</div>
            <div className="mt-1 text-lg font-extrabold">تجريبي</div>
          </div>
        </div>

        <div className="mt-8 surface p-6">
          <div className="font-semibold text-metal-900">الأقسام المقترحة</div>
          <ul className="mt-3 list-disc pr-6 text-sm text-metal-600 leading-relaxed">
            <li>الاستراتيجية وتكوين المحفظة</li>
            <li>الرسوم والمصاريف</li>
            <li>تقارير دورية وملفات</li>
            <li>المخاطر والافتراضات</li>
          </ul>
          <div className="mt-4 flex flex-wrap gap-3">
            <Link href="/knowledge-center" className="btn btn-ghost">مركز المعرفة</Link>
            <Link href="/legal/risk" className="btn btn-ghost">إفصاح المخاطر</Link>
          </div>
        </div>
      </Section>

      <RiskNote />
    </div>
  );
}
