import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { RiskNote } from "@/components/marketing/RiskNote";
import Link from "next/link";

export const metadata = { title: "Growth REIT | Brix" };

export default function GrowthReitPage() {
  return (
    <div>
      <PageHero
        eyebrow="REIT"
        title="Apartment Growth REIT (نموذج)"
        subtitle="قالب صفحة لمنتج نمو: يركز على ارتفاع القيمة عبر أصول سكنية/تطوير—مع شفافية الأقسام."
        ctaHref="/auth/register"
        ctaLabel="إنشاء حساب"
        secondaryHref="/knowledge-center/why-reits"
        secondaryLabel="لماذا REITs؟"
        imageSrc="/images/property-1.jpg"
      />

      <Section title="نظرة عامة" subtitle="استبدل القيم التجريبية ببياناتك بعد ربط النظام.">
        <div className="grid gap-4 md:grid-cols-3">
          <div className="kpi">
            <div className="text-sm text-metal-500">الهدف</div>
            <div className="mt-1 text-lg font-extrabold">نمو</div>
          </div>
          <div className="kpi">
            <div className="text-sm text-metal-500">الأفق الزمني</div>
            <div className="mt-1 text-lg font-extrabold">طويل</div>
          </div>
          <div className="kpi">
            <div className="text-sm text-metal-500">التركيز</div>
            <div className="mt-1 text-lg font-extrabold">سكني</div>
          </div>
        </div>

        <div className="mt-8 surface p-6">
          <div className="font-semibold text-metal-900">ما الذي نعرضه؟</div>
          <p className="mt-2 text-sm text-metal-600 leading-relaxed">
            صفحات المنتج يجب أن تشمل: استراتيجية، أمثلة أصول، تقارير، رسوم، ومخاطر.
          </p>
          <div className="mt-4 flex flex-wrap gap-3">
            <Link href="/marketplace" className="btn btn-primary">استعرض Marketplace</Link>
            <Link href="/knowledge-center" className="btn btn-ghost">مركز المعرفة</Link>
          </div>
        </div>
      </Section>

      <RiskNote />
    </div>
  );
}
