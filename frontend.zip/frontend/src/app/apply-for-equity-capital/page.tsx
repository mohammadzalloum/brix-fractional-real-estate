import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { RiskNote } from "@/components/marketing/RiskNote";

export const metadata = { title: "تقديم طلب تمويل | Brix" };

export default function ApplyEquityCapitalPage() {
  return (
    <div>
      <PageHero
        eyebrow="Financing"
        title="تقديم طلب لجمع رأس المال"
        subtitle="نموذج بسيط (قالب). يمكنك لاحقًا ربطه بقاعدة بيانات أو إرسال بريد."
        ctaHref="/contact-us"
        ctaLabel="تواصل معنا"
        secondaryHref="/financing/jv-equity"
        secondaryLabel="عملية JV Equity"
        imageSrc="/images/property-3.jpg"
      />

      <Section title="نموذج (واجهة فقط)" subtitle="لأسباب أمنية، هذه النسخة لا تُرسل بيانات حقيقية.">
        <form className="card p-6 grid gap-4 max-w-2xl">
          <div className="grid gap-2">
            <label className="text-sm font-semibold">اسم الشركة / الراعي</label>
            <input className="rounded-2xl border border-metal-200 px-4 py-2" placeholder="مثال: ABC Properties" />
          </div>
          <div className="grid gap-2">
            <label className="text-sm font-semibold">نوع الأصل</label>
            <input className="rounded-2xl border border-metal-200 px-4 py-2" placeholder="سكني / تجاري / ... " />
          </div>
          <div className="grid gap-2">
            <label className="text-sm font-semibold">وصف مختصر</label>
            <textarea className="rounded-2xl border border-metal-200 px-4 py-2 min-h-[120px]" placeholder="صف المشروع، المدينة، الحجم، الخطة..." />
          </div>
          <button type="button" className="btn btn-primary">إرسال (قريبًا)</button>
        </form>
      </Section>

      <RiskNote />
    </div>
  );
}
