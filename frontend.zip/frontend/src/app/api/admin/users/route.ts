import { NextResponse } from "next/server";
import { ensureSeedAccounts, getUsers, updateUserRole, type UserRole } from "@/lib/auth/store";
import { getSessionUser } from "@/lib/auth/session";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeedAccounts();
  const session = await getSessionUser();
  if (!session || session.role !== "admin") return NextResponse.json({ ok: false, code: "FORBIDDEN" }, { status: 403 });

  const users = await getUsers();
  return NextResponse.json({
    ok: true,
    users: users.map((u) => ({ id: u.id, email: u.email, role: u.role, wallet: u.wallet ?? null, createdAt: u.createdAt })),
  });
}

export async function PATCH(req: Request) {
  await ensureSeedAccounts();
  const session = await getSessionUser();
  if (!session || session.role !== "admin") return NextResponse.json({ ok: false, code: "FORBIDDEN" }, { status: 403 });

  const body = await req.json().catch(() => ({}));
  const id = String(body.id ?? "");
  const role = String(body.role ?? "") as UserRole;

  if (!id) return NextResponse.json({ ok: false, code: "MISSING_ID" }, { status: 400 });
  if (!["investor", "manager", "admin"].includes(role)) return NextResponse.json({ ok: false, code: "INVALID_ROLE" }, { status: 400 });

  const updated = await updateUserRole(id, role);
  return NextResponse.json({ ok: true, user: { id: updated.id, email: updated.email, role: updated.role, wallet: updated.wallet ?? null } });
}
