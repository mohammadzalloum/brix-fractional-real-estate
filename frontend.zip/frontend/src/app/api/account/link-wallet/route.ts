import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth/session";
import { linkWallet } from "@/lib/auth/store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const session = await getSessionUser();
  if (!session) return NextResponse.json({ ok: false, code: "UNAUTHORIZED" }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const wallet = String(body.wallet ?? "").trim();

  if (!/^0x[a-fA-F0-9]{40}$/.test(wallet)) {
    return NextResponse.json({ ok: false, code: "INVALID_WALLET" }, { status: 400 });
  }

  const updated = await linkWallet(session.id, wallet);
  return NextResponse.json({ ok: true, user: { id: updated.id, email: updated.email, role: updated.role, wallet: updated.wallet ?? null } });
}
