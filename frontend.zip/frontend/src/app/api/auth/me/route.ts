import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth/session";
import { ensureSeedAccounts } from "@/lib/auth/store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeedAccounts();
  const u = await getSessionUser();
  return NextResponse.json({ ok: true, user: u });
}
