import { NextResponse } from "next/server";
import { createUser, ensureSeedAccounts } from "@/lib/auth/store";
import { createSessionToken } from "@/lib/auth/jwt";
import { SESSION_COOKIE } from "@/lib/auth/session";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  await ensureSeedAccounts();

  const body = await req.json().catch(() => ({}));

  const email = String(body.email ?? "").trim();
  const password = String(body.password ?? "");

  const fullName = String(body.fullName ?? "").trim();
  const country = String(body.country ?? "").trim();
  const phone = String(body.phone ?? "").trim();

  // Smart contracts need wallet address (whitelist/claims/ownership).
  const wallet = String(body.wallet ?? "").trim();
  const requestManager = Boolean(body.requestManager ?? false);

  if (!wallet || !/^0x[a-fA-F0-9]{40}$/.test(wallet)) {
    return NextResponse.json({ ok: false, code: "INVALID_WALLET" }, { status: 400 });
  }

  try {
    const user = await createUser({
      email,
      password,
      role: "investor",
      wallet,
      fullName,
      country,
      phone,
      requestManager,
    });

    const token = createSessionToken({ sub: user.id, email: user.email, role: user.role });

    const res = NextResponse.json({
      ok: true,
      user: { id: user.id, email: user.email, role: user.role, wallet: user.wallet ?? null, fullName: user.fullName ?? null },
    });

    res.cookies.set(SESSION_COOKIE, token, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
    });

    return res;
  } catch (e: any) {
    const code = e?.message ?? "ERROR";
    return NextResponse.json({ ok: false, code }, { status: 400 });
  }
}
