import { NextResponse } from "next/server";
import { ensureSeedAccounts, getUserByEmail, verifyPassword } from "@/lib/auth/store";
import { createSessionToken } from "@/lib/auth/jwt";
import { SESSION_COOKIE } from "@/lib/auth/session";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  await ensureSeedAccounts();

  const body = await req.json().catch(() => ({}));
  const email = String(body.email ?? "").trim();
  const password = String(body.password ?? "");

  const user = await getUserByEmail(email);
  if (!user) {
    return NextResponse.json({ ok: false, code: "INVALID_CREDENTIALS" }, { status: 401 });
  }

  const valid = verifyPassword(password, user.passwordHash);
  if (!valid) {
    return NextResponse.json({ ok: false, code: "INVALID_CREDENTIALS" }, { status: 401 });
  }

  const token = createSessionToken({ sub: user.id, email: user.email, role: user.role });

  const res = NextResponse.json({
    ok: true,
    user: { id: user.id, email: user.email, role: user.role, wallet: user.wallet ?? null, fullName: user.fullName ?? null },
  });

  res.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });

  return res;
}
