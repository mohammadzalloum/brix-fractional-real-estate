import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth/session";
import { createStoredProperty, isEvmAddress } from "@/lib/properties/store";
import { getAllProperties } from "@/lib/properties";

function toNum(x: any): number | undefined {
  if (x === undefined || x === null || x === "") return undefined;
  const n = Number(x);
  return Number.isFinite(n) ? n : undefined;
}

function toStrList(x: any): string[] {
  if (!x) return [];
  if (Array.isArray(x)) return x.map(String).map((s) => s.trim()).filter(Boolean);
  if (typeof x === "string") return x.split(",").map((s) => s.trim()).filter(Boolean);
  return [];
}

export async function GET() {
  const all = await getAllProperties();
  return NextResponse.json({ properties: all }, { status: 200 });
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (user.role !== "manager" && user.role !== "admin") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const body = await req.json().catch(() => null);
  if (!body) return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });

  // Required fields
  const title = String(body.title ?? "").trim();
  const location = String(body.location ?? "").trim();
  const description = String(body.description ?? "").trim();
  const coverImage = String(body.coverImage ?? "").trim();
  const rentTokenSymbol = String(body.rentTokenSymbol ?? "").trim();

  const token = body.token;
  const vault = body.vault;
  const distributor = body.distributor;
  const governor = body.governor;
  const timelock = body.timelock;

  if (!title || !location || !description || !coverImage || !rentTokenSymbol) {
    return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
  }

  if (
    !isEvmAddress(token) ||
    !isEvmAddress(vault) ||
    !isEvmAddress(distributor) ||
    !isEvmAddress(governor) ||
    !isEvmAddress(timelock)
  ) {
    return NextResponse.json({ error: "Invalid contract address (must be 0x + 40 hex chars)." }, { status: 400 });
  }

  const tags = toStrList(body.tags).slice(0, 12);

  const record = await createStoredProperty(
    {
      id: body.id ? String(body.id) : undefined,
      title,
      location,
      description,
      coverImage,
      tags,

      token,
      vault,
      distributor,
      governor,
      timelock,

      rentTokenSymbol,
      docsUrl: body.docsUrl ? String(body.docsUrl).trim() : undefined,

      heroImage: body.heroImage ? String(body.heroImage).trim() : undefined,
      gallery: toStrList(body.gallery).slice(0, 12),
      propertyType: body.propertyType ? String(body.propertyType).trim() : undefined,
      sponsorName: body.sponsorName ? String(body.sponsorName).trim() : undefined,
      sponsorSlug: body.sponsorSlug ? String(body.sponsorSlug).trim() : undefined,

      priceUsd: toNum(body.priceUsd),
      minInvestmentUsd: toNum(body.minInvestmentUsd),
      targetYieldPct: toNum(body.targetYieldPct),
      occupancyPct: toNum(body.occupancyPct),
      yearBuilt: toNum(body.yearBuilt),
      units: toNum(body.units),

      highlights: toStrList(body.highlights).slice(0, 12),
      risks: toStrList(body.risks).slice(0, 12),
    },
    user.id
  );

  return NextResponse.json({ property: record }, { status: 201 });
}
