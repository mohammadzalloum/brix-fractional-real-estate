import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { RiskNote } from "@/components/marketing/RiskNote";
import Link from "next/link";

export const metadata = { title: "JV Equity | Brix" };

export default function JvEquityPage() {
  return (
    <div>
      <PageHero
        eyebrow="Financing"
        title="رفع رأس المال لمشروعك (قالب)"
        subtitle="صفحة تسويقية لمالكي المشاريع/الرعاة لشرح عملية جمع رأس المال وآلية التقييم."
        ctaHref="/apply-for-equity-capital"
        ctaLabel="تقديم طلب"
        secondaryHref="/contact-us"
        secondaryLabel="تواصل معنا"
        imageSrc="/images/hero.jpg"
      />

      <Section title="كيف نعمل مع الرعاة؟" subtitle="ضع هنا شروط قبول الرعاة ومعايير التدقيق.">
        <div className="grid gap-4 md:grid-cols-3">
          <div className="surface p-6">
            <div className="font-extrabold">التقديم</div>
            <p className="mt-2 text-sm text-metal-600 leading-relaxed">بيانات المشروع، فريق الإدارة، والخطة.</p>
          </div>
          <div className="surface p-6">
            <div className="font-extrabold">التقييم</div>
            <p className="mt-2 text-sm text-metal-600 leading-relaxed">سوق/عقار/تمويل/مخاطر.</p>
          </div>
          <div className="surface p-6">
            <div className="font-extrabold">الإدراج</div>
            <p className="mt-2 text-sm text-metal-600 leading-relaxed">إنشاء صفحة فرصة + مواد داعمة + مقترحات DAO.</p>
          </div>
        </div>

        <div className="mt-8 surface p-6">
          <div className="font-semibold text-metal-900">التالي</div>
          <div className="mt-3 flex flex-wrap gap-3">
            <Link href="/apply-for-equity-capital" className="btn btn-primary">تقديم طلب</Link>
            <Link href="/due-diligence-process" className="btn btn-ghost">منهجية التدقيق</Link>
          </div>
        </div>
      </Section>

      <RiskNote />
    </div>
  );
}
