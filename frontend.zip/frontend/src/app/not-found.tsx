import Link from "next/link";

export default function NotFound() {
  return (
    <div className="container py-12">
      <div className="card p-8 text-center">
        <div className="text-2xl font-semibold">الصفحة غير موجودة</div>
        <p className="mt-3 text-sm text-gray-600">قد يكون الرابط غير صحيح أو تم نقل الصفحة.</p>
        <div className="mt-6 flex justify-center gap-3">
          <Link href="/" className="btn btn-primary">العودة للرئيسية</Link>
          <Link href="/properties" className="btn btn-ghost">العقارات</Link>
        </div>
      </div>
    </div>
  );
}
