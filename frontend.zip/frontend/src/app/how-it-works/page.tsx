import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { CtaBand } from "@/components/marketing/CtaBand";
import { RiskNote } from "@/components/marketing/RiskNote";
import { BadgeCheck, Wallet, Vote, Coins, Wrench, Clock } from "lucide-react";
import type { ReactNode } from "react";

export const metadata = { title: "كيف تعمل | Brix" };

function Step({ icon, title, desc }: { icon: ReactNode; title: string; desc: string }) {
  return (
    <div className="surface p-6">
      <div className="badge badge-gold w-fit">{icon}<span className="font-semibold">{title}</span></div>
      <p className="mt-3 text-sm text-metal-600 leading-relaxed">{desc}</p>
    </div>
  );
}

export default function HowItWorksPage() {
  return (
    <div>
      <PageHero
        eyebrow="Process"
        title="تجربة استثمار + حوكمة بشكل مبسط"
        subtitle="نموذج Brix يجمع بين امتلاك حصص، تصويت DAO، وتوزيع الإيجار بأسلوب Claim (سحب)."
        ctaHref="/auth/register"
        ctaLabel="ابدأ الآن"
        secondaryHref="/due-diligence-process"
        secondaryLabel="منهجية التدقيق"
        imageSrc="/images/property-1.jpg"
      />

      <Section title="خطوات العمل" subtitle="من التسجيل إلى التوزيع—كل شيء واضح وقابل للتتبع.">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Step icon={<BadgeCheck className="h-4 w-4" />} title="1) إنشاء حساب" desc="حساب مستخدم عادي لاستعراض الفرص ومتابعة المقترحات." />
          <Step icon={<Wallet className="h-4 w-4" />} title="2) ربط محفظة" desc="للتفاعل على الشبكة (تصويت/Claims) عند تفعيل الربط." />
          <Step icon={<Vote className="h-4 w-4" />} title="3) التصويت" desc="رمز الحصص يعطي وزن تصويت. المقترحات تمر عبر Timelock." />
          <Step icon={<Coins className="h-4 w-4" />} title="4) توزيع الإيجار" desc="مدير العقار يودع صافي الإيجار، والمستثمرون يطالبون بحصتهم." />
          <Step icon={<Wrench className="h-4 w-4" />} title="5) المصاريف" desc="المصاريف تُنفذ عبر الحوكمة دون المساس بأموال المستثمرين المستحقة." />
          <Step icon={<Clock className="h-4 w-4" />} title="6) شفافية" desc="كل الإيداعات، المقترحات، والتنفيذات قابلة للمراجعة." />
        </div>
      </Section>

      <CtaBand
        title="جرّب Marketplace"
        subtitle="افتح صفحة أي عقار، راجع بياناته، ثم تابع مقترحات الحوكمة المرتبطة."
        primaryHref="/marketplace"
        primaryLabel="فتح Marketplace"
        secondaryHref="/dashboard"
        secondaryLabel="لوحة المتابعة"
      />

      <RiskNote />
    </div>
  );
}