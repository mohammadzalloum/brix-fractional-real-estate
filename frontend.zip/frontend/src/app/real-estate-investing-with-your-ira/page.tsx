import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { RiskNote } from "@/components/marketing/RiskNote";
import Link from "next/link";

export const metadata = { title: "استثمار التقاعد | Brix" };

export default function RetirementInvestingPage() {
  return (
    <div>
      <PageHero
        eyebrow="Learn"
        title="الاستثمار عبر حسابات التقاعد (عام)"
        subtitle="صفحة تعليمية توضح كيف يمكن أن يفكر المستثمرون في الاستثمار ضمن قيود حسابات التقاعد—مع التأكيد على مراجعة القوانين المحلية."
        ctaHref="/knowledge-center"
        ctaLabel="مركز المعرفة"
        secondaryHref="/legal/risk"
        secondaryLabel="إفصاح المخاطر"
        imageSrc="/images/property-2.jpg"
      />

      <Section
        title="نقاط سريعة"
        subtitle="هذا ليس إرشادًا قانونيًا/ضريبيًا—بل قالب محتوى وتعليمي."
      >
        <div className="grid gap-4 md:grid-cols-2">
          <div className="card p-6 hover-luxe">
            <div className="text-lg font-extrabold tracking-tight">الامتثال أولاً</div>
            <p className="mt-2 text-sm text-metal-600 leading-relaxed">
              تأكد من القواعد الخاصة ببلدك/مزود حساب التقاعد قبل أي خطوة.
            </p>
          </div>
          <div className="card p-6 hover-luxe">
            <div className="text-lg font-extrabold tracking-tight">السيولة والمدة</div>
            <p className="mt-2 text-sm text-metal-600 leading-relaxed">
              بعض الاستثمارات العقارية غير سائلة وقد لا تناسب أفقًا زمنيًا قصيرًا.
            </p>
          </div>
        </div>

        <div className="mt-8 surface p-6">
          <div className="font-semibold text-metal-900">روابط ذات صلة</div>
          <div className="mt-3 flex flex-wrap gap-3">
            <Link href="/investment-options" className="btn btn-ghost">خيارات الاستثمار</Link>
            <Link href="/due-diligence-process" className="btn btn-ghost">منهجية التدقيق</Link>
          </div>
        </div>
      </Section>

      <RiskNote />
    </div>
  );
}
