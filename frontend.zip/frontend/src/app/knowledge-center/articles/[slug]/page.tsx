import { notFound } from "next/navigation";
import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { RiskNote } from "@/components/marketing/RiskNote";

const ARTICLES: Record<string, { title: string; subtitle: string; body: string[] }> = {
  "what-is-1031": {
    title: "ما هو 1031؟ (ملخص)",
    subtitle: "مقدمة عامة ومبسطة—ليست استشارة ضريبية.",
    body: [
      "يُستخدم مصطلح 1031 للإشارة إلى آليات استبدال أصول ضمن إطار تنظيمي/ضريبي في بعض الدول. تختلف القواعد حسب الدولة.",
      "الفكرة العامة: بيع أصل وشراء آخر ضمن شروط وجدول زمني محدد للحفاظ على مزايا معينة.",
      "احرص على استشارة مختص قانوني/ضريبي في بلدك."
    ],
  },
  "timeline": {
    title: "الجدول الزمني",
    subtitle: "كيف تخطط للخطوات وتتجنب التأخير (قالب).",
    body: [
      "حدد تاريخ البيع/الإغلاق كنقطة بداية.",
      "أنشئ قائمة تحقق للمستندات والفحص.",
      "خصص هامش زمن للتأخير، وتأكد من توافق الصفقة مع القيود ذات الصلة."
    ],
  },
  "common-mistakes": {
    title: "أخطاء شائعة",
    subtitle: "قائمة مختصرة لتقليل المخاطر التشغيلية.",
    body: [
      "التأخر في جمع المستندات.",
      "عدم وضوح الأدوار (من يجمع الإيجار؟ من يودع؟).",
      "الاعتماد على افتراضات غير مدعومة بالبيانات."
    ],
  },
};

export default function ArticlePage({ params }: { params: { slug: string } }) {
  const a = ARTICLES[params.slug];
  if (!a) return notFound();

  return (
    <div>
      <PageHero
        eyebrow="Knowledge Center"
        title={a.title}
        subtitle={a.subtitle}
        ctaHref="/knowledge-center"
        ctaLabel="عودة لمركز المعرفة"
        secondaryHref="/marketplace"
        secondaryLabel="استعرض الفرص"
        imageSrc="/images/property-2.jpg"
      />

      <Section title="المحتوى" subtitle="محتوى تجريبي قابل للاستبدال.">
        <div className="prose max-w-none">
          {a.body.map((p, idx) => (
            <p key={idx} className="text-metal-700 leading-relaxed">{p}</p>
          ))}
        </div>
      </Section>

      <RiskNote />
    </div>
  );
}
