import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { RiskNote } from "@/components/marketing/RiskNote";
import Link from "next/link";

export const metadata = { title: "لماذا العقار التجاري؟ | Brix" };

export default function WhyCREPage() {
  return (
    <div>
      <PageHero
        eyebrow="Learn • CRE"
        title="لماذا العقار التجاري؟"
        subtitle="قالب تعليمي يوضح مزايا وعيوب التعرض للعقار التجاري مقارنة بأصول أخرى."
        ctaHref="/marketplace"
        ctaLabel="استعرض الفرص"
        secondaryHref="/due-diligence-process"
        secondaryLabel="منهجية التدقيق"
        imageSrc="/images/property-1.jpg"
      />

      <Section title="متى يكون مناسبًا؟" subtitle="قد يناسب من يفكر في التنويع طويل الأجل—مع فهم المخاطر.">
        <div className="grid gap-4 md:grid-cols-3">
          <div className="surface p-6">
            <div className="font-extrabold">تنويع</div>
            <p className="mt-2 text-sm text-metal-600 leading-relaxed">قد يقل الارتباط ببعض الأصول الأخرى في فترات معينة.</p>
          </div>
          <div className="surface p-6">
            <div className="font-extrabold">تدفقات نقدية</div>
            <p className="mt-2 text-sm text-metal-600 leading-relaxed">قد تنتج بعض الأصول دخلًا دوريًا (بحسب التشغيل).</p>
          </div>
          <div className="surface p-6">
            <div className="font-extrabold">مخاطر</div>
            <p className="mt-2 text-sm text-metal-600 leading-relaxed">الركود، الشغور، السيولة، والتكاليف غير المتوقعة.</p>
          </div>
        </div>

        <div className="mt-8 surface p-6">
          <div className="font-semibold text-metal-900">روابط مفيدة</div>
          <div className="mt-3 flex flex-wrap gap-3">
            <Link href="/knowledge-center" className="btn btn-ghost">مركز المعرفة</Link>
            <Link href="/legal/risk" className="btn btn-ghost">إفصاح المخاطر</Link>
          </div>
        </div>
      </Section>

      <RiskNote />
    </div>
  );
}
