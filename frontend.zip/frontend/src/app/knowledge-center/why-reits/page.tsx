import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { RiskNote } from "@/components/marketing/RiskNote";
import Link from "next/link";

export const metadata = { title: "لماذا REITs؟ | Brix" };

export default function WhyReitsPage() {
  return (
    <div>
      <PageHero
        eyebrow="Learn • REITs"
        title="فهم أساسيات REITs"
        subtitle="قالب تعليمي يشرح لماذا قد يختار بعض المستثمرين REITs كجزء من محفظتهم، وما الذي يجب الانتباه له."
        ctaHref="/investment-options/the-income-reit"
        ctaLabel="Income REIT"
        secondaryHref="/investment-options/the-apartment-growth-reit"
        secondaryLabel="Growth REIT"
        imageSrc="/images/hero.jpg"
      />

      <Section title="الفكرة العامة" subtitle="REIT عادةً يمنح تعرضًا لمحفظة أصول مُدارة بدل صفقة واحدة.">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="card p-6 hover-luxe">
            <div className="text-lg font-extrabold tracking-tight">الدخل</div>
            <p className="mt-2 text-sm text-metal-600 leading-relaxed">
              بعض المنتجات تستهدف توزيع دخل دوري (مع مخاطر السوق).
            </p>
          </div>
          <div className="card p-6 hover-luxe">
            <div className="text-lg font-extrabold tracking-tight">النمو</div>
            <p className="mt-2 text-sm text-metal-600 leading-relaxed">
              منتجات أخرى تركز على نمو القيمة على المدى الأطول.
            </p>
          </div>
        </div>

        <div className="mt-8 surface p-6">
          <div className="font-semibold text-metal-900">التالي</div>
          <div className="mt-3 flex flex-wrap gap-3">
            <Link href="/investment-options/the-income-reit" className="btn btn-primary">استعرض Income REIT</Link>
            <Link href="/investment-options/the-apartment-growth-reit" className="btn btn-ghost">استعرض Growth REIT</Link>
          </div>
        </div>
      </Section>

      <RiskNote />
    </div>
  );
}
