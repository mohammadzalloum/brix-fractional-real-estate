import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { RiskNote } from "@/components/marketing/RiskNote";

export const metadata = { title: "أخبار وإعلانات | Brix" };

const items = [
  { date: "2025-12-14", title: "إطلاق نسخة تجريبية من Brix Portal", desc: "تحديث واجهة التسويق + Marketplace + صفحات المعرفة." },
  { date: "2025-12-01", title: "تحسين الهوية البصرية", desc: "ألوان ذهبية/زرقاء وتقوية تجربة الهاتف." },
];

export default function PressPage() {
  return (
    <div>
      <PageHero
        eyebrow="News"
        title="أخبار وإعلانات"
        subtitle="صفحة منظمة لنشر تحديثات المنتج والبيانات العامة."
        ctaHref="/contact-us"
        ctaLabel="تواصل معنا"
        secondaryHref="/knowledge-center"
        secondaryLabel="مركز المعرفة"
        imageSrc="/images/hero.jpg"
      />

      <Section title="آخر التحديثات" subtitle="أضف روابط خارجية أو مقالات داخلية لاحقًا.">
        <div className="grid gap-4">
          {items.map((x) => (
            <div key={x.title} className="card p-6 hover-luxe">
              <div className="text-xs text-metal-500">{x.date}</div>
              <div className="mt-1 text-lg font-extrabold tracking-tight">{x.title}</div>
              <div className="mt-2 text-sm text-metal-600 leading-relaxed">{x.desc}</div>
            </div>
          ))}
        </div>
      </Section>

      <RiskNote />
    </div>
  );
}
