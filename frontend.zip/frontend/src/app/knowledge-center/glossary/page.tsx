import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { RiskNote } from "@/components/marketing/RiskNote";

export const metadata = { title: "قاموس المصطلحات | Brix" };

const terms = [
  { t: "DAO", d: "منظمة لامركزية—آلية قرار جماعي عبر تصويت." },
  { t: "Timelock", d: "تأخير زمني لتنفيذ قرارات الحوكمة بعد اعتمادها." },
  { t: "ERC20", d: "معيار توكن قابل للتحويل على شبكة EVM." },
  { t: "ERC20Votes", d: "امتداد يضيف وزن التصويت المبني على التوكن." },
  { t: "Vault", d: "خزنة تحتفظ بالأموال وتفرض قيود الإنفاق." },
  { t: "Claim", d: "نموذج سحب: المستثمر يطالب بحصته بنفسه." },
];

export default function GlossaryPage() {
  return (
    <div>
      <PageHero
        eyebrow="Learn"
        title="قاموس المصطلحات"
        subtitle="مصطلحات أساسية لفهم نموذج Brix."
        ctaHref="/knowledge-center"
        ctaLabel="عودة لمركز المعرفة"
        secondaryHref="/docs"
        secondaryLabel="التوثيق"
        imageSrc="/images/property-3.jpg"
      />

      <Section title="مصطلحات" subtitle="أضف/عدّل حسب منتجك.">
        <div className="grid gap-3">
          {terms.map((x) => (
            <div key={x.t} className="surface p-5">
              <div className="text-base font-extrabold tracking-tight">{x.t}</div>
              <div className="mt-1 text-sm text-metal-600 leading-relaxed">{x.d}</div>
            </div>
          ))}
        </div>
      </Section>

      <RiskNote />
    </div>
  );
}
