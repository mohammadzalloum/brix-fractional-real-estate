import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { RiskNote } from "@/components/marketing/RiskNote";
import Link from "next/link";

export const metadata = { title: "مركز المعرفة | Brix" };

const cards = [
  { href: "/knowledge-center/faqs", title: "الأسئلة الشائعة", desc: "إجابات سريعة حول التجربة والحوكمة وتوزيع الإيجار." },
  { href: "/knowledge-center/glossary", title: "قاموس المصطلحات", desc: "مصطلحات DAO + العقار + التمويل بشكل مبسط." },
  { href: "/knowledge-center/press", title: "أخبار وإعلانات", desc: "مساحة لبيانات صحفية وتحديثات عامة." },
  { href: "/knowledge-center/why-reits", title: "لماذا REITs؟", desc: "محتوى تعليمي عن REITs." },
  { href: "/knowledge-center/why-commercial-real-estate", title: "لماذا العقار التجاري؟", desc: "موازنة المنافع والمخاطر." },
  { href: "/real-estate-investing-with-your-ira", title: "استثمار التقاعد", desc: "محتوى عام/تعليمي." },
];

export default function KnowledgeCenterPage() {
  return (
    <div>
      <PageHero
        eyebrow="Learn"
        title="مركز المعرفة"
        subtitle="مقالات مختارة، قاموس، ومواد تساعد المستثمر على فهم الحوكمة والعقار—قبل أي قرار."
        ctaHref="/marketplace"
        ctaLabel="استعرض الفرص"
        secondaryHref="/how-it-works"
        secondaryLabel="كيف تعمل؟"
        imageSrc="/images/hero.jpg"
      />

      <Section title="استكشف المحتوى" subtitle="هذه صفحات جاهزة كبنية—استبدل النصوص بمحتوى قانوني/تعليمي خاص بك.">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {cards.map((c) => (
            <Link key={c.href} href={c.href} className="card p-6 hover-luxe">
              <div className="text-lg font-extrabold tracking-tight">{c.title}</div>
              <p className="mt-2 text-sm text-metal-600 leading-relaxed">{c.desc}</p>
              <div className="mt-4 text-sm font-semibold">فتح →</div>
            </Link>
          ))}
        </div>
      </Section>

      <RiskNote />
    </div>
  );
}
