export { default } from "../../faq/page";
