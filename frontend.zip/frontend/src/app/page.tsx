import Link from "next/link";
import Image from "next/image";
import { getAllProperties } from "@/lib/properties";
import type { PropertyInstance } from "@/config/properties";
import { ShieldCheck, Building2, Vote, Coins, Sparkles, LineChart } from "lucide-react";
import type { ReactNode } from "react";
import { Reveal } from "@/components/Reveal";
import { getLang, tr } from "@/i18n/server";

function Feature({ icon, title, desc }: { icon: ReactNode; title: string; desc: string }) {
  return (
    <div className="surface p-5">
      <div className="badge w-fit">
        {icon}<span className="font-semibold">{title}</span>
      </div>
      <p className="mt-3 text-sm text-slate-600 leading-relaxed">{desc}</p>
    </div>
  );
}

export default async function HomePage() {
  const lang = getLang();
  const properties = (await getAllProperties()) as unknown as PropertyInstance[];
  return (
    <div className="snap-y snap-proximity">
      <section className="relative overflow-hidden snap-start scroll-mt-24 min-h-[calc(100vh-88px)] flex items-center">
        <div className="absolute inset-0 bg-brix-radial" />
        <div className="absolute inset-0 opacity-40 bg-grid" />
        <div className="container relative py-12">
          <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
            <Reveal>
            <div>
              <div className="badge badge-blue">
                <Sparkles className="h-4 w-4 text-brand-700" />
                {tr(lang, "تجربة استثمار عقاري مُجزّأ بواجهة احترافية (MVP)", "Fractional real estate investing — polished MVP")}
              </div>

              <h1 className="mt-4 text-4xl md:text-5xl font-extrabold leading-[1.15]">
                {tr(lang, "استثمر في عقارات مُجزّأة…", "Invest in fractional real estate…")}
                <br />
                {tr(lang, "وشارك في القرار", "and take part in decisions")}
              </h1>

              <p className="mt-4 text-slate-600 leading-relaxed">
                {tr(
                  lang,
                  "لكل عقار: توكن حصص (ERC20Votes) يمنحك قوة تصويت، خزنة لإيداع الإيجارات، موزّع أرباح Claim، وحوكمة (Governor + Timelock) للمصاريف والقرارات.",
                  "For each property: a share token (ERC20Votes) for voting power, a Vault for rent deposits, a Claim-based distributor, and governance (Governor + Timelock) for expenses and decisions."
                )}
              </p>

              <div className="mt-6 flex flex-wrap gap-3">
                <Link href="/properties" className="btn btn-primary">{tr(lang, "استعراض العقارات", "Browse properties")}</Link>
                <Link href="/dashboard" className="btn btn-ghost">{tr(lang, "لوحتي", "Dashboard")}</Link>
                <Link href="/docs" className="btn btn-ghost">{tr(lang, "كيف يعمل النظام؟", "How it works")}</Link>
                <Link href="/investment-opportunities" className="btn btn-ghost">{tr(lang, "عرض الفرص", "View investments")}</Link>
              </div>

              <div className="mt-8 grid gap-4 sm:grid-cols-3">
                <div className="kpi">
                  <div className="text-xs text-slate-500">{tr(lang, "توزيعات", "Distributions")}</div>
                  <div className="mt-1 text-lg font-semibold">Claim</div>
                  <div className="mt-2 text-xs text-slate-500">{tr(lang, "نموذج Pull لتقليل المخاطر", "Pull model to reduce risk")}</div>
                </div>
                <div className="kpi">
                  <div className="text-xs text-slate-500">{tr(lang, "حوكمة", "Governance")}</div>
                  <div className="mt-1 text-lg font-semibold">Timelock</div>
                  <div className="mt-2 text-xs text-slate-500">{tr(lang, "قرارات مؤجلة وقابلة للتدقيق", "Delayed, auditable decisions")}</div>
                </div>
                <div className="kpi">
                  <div className="text-xs text-slate-500">{tr(lang, "شفافية", "Transparency")}</div>
                  <div className="mt-1 text-lg font-semibold">On‑chain</div>
                  <div className="mt-2 text-xs text-slate-500">{tr(lang, "حسابات أرباح على السلسلة", "On-chain accounting")}</div>
                </div>
              </div>
            </div>

            </Reveal>

            <Reveal delayMs={140}>
            <div className="relative">
              <div className="surface p-3">
                <div className="relative aspect-[16/10] overflow-hidden rounded-3xl">
                  <Image src="/images/amman-skyline.jpg" alt="Amman skyline" fill className="object-cover object-center" priority />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/50 to-transparent" />
                  <div className="absolute bottom-4 right-4 left-4 flex flex-wrap gap-2">
                    <span className="badge border-white/20 bg-white/10 text-white">
                      <Building2 className="h-4 w-4" /> {tr(lang, "أصول حقيقية", "Real assets")}
                    </span>
                    <span className="badge border-white/20 bg-white/10 text-white">
                      <ShieldCheck className="h-4 w-4" /> {tr(lang, "حماية الخزنة", "Vault safeguards")}
                    </span>
                    <span className="badge border-white/20 bg-white/10 text-white">
                      <Vote className="h-4 w-4" /> {tr(lang, "تصويت", "Voting")}
                    </span>
                    <span className="badge border-white/20 bg-white/10 text-white">
                      <Coins className="h-4 w-4" /> {tr(lang, "توزيعات", "Distributions")}
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <Feature
                  icon={<LineChart className="h-4 w-4 text-brand-700" />}
                  title={tr(lang, "مؤشرات واضحة", "Clear metrics")}
                  desc={tr(lang, "اعرض الأداء والتوزيعات على مستوى العقار والمستثمر بشكل بسيط ومفهوم.", "See performance and distributions at the property and investor levels — simple and readable.")}
                />
                <Feature
                  icon={<ShieldCheck className="h-4 w-4 text-brand-700" />}
                  title={tr(lang, "ثقة أعلى", "Higher trust")}
                  desc={tr(lang, "حسابات التوزيع تعمل on-chain، والخزنة تمنع إنفاق الأموال المستحقة للمستثمرين.", "Distribution accounting runs on-chain, and the Vault protects investor-entitled funds.")}
                />
              </div>
            </div>
            </Reveal>
          </div>
        </div>
      </section>
<section className="container py-8 snap-start scroll-mt-24 min-h-[calc(100vh-88px)] flex flex-col justify-center">
        <Reveal>
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-extrabold">{tr(lang, "عقارات مميزة", "Featured properties")}</h2>
            <p className="mt-2 text-sm text-slate-600">
              {tr(
                lang,
                "فرص مختارة داخل الأردن — مع تفاصيل الحصص، التوزيعات، والحوكمة لكل عقار.",
                "Curated opportunities in Jordan — with shares, distributions, and governance details for each property."
              )}
            </p>
          </div>
          <Link href="/properties" className="btn btn-ghost">{tr(lang, "عرض الكل", "View all")}</Link>
        </div>
        </Reveal>

        <div className="mt-6 grid gap-5 md:grid-cols-3">
          {properties.slice(0, 3).map((p, idx) => (
            <Reveal key={p.id} delayMs={idx * 90}>
              <Link href={`/properties/${p.id}`} className="group card overflow-hidden transition hover:-translate-y-1 hover:shadow-glow">
              <div className="relative h-44">
                <Image src={p.coverImage} alt={p.title} fill className="object-cover object-top" />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/40 to-transparent" />
              </div>
              <div className="p-5">
                <div className="text-sm text-slate-500">{p.location}</div>
                <div className="mt-1 text-lg font-extrabold">{p.title}</div>
                <p className="mt-2 text-sm text-slate-600 line-clamp-2">{p.description}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {p.tags.slice(0, 3).map((t) => (
                    <span key={t} className="badge badge-blue">{t}</span>
                  ))}
                </div>
              </div>
            </Link>
              </Reveal>
          ))}
        </div>
      </section>


{/* ---- Brix value sections (inspired layout) ---- */}
<section className="py-8 md:py-10 snap-start scroll-mt-24 min-h-[calc(100vh-88px)] flex items-center">
  <div className="container w-full lg:px-0">
    {/* Full-screen feature section */}
    <div className="grid overflow-hidden border border-slate-200 bg-white lg:grid-cols-2 h-[calc(100vh-140px)] min-h-[560px] max-h-[900px]">
      {/* Left: image panel */}
      <div className="relative overflow-hidden">
        <Image
          src="/images/more-than-platform.webp"
          alt="Brix platform"
          fill
          className="object-cover object-top"
          priority={false}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-slate-950/35 to-transparent" />

        <div className="relative z-10 flex h-full flex-col justify-end p-6 md:p-10">
          <Reveal>
            <h2 className="max-w-xl text-3xl font-extrabold tracking-tight text-white md:text-4xl">
              {tr(lang, "أكثر من مجرد منصة استثمار", "More than just an investment platform")}
            </h2>
          </Reveal>

          <Reveal delayMs={120}>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-white/85">
              {tr(
                lang,
                "Brix تربط بين الاستثمار العقاري المُجزّأ وشفافية البلوك تشين: حصص (ERC20Votes)، توزيعات إيجار قابلة للمطالبة (Claim)، وحوكمة قرارات المصروفات عبر Timelock.",
                "Brix combines fractional real-estate investing with blockchain transparency: shares (ERC20Votes), claimable rent distributions (Claim), and governance via Timelock."
              )}
            </p>
          </Reveal>

          <Reveal delayMs={240}>
            <div className="mt-8">
              <Link href="/investment-opportunities" className="btn btn-primary">
                {tr(lang, "استكشف الفرص", "Explore opportunities")}
              </Link>
            </div>
          </Reveal>
        </div>
      </div>

      {/* Right: value pillars */}
      <div className="grid h-full divide-y divide-slate-200">
        <Reveal className="h-full">
          <div className="group h-full p-6 md:p-10 transition-colors hover:bg-slate-50">
            <div className="text-sm font-extrabold tracking-[0.20em] text-blue-700 md:text-base">{tr(lang, "الوصول والشفافية", "Access & transparency")}</div>
            <p className="mt-4 max-w-xl text-base leading-relaxed text-slate-700 md:text-lg">
              {tr(
                lang,
                "معلومات واضحة عن الحصص، التوزيعات، والقرارات — مع سجل on-chain يسهل مراجعته ويقلّل الغموض حول أين تذهب أموال الإيجار ومتى تصبح قابلة للمطالبة.",
                "Clear info about shares, distributions, and decisions — backed by an on-chain record that's easy to audit and reduces ambiguity around where rent goes and when it becomes claimable."
              )}
            </p>
          </div>
        </Reveal>

        <Reveal delayMs={120} className="h-full">
          <div className="group h-full p-6 md:p-10 transition-colors hover:bg-slate-50">
            <div className="text-sm font-extrabold tracking-[0.20em] text-blue-700 md:text-base">{tr(lang, "معك في كل خطوة", "With you every step")}</div>
            <p className="mt-4 max-w-xl text-base leading-relaxed text-slate-700 md:text-lg">
              {tr(
                lang,
                "تجربة مبسّطة من اختيار العقار وحتى ربط المحفظة، وحتى متابعة توزيعات الإيجار والتصويت على المقترحات — بدون تعقيد.",
                "A streamlined experience from selecting a property to connecting a wallet, tracking rent distributions, and voting on proposals — without the complexity."
              )}
            </p>
          </div>
        </Reveal>

        <Reveal delayMs={240} className="h-full">
          <div className="group h-full p-6 md:p-10 transition-colors hover:bg-slate-50">
            <div className="text-sm font-extrabold tracking-[0.20em] text-blue-700 md:text-base">{tr(lang, "حوكمة مسؤولة", "Responsible governance")}</div>
            <p className="mt-4 max-w-xl text-base leading-relaxed text-slate-700 md:text-lg">
              {tr(
                lang,
                "المصروفات لا تُصرف إلا عبر الحوكمة (Governor + Timelock) مع حماية أموال المستثمرين المستحقة للتوزيع داخل الـVault.",
                "Expenses can only be executed via governance (Governor + Timelock), while investor-entitled funds remain protected inside the Vault."
              )}
            </p>
          </div>
        </Reveal>
      </div>
    </div>

    {/* On very tall screens: keep a comfortable margin above/below */}
    <div className="hidden lg:block h-6" />
  </div>
</section>

<section className="py-8 md:py-10 snap-start scroll-mt-24 min-h-[calc(100vh-88px)] flex items-center">
  <div className="container w-full lg:px-0">
    {/* Full-screen due diligence section */}
    <div className="grid overflow-hidden border border-slate-200 bg-white lg:grid-cols-2 h-[calc(100vh-140px)] min-h-[560px] max-h-[900px]">
      {/* Copy */}
      <div className="flex h-full flex-col justify-between p-6 md:p-10">
        <div>
          <Reveal>
            <div className="text-xs font-extrabold tracking-[0.22em] text-blue-700">
              {tr(lang, "منهجيتنا", "Our approach")}
            </div>
          </Reveal>

          <Reveal delayMs={120}>
            <h2 className="mt-4 text-3xl font-extrabold tracking-tight md:text-4xl">
              {tr(lang, "اعتماد الفرص ليس شيئًا عشوائيًا", "Opportunity approval isn't random")}
            </h2>
          </Reveal>

          <Reveal delayMs={220}>
            <p className="mt-4 text-sm leading-relaxed text-slate-700">
              {tr(
                lang,
                "قبل عرض أي فرصة، نمرّ بخطوات تدقيق واضحة (يمكن تخصيصها حسب عملك)، ثم تُربط التدفقات المالية بعقود Vault وDistributor لضمان التوزيع العادل.",
                "Before we list any opportunity, we run a clear diligence workflow (customizable to your process), then connect cashflows to the Vault and Distributor contracts for fair distribution."
              )}
            </p>
          </Reveal>

          <ul className="mt-8 grid gap-3">
            <Reveal delayMs={320}>
              <li className="group flex gap-3 rounded-2xl border border-slate-200 p-4 transition hover:-translate-y-0.5 hover:bg-slate-50 hover:shadow-[0_16px_40px_rgba(15,23,42,.10)]">
                <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-700" />
                <span className="text-sm text-slate-700">
                  {tr(lang, "فحص الملكية والوضع القانوني: مطابقة المستندات وتقليل المخاطر.", "Title & legal review: verify documents and reduce risk.")}
                </span>
              </li>
            </Reveal>

            <Reveal delayMs={420}>
              <li className="group flex gap-3 rounded-2xl border border-slate-200 p-4 transition hover:-translate-y-0.5 hover:bg-slate-50 hover:shadow-[0_16px_40px_rgba(15,23,42,.10)]">
                <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-700" />
                <span className="text-sm text-slate-700">
                  {tr(lang, "تحليل العائد والإشغال: سيناريوهات محافظة/متوسطة/متفائلة لتوقع الدخل.", "Yield & occupancy analysis: conservative/base/optimistic scenarios for income.")}
                </span>
              </li>
            </Reveal>

            <Reveal delayMs={520}>
              <li className="group flex gap-3 rounded-2xl border border-slate-200 p-4 transition hover:-translate-y-0.5 hover:bg-slate-50 hover:shadow-[0_16px_40px_rgba(15,23,42,.10)]">
                <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-700" />
                <span className="text-sm text-slate-700">
                  {tr(lang, "توثيق وتدقيق: مستندات، افتراضات، وخطّة توزيع/Claim واضحة للمستثمرين.", "Documentation & audit: assumptions, files, and a clear distribution/Claim plan.")}
                </span>
              </li>
            </Reveal>
          </ul>
        </div>

        <Reveal delayMs={620}>
          <div className="mt-8">
            <Link href="/due-diligence-process" className="btn btn-primary">
              {tr(lang, "اعرف المزيد", "Learn more")}
            </Link>
          </div>
        </Reveal>
      </div>

      {/* Image */}
      <div className="relative overflow-hidden">
        <Image
          src="/images/due-diligence.webp"
          alt="Due diligence"
          fill
          className="object-cover object-top"
        />
        <div className="absolute inset-0 bg-gradient-to-l from-slate-950/55 via-slate-950/10 to-transparent" />
      </div>
    </div>

    {/* On very tall screens: keep a comfortable margin above/below */}
    <div className="hidden lg:block h-6" />
  </div>
</section>



      <section className="container pb-10 snap-start scroll-mt-24 min-h-[calc(100vh-88px)] flex items-center">
        <Reveal className="w-full">
        <div className="surface p-8 md:p-12">
          <div className="grid gap-8 lg:grid-cols-[1fr_.9fr] lg:items-center">
            <div>
              <h3 className="text-3xl md:text-4xl font-extrabold">{tr(lang, "ابدأ الآن خلال دقائق", "Get started in minutes")}</h3>
              <p className="mt-3 text-base text-slate-600 leading-relaxed">
                {tr(
                  lang,
                  "سجّل حسابًا، اربط محفظتك، وابدأ باستعراض العقارات ومتابعة التوزيعات والحوكمة.",
                  "Create an account, connect your wallet, and start browsing properties while tracking distributions and governance."
                )}
              </p>

              <div className="mt-6 flex flex-wrap gap-3">
                <Link href="/auth/register" className="btn btn-primary">{tr(lang, "إنشاء حساب", "Create account")}</Link>
                <Link href="/auth/login" className="btn btn-ghost">{tr(lang, "تسجيل الدخول", "Login")}</Link>
              </div>
            </div>

            <div className="relative overflow-hidden rounded-2xl border border-metal-200 bg-black/5 min-h-[260px] md:min-h-[340px]">
              <Image
                src="/images/start-now.jpg"
                alt="Start investing"
                fill
                className="object-cover object-center"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-black/20 via-transparent to-transparent" />
            </div>
          </div>
        </div>
        </Reveal>
      </section>
    </div>
  );
}