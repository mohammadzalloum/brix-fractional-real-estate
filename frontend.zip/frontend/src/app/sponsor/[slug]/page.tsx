import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { RiskNote } from "@/components/marketing/RiskNote";
import Link from "next/link";

export const metadata = { title: "Sponsor | Brix" };

export default function SponsorPage({ params }: { params: { slug: string } }) {
  const name = params.slug.replace(/-/g, " ");

  return (
    <div>
      <PageHero
        eyebrow="Sponsor"
        title={`Sponsor: ${name}`}
        subtitle="قالب صفحة لعرض معلومات الراعي/الشركة: نظرة عامة، خبرة، استراتيجية، وملخص فرص متاحة."
        ctaHref="/marketplace"
        ctaLabel="استعرض الفرص"
        secondaryHref="/due-diligence-process"
        secondaryLabel="منهجية التدقيق"
        imageSrc="/images/hero.jpg"
      />

      <Section title="نبذة" subtitle="استبدل هذا المحتوى ببيانات حقيقية من قاعدة البيانات لاحقًا.">
        <div className="grid gap-4 md:grid-cols-3">
          <div className="surface p-6">
            <div className="text-sm text-metal-500">التخصص</div>
            <div className="mt-1 font-extrabold">Multifamily / Commercial</div>
          </div>
          <div className="surface p-6">
            <div className="text-sm text-metal-500">المنطقة</div>
            <div className="mt-1 font-extrabold">US / Global (Demo)</div>
          </div>
          <div className="surface p-6">
            <div className="text-sm text-metal-500">سنوات الخبرة</div>
            <div className="mt-1 font-extrabold">—</div>
          </div>
        </div>

        <div className="mt-8 card p-6">
          <div className="text-lg font-extrabold tracking-tight">الفرص المرتبطة</div>
          <p className="mt-2 text-sm text-metal-600 leading-relaxed">
            يمكنك لاحقًا عرض قائمة فرص مرتبطة بهذا الراعي (من API/DB).
          </p>
          <div className="mt-4 flex flex-wrap gap-3">
            <Link href="/marketplace" className="btn btn-primary">Marketplace</Link>
            <Link href="/contact-us" className="btn btn-ghost">Contact</Link>
          </div>
        </div>
      </Section>

      <RiskNote />
    </div>
  );
}
