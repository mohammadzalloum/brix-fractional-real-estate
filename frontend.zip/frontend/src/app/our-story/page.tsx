import { PageHero } from "@/components/marketing/PageHero";
import { Section } from "@/components/marketing/Section";
import { RiskNote } from "@/components/marketing/RiskNote";
import { ShieldCheck, Sparkles, Users } from "lucide-react";

export const metadata = { title: "قصتنا | Brix" };

export default function OurStoryPage() {
  return (
    <div>
      <PageHero
        eyebrow="Company"
        title="قصة Brix"
        subtitle="بناء منصة تُبسّط الوصول للاستثمار العقاري المُجزّأ مع حوكمة واضحة وتوزيعات قابلة للتتبع."
        ctaHref="/contact-us"
        ctaLabel="تواصل معنا"
        secondaryHref="/docs"
        secondaryLabel="التوثيق"
        imageSrc="/images/hero.jpg"
      />

      <Section title="قيمنا" subtitle="نركّز على الشفافية، الجودة، ووضوح الحوكمة.">
        <div className="grid gap-4 md:grid-cols-3">
          <div className="surface p-6">
            <div className="badge badge-gold w-fit"><ShieldCheck className="h-4 w-4" /><span className="font-semibold">شفافية</span></div>
            <p className="mt-3 text-sm text-metal-600 leading-relaxed">بيانات وإفصاحات واضحة قبل القرار.</p>
          </div>
          <div className="surface p-6">
            <div className="badge badge-blue w-fit"><Sparkles className="h-4 w-4" /><span className="font-semibold">بساطة</span></div>
            <p className="mt-3 text-sm text-metal-600 leading-relaxed">تجربة استخدام مرتبة، تركز على الأساسيات.</p>
          </div>
          <div className="surface p-6">
            <div className="badge w-fit"><Users className="h-4 w-4" /><span className="font-semibold">مجتمع</span></div>
            <p className="mt-3 text-sm text-metal-600 leading-relaxed">حوكمة DAO تشجع المشاركة والمساءلة.</p>
          </div>
        </div>
      </Section>

      <RiskNote />
    </div>
  );
}
