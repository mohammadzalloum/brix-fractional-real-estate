"use client";

import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

export type Lang = "ar" | "en";

type I18nCtx = {
  lang: Lang;
  setLang: (l: Lang) => void;
  toggleLang: () => void;
  /** Quick inline translation helper: tr("AR", "EN") */
  tr: (ar: string, en: string) => string;
};

const I18nContext = createContext<I18nCtx | null>(null);

function readInitialLang(): Lang {
  if (typeof document === "undefined") return "ar";

  // 1) cookie (so it matches server rendering after refresh)
  const m = document.cookie.match(/(?:^|; )lang=(ar|en)(?:;|$)/);
  if (m?.[1] === "en") return "en";
  if (m?.[1] === "ar") return "ar";

  // 2) localStorage fallback
  const ls = window.localStorage.getItem("lang");
  return ls === "en" ? "en" : "ar";
}

function persistLang(l: Lang) {
  try {
    window.localStorage.setItem("lang", l);
  } catch {}

  // 1 year
  document.cookie = `lang=${l}; Path=/; Max-Age=31536000; SameSite=Lax`;

  // Keep document direction in sync (also used by globals.css)
  document.documentElement.lang = l;
  document.documentElement.dir = l === "ar" ? "rtl" : "ltr";
}

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [lang, setLangState] = useState<Lang>(() => readInitialLang());

  useEffect(() => {
    persistLang(lang);
  }, [lang]);

  const setLang = (l: Lang) => {
    // IMPORTANT: persist cookie/dir synchronously BEFORE refresh.
    // Otherwise server components/layout will still read the old cookie
    // until a full page reload.
    if (typeof document !== "undefined") {
      persistLang(l);
    }
    setLangState(l);
    // Refresh server components so they can read the updated lang cookie.
    router.refresh();
  };

  const toggleLang = () => setLang(lang === "ar" ? "en" : "ar");

  const tr = useMemo(() => {
    return (ar: string, en: string) => (lang === "ar" ? ar : en);
  }, [lang]);

  const value = useMemo<I18nCtx>(() => ({ lang, setLang, toggleLang, tr }), [lang, tr]);

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used within <I18nProvider>.");
  return ctx;
}
