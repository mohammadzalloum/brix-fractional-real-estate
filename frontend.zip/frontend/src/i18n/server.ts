import { cookies } from "next/headers";
import type { Lang } from "./I18nProvider";

export function getLang(): Lang {
  const c = cookies().get("lang")?.value;
  return c === "en" ? "en" : "ar";
}

/** Server-side inline translation helper: tr(lang, "AR", "EN") */
export function tr(lang: Lang, ar: string, en: string) {
  return lang === "ar" ? ar : en;
}
