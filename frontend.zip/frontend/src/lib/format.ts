import { formatUnits } from "viem";

export function formatToken(amount: bigint | undefined, decimals: number, max = 4) {
  if (amount === undefined) return "—";
  const s = formatUnits(amount, decimals);
  // تقطيع بسيط دون تعقيد (للاستخدام في الواجهة)
  const [a, b] = s.split(".");
  if (!b) return a;
  return `${a}.${b.slice(0, max)}`;
}
