import "server-only";

import { PROPERTIES } from "@/config/properties";
import { listStoredProperties, getStoredPropertyById, PropertyRecord } from "./store";

export async function getAllProperties(): Promise<(((typeof PROPERTIES)[number]) | PropertyRecord)[]> {
  const stored = await listStoredProperties();
  const seedIds = new Set(PROPERTIES.map((p) => p.id));
  const merged = [...PROPERTIES, ...stored.filter((p) => !seedIds.has(p.id))];
  return merged;
}

export async function getAnyPropertyById(id: string) {
  const seed = PROPERTIES.find((p) => p.id === id);
  if (seed) return seed;
  return await getStoredPropertyById(id);
}
