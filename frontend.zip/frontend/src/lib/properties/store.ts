import "server-only";

import { promises as fs } from "fs";
import path from "path";
import crypto from "crypto";
import { PropertyInstance } from "@/config/properties";

export type PropertyRecord = PropertyInstance & {
  // Extra (optional) info collected from the Manager form.
  heroImage?: string;
  gallery?: string[];
  propertyType?: string;
  sponsorName?: string;
  sponsorSlug?: string;

  // Simple financial/ops stats (optional)
  priceUsd?: number;
  minInvestmentUsd?: number;
  targetYieldPct?: number;
  occupancyPct?: number;
  yearBuilt?: number;
  units?: number;

  highlights?: string[];
  risks?: string[];

  createdAt: string;
  createdByUserId: string;
};

const DATA_PATH = path.join(process.cwd(), "data", "properties.json");

async function readJsonFile(): Promise<PropertyRecord[]> {
  try {
    const raw = await fs.readFile(DATA_PATH, "utf-8");
    const data = JSON.parse(raw);
    if (!Array.isArray(data)) return [];
    return data as PropertyRecord[];
  } catch {
    return [];
  }
}

async function writeJsonFile(properties: PropertyRecord[]) {
  await fs.mkdir(path.dirname(DATA_PATH), { recursive: true });
  await fs.writeFile(DATA_PATH, JSON.stringify(properties, null, 2), "utf-8");
}

export async function listStoredProperties(): Promise<PropertyRecord[]> {
  return await readJsonFile();
}

export async function getStoredPropertyById(id: string): Promise<PropertyRecord | null> {
  const all = await readJsonFile();
  return all.find((p) => p.id === id) ?? null;
}

function slugify(input: string) {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 64);
}

export function isEvmAddress(x: unknown): x is `0x${string}` {
  return typeof x === "string" && /^0x[a-fA-F0-9]{40}$/.test(x);
}

export type CreatePropertyInput = Omit<PropertyRecord, "id" | "createdAt" | "createdByUserId"> & {
  id?: string;
};

export async function createStoredProperty(input: CreatePropertyInput, createdByUserId: string) {
  const all = await readJsonFile();

  const base = slugify(input.title || "property");
  const suffix = crypto.randomBytes(3).toString("hex"); // 6 chars
  const id = input.id && input.id.trim() ? slugify(input.id) : `${base}-${suffix}`;

  if (all.some((p) => p.id === id)) {
    throw new Error("Property id already exists.");
  }

  const now = new Date().toISOString();

  const record: PropertyRecord = {
    id,
    title: input.title,
    location: input.location,
    description: input.description,
    coverImage: input.coverImage,
    tags: input.tags ?? [],

    token: input.token,
    vault: input.vault,
    distributor: input.distributor,
    governor: input.governor,
    timelock: input.timelock,

    rentTokenSymbol: input.rentTokenSymbol,
    docsUrl: input.docsUrl,

    // extras
    heroImage: input.heroImage,
    gallery: input.gallery ?? [],
    propertyType: input.propertyType,
    sponsorName: input.sponsorName,
    sponsorSlug: input.sponsorSlug,
    priceUsd: input.priceUsd,
    minInvestmentUsd: input.minInvestmentUsd,
    targetYieldPct: input.targetYieldPct,
    occupancyPct: input.occupancyPct,
    yearBuilt: input.yearBuilt,
    units: input.units,
    highlights: input.highlights ?? [],
    risks: input.risks ?? [],

    createdAt: now,
    createdByUserId,
  };

  all.unshift(record);
  await writeJsonFile(all);

  return record;
}
