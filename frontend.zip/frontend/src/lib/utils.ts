import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: any[]) {
  return twMerge(clsx(inputs));
}

export function shortAddr(addr?: string, n = 4) {
  if (!addr) return "";
  return `${addr.slice(0, 2 + n)}…${addr.slice(-n)}`;
}

export function formatNumber(n?: number | bigint, decimals = 2) {
  if (n === undefined) return "—";
  const num = typeof n === "bigint" ? Number(n) : n;
  if (!Number.isFinite(num)) return "—";
  return new Intl.NumberFormat("ar", { maximumFractionDigits: decimals }).format(num);
}

export function formatUsd(n?: number) {
  if (n === undefined) return "—";
  return new Intl.NumberFormat("ar", { style: "currency", currency: "USD" }).format(n);
}
