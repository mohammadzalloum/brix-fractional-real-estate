import "server-only";

import { promises as fs } from "fs";
import path from "path";
import crypto from "crypto";

export type UserRole = "investor" | "manager" | "admin";

export type UserRecord = {
  id: string;
  email: string;
  passwordHash: string; // scrypt format
  role: UserRole;
  createdAt: string;

  // Optional profile fields (used by the web app; the smart contracts only need wallet address)
  wallet?: `0x${string}`;
  fullName?: string;
  country?: string;
  phone?: string;
  requestManager?: boolean; // user asked to become manager (needs admin approval)
};

const DATA_PATH = path.join(process.cwd(), "data", "users.json");

async function readJsonFile(): Promise<UserRecord[]> {
  try {
    const raw = await fs.readFile(DATA_PATH, "utf-8");
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as UserRecord[]) : [];
  } catch {
    return [];
  }
}

async function writeJsonFile(users: UserRecord[]) {
  await fs.mkdir(path.dirname(DATA_PATH), { recursive: true });
  await fs.writeFile(DATA_PATH, JSON.stringify(users, null, 2) + "\n", "utf-8");
}

function normalizeEmail(email: string) {
  return email.trim().toLowerCase();
}

// ---- Password hashing (scrypt) ----
const SCRYPT_N = 16384;
const SCRYPT_R = 8;
const SCRYPT_P = 1;
const KEYLEN = 32;

// stored as: scrypt$N$r$p$saltB64$hashB64
export function hashPassword(password: string) {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(password, salt, KEYLEN, { N: SCRYPT_N, r: SCRYPT_R, p: SCRYPT_P });
  return `scrypt$${SCRYPT_N}$${SCRYPT_R}$${SCRYPT_P}$${salt.toString("base64")}$${key.toString("base64")}`;
}

export function verifyPassword(password: string, stored: string) {
  try {
    const parts = stored.split("$");
    if (parts.length !== 6) return false;
    const [_tag, N, r, p, saltB64, hashB64] = parts;
    const salt = Buffer.from(saltB64, "base64");
    const expected = Buffer.from(hashB64, "base64");
    const derived = crypto.scryptSync(password, salt, expected.length, {
      N: Number(N),
      r: Number(r),
      p: Number(p),
    });
    return crypto.timingSafeEqual(expected, derived);
  } catch {
    return false;
  }
}

// ---- Queries ----
export async function getUsers() {
  return await readJsonFile();
}

export async function getUserByEmail(email: string) {
  const users = await readJsonFile();
  const e = normalizeEmail(email);
  return users.find((u) => normalizeEmail(u.email) === e) ?? null;
}

export async function getUserById(id: string) {
  const users = await readJsonFile();
  return users.find((u) => u.id === id) ?? null;
}

// ---- Mutations ----
export async function createUser(params: {
  email: string;
  password: string;
  role?: UserRole;
  wallet?: string;
  fullName?: string;
  country?: string;
  phone?: string;
  requestManager?: boolean;
}) {
  const users = await readJsonFile();
  const email = normalizeEmail(params.email);

  if (!email || !email.includes("@")) throw new Error("INVALID_EMAIL");
  if (!params.password || params.password.length < 8) throw new Error("WEAK_PASSWORD");
  if (users.some((u) => normalizeEmail(u.email) === email)) throw new Error("EMAIL_EXISTS");

  const wallet = params.wallet?.trim();
  if (wallet && !/^0x[a-fA-F0-9]{40}$/.test(wallet)) throw new Error("INVALID_WALLET");

  const role: UserRole = params.role ?? "investor";

  const rec: UserRecord = {
    id: crypto.randomUUID(),
    email,
    passwordHash: hashPassword(params.password),
    role,
    createdAt: new Date().toISOString(),
    wallet: (wallet as `0x${string}` | undefined) ?? undefined,
    fullName: params.fullName?.trim() || undefined,
    country: params.country?.trim() || undefined,
    phone: params.phone?.trim() || undefined,
    requestManager: params.requestManager ?? false,
  };

  users.push(rec);
  await writeJsonFile(users);
  return rec;
}

export async function updateUserRole(userId: string, role: UserRole) {
  const users = await readJsonFile();
  const idx = users.findIndex((u) => u.id === userId);
  if (idx === -1) throw new Error("NOT_FOUND");
  users[idx] = { ...users[idx], role };
  await writeJsonFile(users);
  return users[idx];
}

export async function linkWallet(userId: string, wallet: string) {
  const users = await readJsonFile();
  const idx = users.findIndex((u) => u.id === userId);
  if (idx === -1) throw new Error("NOT_FOUND");
  if (!/^0x[a-fA-F0-9]{40}$/.test(wallet)) throw new Error("INVALID_WALLET");
  users[idx] = { ...users[idx], wallet: wallet as `0x${string}` };
  await writeJsonFile(users);
  return users[idx];
}

// ---- Seeding (Admin/Manager demo accounts) ----
export async function ensureSeedAccounts() {
  const adminEmail = process.env.ADMIN_EMAIL?.trim();
  const adminPassword = process.env.ADMIN_PASSWORD?.trim();

  const managerEmail = process.env.MANAGER_EMAIL?.trim();
  const managerPassword = process.env.MANAGER_PASSWORD?.trim();

  // Default demo seeding in dev
  const dev = process.env.NODE_ENV !== "production";
  const seedAdmin =
    dev && (!adminEmail || !adminPassword)
      ? { email: "admin@demo.local", password: "Admin12345!", role: "admin" as const }
      : adminEmail && adminPassword
        ? { email: adminEmail, password: adminPassword, role: "admin" as const }
        : null;

  const seedManager =
    dev && (!managerEmail || !managerPassword)
      ? { email: "manager@demo.local", password: "Manager12345!", role: "manager" as const }
      : managerEmail && managerPassword
        ? { email: managerEmail, password: managerPassword, role: "manager" as const }
        : null;

  const users = await readJsonFile();
  let changed = false;

  async function upsert(seed: { email: string; password: string; role: UserRole }) {
    const email = normalizeEmail(seed.email);
    const existing = users.find((u) => normalizeEmail(u.email) === email);
    if (!existing) {
      users.push({
        id: crypto.randomUUID(),
        email,
        passwordHash: hashPassword(seed.password),
        role: seed.role,
        createdAt: new Date().toISOString(),
        wallet: undefined,
        fullName: seed.role === "admin" ? "Brix Admin" : seed.role === "manager" ? "Brix Manager" : undefined,
        country: undefined,
        phone: undefined,
        requestManager: false,
      });
      changed = true;
    } else if (existing.role !== seed.role) {
      existing.role = seed.role;
      changed = true;
    }
  }

  if (seedAdmin) await upsert(seedAdmin);
  if (seedManager) await upsert(seedManager);

  if (changed) await writeJsonFile(users);

  return {
    admin: seedAdmin ? { email: normalizeEmail(seedAdmin.email), role: "admin" as const } : null,
    manager: seedManager ? { email: normalizeEmail(seedManager.email), role: "manager" as const } : null,
    note: dev && seedAdmin ? "Dev seed is enabled. Change AUTH_SECRET/ADMIN_PASSWORD before production." : null,
  };
}
