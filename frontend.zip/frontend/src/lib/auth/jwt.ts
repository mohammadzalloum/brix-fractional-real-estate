import "server-only";

import crypto from "crypto";

export type SessionPayload = {
  sub: string; // user id
  email: string;
  role: "investor" | "manager" | "admin";
  exp: number; // unix seconds
};

function b64url(input: Buffer | string) {
  const buf = Buffer.isBuffer(input) ? input : Buffer.from(input);
  return buf.toString("base64").replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}

function b64urlJson(obj: any) {
  return b64url(JSON.stringify(obj));
}

function signHS256(data: string, secret: string) {
  const sig = crypto.createHmac("sha256", secret).update(data).digest();
  return b64url(sig);
}

export function createSessionToken(payload: Omit<SessionPayload, "exp">, ttlSeconds = 60 * 60 * 24 * 7) {
  const secret = process.env.AUTH_SECRET || "dev-secret";
  const header = { alg: "HS256", typ: "JWT" };
  const exp = Math.floor(Date.now() / 1000) + ttlSeconds;

  const full: SessionPayload = { ...payload, exp };
  const h = b64urlJson(header);
  const p = b64urlJson(full);
  const data = `${h}.${p}`;
  const s = signHS256(data, secret);
  return `${data}.${s}`;
}

export function verifySessionToken(token: string): SessionPayload | null {
  try {
    const secret = process.env.AUTH_SECRET || "dev-secret";
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const data = `${parts[0]}.${parts[1]}`;
    const sig = signHS256(data, secret);

    // timing-safe compare
    const a = Buffer.from(parts[2]);
    const b = Buffer.from(sig);
    if (a.length !== b.length) return null;
    if (!crypto.timingSafeEqual(a, b)) return null;

    const payloadJson = Buffer.from(parts[1].replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf-8");
    const payload = JSON.parse(payloadJson) as SessionPayload;

    if (!payload?.sub || !payload?.exp) return null;
    if (Math.floor(Date.now() / 1000) > payload.exp) return null;

    return payload;
  } catch {
    return null;
  }
}
