import "server-only";

import { cookies } from "next/headers";
import { verifySessionToken } from "./jwt";
import { getUserById } from "./store";

export const SESSION_COOKIE = "dao_session";

export async function getSessionUser() {
  const c = cookies().get(SESSION_COOKIE)?.value;
  if (!c) return null;
  const payload = verifySessionToken(c);
  if (!payload) return null;
  const user = await getUserById(payload.sub);
  if (!user) return null;
  return {
    id: user.id,
    email: user.email,
    role: user.role,
    wallet: user.wallet ?? null,
    fullName: user.fullName ?? null,
  };
}
