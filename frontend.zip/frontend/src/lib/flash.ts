"use client";

export type FlashPayload = {
  message: string;
  variant?: "success" | "error" | "info";
};

export const FLASH_KEY = "brix_flash_v1";

export function setFlash(payload: FlashPayload) {
  try {
    sessionStorage.setItem(FLASH_KEY, JSON.stringify(payload));
  } catch {}
}

export function popFlash(): FlashPayload | null {
  try {
    const raw = sessionStorage.getItem(FLASH_KEY);
    if (!raw) return null;
    sessionStorage.removeItem(FLASH_KEY);
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed.message === "string") return parsed as FlashPayload;
    return null;
  } catch {
    return null;
  }
}
