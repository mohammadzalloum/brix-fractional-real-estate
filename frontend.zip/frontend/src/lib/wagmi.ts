"use client";

import { http, createConfig } from "wagmi";
import { CHAIN, RPC_URL } from "@/config/properties";

export const wagmiConfig = createConfig({
  chains: [CHAIN],
  transports: {
    [CHAIN.id]: http(RPC_URL ?? CHAIN.rpcUrls.default.http[0]),
  },
  ssr: true,
});
