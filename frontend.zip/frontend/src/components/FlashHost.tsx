"use client";

import { useEffect, useMemo, useState } from "react";
import { usePathname, useSearchParams } from "next/navigation";
import { CheckCircle2, AlertCircle, Info, X } from "lucide-react";
import { popFlash, type FlashPayload } from "@/lib/flash";

function Icon({ variant }: { variant: FlashPayload["variant"] }) {
  if (variant === "success") return <CheckCircle2 className="h-5 w-5 text-emerald-600" />;
  if (variant === "error") return <AlertCircle className="h-5 w-5 text-rose-600" />;
  return <Info className="h-5 w-5 text-brand-600" />;
}

export function FlashHost() {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const key = useMemo(() => pathname + "?" + (searchParams?.toString() ?? ""), [pathname, searchParams]);
  const [flash, setFlash] = useState<FlashPayload | null>(null);

  useEffect(() => {
    const f = popFlash();
    if (!f) return;
    setFlash(f);
    const t = window.setTimeout(() => setFlash(null), 2600);
    return () => window.clearTimeout(t);
  }, [key]);

  if (!flash) return null;

  return (
    <div className="fixed top-5 right-5 z-[100] w-[min(420px,calc(100vw-40px))]">
      <div className="surface border border-metal-200/70 shadow-[0_24px_60px_rgba(2,6,23,.18)]">
        <div className="flex items-start gap-3 p-4">
          <Icon variant={flash.variant ?? "info"} />
          <div className="flex-1">
            <div className="text-sm font-semibold text-metal-900">Brix</div>
            <div className="mt-0.5 text-sm text-metal-700">{flash.message}</div>
          </div>
          <button className="btn btn-ghost !px-2" aria-label="close" onClick={() => setFlash(null)}>
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
