import Link from "next/link";
import { getLang, tr } from "@/i18n/server";

const columns = (lang: "ar" | "en") => [
  {
    title: tr(lang, "الشركة", "COMPANY"),
    links: [
      { href: "/our-story", label: tr(lang, "قصتنا", "Our Story") },
      { href: "/rm-communities", label: tr(lang, "مجتمعات Brix", "Brix Communities") },
      { href: "/contact-us", label: tr(lang, "تواصل معنا", "Contact Us") },
      { href: "/careers", label: tr(lang, "وظائف", "Careers") },
      { href: "/newsworthy", label: tr(lang, "الأخبار", "Newsworthy") },
    ],
  },
  {
    title: tr(lang, "استثمر", "INVEST"),
    links: [
      { href: "/due-diligence-process", label: tr(lang, "إجراءات التدقيق", "Due Diligence Process") },
      { href: "/how-it-works", label: tr(lang, "كيف يعمل", "How it Works") },
      { href: "/investment-options", label: tr(lang, "خيارات الاستثمار", "Investment Options") },
      { href: "/investment-opportunities", label: tr(lang, "عرض الفرص", "View Investments") },
    ],
  },
  {
    title: tr(lang, "تعلّم", "LEARN"),
    links: [
      { href: "/knowledge-center", label: tr(lang, "مركز المعرفة", "Knowledge Center") },
      { href: "/why-commercial-real-estate", label: tr(lang, "لماذا العقار التجاري؟", "Why Commercial Real Estate") },
      { href: "/why-reits", label: tr(lang, "لماذا REITs؟", "Why REITs") },
      { href: "/real-estate-investing-with-your-ira", label: tr(lang, "استثمار التقاعد", "Retirement Investing") },
      { href: "/knowledge-center/faqs", label: tr(lang, "الأسئلة الشائعة", "FAQs") },
      { href: "/knowledge-center/glossary", label: tr(lang, "المصطلحات", "Glossary") },
    ],
  },
  {
    title: tr(lang, "التمويل", "FINANCING"),
    links: [
      { href: "/our-jv-equity-process", label: tr(lang, "آلية التمويل", "Our JV Equity Process") },
      { href: "/apply-for-equity-capital", label: tr(lang, "طلب تمويل", "Apply for Equity Capital") },
    ],
  },
];

export function Footer() {
  const lang = getLang();
  const cols = columns(lang);
  return (
    <footer className="mt-24 bg-black text-white">
      <div className="container py-12">
        <div className="grid gap-10 lg:grid-cols-[1fr_1fr_1fr_1fr_auto]">
          {cols.map((c) => (
            <div key={c.title}>
              <div className="text-xs font-extrabold tracking-[0.22em] text-white/70">
                {c.title}
              </div>
              <div className="mt-6 grid gap-3">
                {c.links.map((l) => (
                  <Link
                    key={l.href}
                    href={l.href}
                    className="text-sm text-white/90 hover:text-white underline-offset-4 hover:underline"
                  >
                    {l.label}
                  </Link>
                ))}
              </div>
            </div>
          ))}

          <div className="lg:justify-self-end">
            <div className="text-xs font-extrabold tracking-[0.22em] text-white/70">{tr(lang, "الدعم", "SUPPORT")}</div>
            <div className="mt-6 text-sm text-white/90">
              <div className="text-white/70">{tr(lang, "البريد", "Email")}</div>
              <a className="hover:underline" href="mailto:support@brix.local">support@brix.local</a>
              <div className="mt-4 text-white/70">{tr(lang, "البوابة", "Portal")}</div>
              <Link className="hover:underline" href="/contact-us">{tr(lang, "أرسل رسالة", "Send a message")}</Link>
            </div>
          </div>
        </div>

        <div className="mt-10 border-t border-white/10 pt-10">
          <div className="text-xs text-white/70 leading-relaxed">© {new Date().getFullYear()} Brix. {tr(lang, "جميع الحقوق محفوظة", "All rights reserved")}.</div>

          <div className="mt-6 space-y-4 text-[12px] leading-relaxed text-white/60">
            {lang === "ar" ? (
              <>
                <p>
                  تنبيه مهم: هذه المنصة واجهة تعليمية/تجريبية (MVP). أي معلومات معروضة لا تُعد نصيحة مالية أو
                  دعوة للاستثمار. الاستثمار في العقارات قد يكون عالي المخاطر وغير سائل، وقد يؤدي إلى خسارة جزء
                  أو كامل رأس المال.
                </p>
                <p>
                  يتم تحصيل الإيجار خارج السلسلة بواسطة مدير العقار، ثم يتم إيداع صافي الإيجار في الخزنة (Vault).
                  التوزيعات للمستثمرين تتم عبر آلية Claim من خلال عقود ذكية، وقد تتطلب رسوم شبكة وقد تتأثر بتعطل
                  مزود RPC أو تغيّر الشبكة.
                </p>
                <p>
                  قبل أي قرار: راجع الشروط <Link href="/legal/terms" className="text-white/70 hover:text-white underline">Terms</Link> و
                  سياسة الخصوصية <Link href="/legal/privacy" className="text-white/70 hover:text-white underline">Privacy</Link> و
                  بيان المخاطر <Link href="/legal/risk" className="text-white/70 hover:text-white underline">Risk</Link>.
                </p>
              </>
            ) : (
              <>
                <p>
                  Important: This is a learning/demo portal (MVP). Nothing shown here is financial advice or a solicitation to invest.
                  Real estate investing can be illiquid and high risk, and you may lose some or all of your capital.
                </p>
                <p>
                  Rent is collected off-chain by the property manager, then net rent is deposited into the Vault. Investor distributions
                  are claimed via smart contracts (Claim), may require network fees, and may be affected by RPC outages or chain changes.
                </p>
                <p>
                  Before any decision, review <Link href="/legal/terms" className="text-white/70 hover:text-white underline">Terms</Link>,
                  <Link href="/legal/privacy" className="text-white/70 hover:text-white underline"> Privacy</Link>, and
                  <Link href="/legal/risk" className="text-white/70 hover:text-white underline"> Risk</Link>.
                </p>
              </>
            )}
          </div>
        </div>
      </div>
    </footer>
  );
}
