"use client";

import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const demo = [
  { m: "يناير", v: 100 },
  { m: "فبراير", v: 104 },
  { m: "مارس", v: 103 },
  { m: "أبريل", v: 109 },
  { m: "مايو", v: 111 },
  { m: "يونيو", v: 115 },
];

export function PriceChart() {
  return (
    <div className="h-56 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={demo}>
          <XAxis dataKey="m" />
          <YAxis />
          <Tooltip />
          <Line type="monotone" dataKey="v" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
