"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { useAccount } from "wagmi";
import { Shield, Wrench, User, LogOut, Link2 } from "lucide-react";
import { shortAddr } from "@/lib/utils";
import { setFlash } from "@/lib/flash";
import { AUTH_EVENT, emitAuthChanged } from "@/lib/auth/client";
import { useI18n } from "@/i18n/I18nProvider";

type Me =
  | {
      id: string;
      email: string;
      role: "investor" | "manager" | "admin";
      wallet?: string | null;
      fullName?: string | null;
    }
  | null;

function roleLabel(role: "investor" | "manager" | "admin", tr: (ar: string, en: string) => string) {
  return role === "admin"
    ? tr("مدير النظام", "Admin")
    : role === "manager"
      ? tr("مدير", "Manager")
      : tr("مستثمر", "Investor");
}

function avatarInitial(nameOrEmail: string) {
  const s = (nameOrEmail || "?").trim();
  const ch = s[0] || "?";
  return ch.toUpperCase();
}

export function UserMenu() {
  const router = useRouter();
  const { tr } = useI18n();
  const [me, setMe] = useState<Me>(null);
  const [loading, setLoading] = useState(true);
  const { address, isConnected } = useAccount();

  async function refresh() {
    setLoading(true);
    try {
      const r = await fetch("/api/auth/me", { cache: "no-store" });
      const j = await r.json().catch(() => ({}));
      setMe(j.user ?? null);
    } catch {
      setMe(null);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refresh();
    const onChange = () => refresh();
    window.addEventListener(AUTH_EVENT, onChange);
    return () => window.removeEventListener(AUTH_EVENT, onChange);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const displayName = useMemo(() => {
    if (!me) return "";
    return (me.fullName && me.fullName.trim()) ? me.fullName.trim() : me.email;
  }, [me]);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    setFlash({ message: tr("تم تسجيل الخروج ✅", "Logged out ✅"), variant: "success" });
    emitAuthChanged();
    await refresh();
    router.push("/");
    router.refresh();
  }

  async function linkWallet() {
    if (!isConnected || !address) {
      setFlash({ message: tr("يرجى ربط المحفظة من زر ربط المحفظة أولاً.", "Please connect your wallet first."), variant: "warning" });
      return;
    }
    const r = await fetch("/api/account/link-wallet", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ wallet: address }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.ok) {
      setFlash({ message: tr("لم نتمكن من ربط المحفظة.", "Couldn't link the wallet."), variant: "error" });
      return;
    }
    setFlash({ message: tr("تم ربط المحفظة ✅", "Wallet linked ✅"), variant: "success" });
    emitAuthChanged();
    await refresh();
    router.refresh();
  }

  if (loading) return <div className="badge">…</div>;

  if (!me) {
    return (
      <div className="flex items-center gap-2">
        <Link href="/auth/login" className="btn btn-ghost hidden sm:inline-flex">
          {tr("تسجيل الدخول", "Login")}
        </Link>
        <Link href="/auth/register" className="btn btn-primary hidden sm:inline-flex">
          {tr("إنشاء حساب", "Create account")}
        </Link>
      </div>
    );
  }

  const RoleIcon = me.role === "admin" ? Shield : me.role === "manager" ? Wrench : User;

  return (
    <div className="relative group">
      {/* Trigger */}
      <button
        type="button"
        className="inline-flex items-center gap-2 rounded-full px-3 py-2 text-sm text-metal-800 hover:bg-metal-50 transition focus:outline-none"
      >
        <span className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-brand-600 text-white font-semibold shadow-soft">
          {avatarInitial(displayName)}
        </span>

        <div className="hidden sm:flex flex-col items-start leading-tight">
          <span className="font-semibold text-metal-900 max-w-[160px] truncate">{displayName}</span>
          <span className="text-[11px] text-metal-500 flex items-center gap-1">
            <RoleIcon className="h-3.5 w-3.5" />
            {roleLabel(me.role, tr)}
          </span>
        </div>
      </button>

      {/* Hover-open menu */}
      <div
        className={[
          "absolute top-full z-50 pt-3",
          "right-0",
          "opacity-0 invisible translate-y-1",
          "transition duration-150",
          "group-hover:opacity-100 group-hover:visible group-hover:translate-y-0",
          "group-focus-within:opacity-100 group-focus-within:visible group-focus-within:translate-y-0",
        ].join(" ")}
      >
        <div className="w-[320px] rounded-3xl border border-metal-200 bg-white shadow-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-metal-100">
            <div className="flex items-center gap-3">
              <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-brand-600 text-white font-semibold">
                {avatarInitial(displayName)}
              </span>
              <div className="min-w-0">
                <div className="font-semibold text-metal-900 truncate">{displayName}</div>
                <div className="text-xs text-metal-500 truncate">{me.email}</div>
              </div>
            </div>

            <div className="mt-3 grid gap-1 text-xs text-metal-600">
              <div>{tr("الدور", "Role")}: <span className="font-semibold text-metal-900">{roleLabel(me.role, tr)}</span></div>
              <div>
                {tr("المحفظة", "Wallet")}: <span className="font-semibold text-metal-900">{me.wallet ? shortAddr(me.wallet) : tr("غير مرتبطة", "Not linked")}</span>
              </div>
            </div>
          </div>

          <div className="p-2">
            <Link href="/me" className="menu-item">
              <User className="h-4 w-4" />
              {tr("الصفحة الشخصية", "Profile")}
            </Link>

            {(me.role === "manager" || me.role === "admin") ? (
              <>
                <Link href="/manager" className="menu-item">
                  <Wrench className="h-4 w-4" />
                  {tr("لوحة المانيجر", "Manager dashboard")}
                </Link>
                <Link href="/manager/properties/new" className="menu-item">
                  <Wrench className="h-4 w-4" />
                  {tr("إضافة عقار", "Add property")}
                </Link>
              </>
            ) : null}

            {me.role === "admin" ? (
              <Link href="/admin" className="menu-item">
                <Shield className="h-4 w-4" />
                {tr("لوحة الإدارة", "Admin panel")}
              </Link>
            ) : null}

            <button type="button" onClick={linkWallet} className="menu-item w-full text-left">
              <Link2 className="h-4 w-4" />
              {tr("ربط محفظة MetaMask (حفظ العنوان)", "Link MetaMask wallet (save address)")}
            </button>

            <div className="my-1 h-px bg-metal-100" />

            <button type="button" onClick={logout} className="menu-item w-full text-left">
              <LogOut className="h-4 w-4" />
              {tr("تسجيل الخروج", "Logout")}
            </button>
          </div>
        </div>
      </div>

      <style jsx global>{`
        .menu-item {
          display: flex;
          align-items: center;
          gap: 10px;
          border-radius: 18px;
          padding: 12px 14px;
          font-size: 14px;
          color: rgb(17 24 39);
          transition: background 120ms ease, color 120ms ease;
        }
        .menu-item:hover {
          background: rgb(243 244 246);
          color: rgb(30 64 175);
        }
      `}</style>
    </div>
  );
}
