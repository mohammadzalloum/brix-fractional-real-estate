"use client";

import * as React from "react";
import * as DropdownMenu from "@radix-ui/react-dropdown-menu";
import { cn } from "@/lib/utils";

export const Dropdown = DropdownMenu.Root;
export const DropdownTrigger = DropdownMenu.Trigger;

export function DropdownContent({ className, ...props }: DropdownMenu.DropdownMenuContentProps) {
  return (
    <DropdownMenu.Portal>
      <DropdownMenu.Content
        className={cn("z-50 min-w-[220px] rounded-2xl border border-gray-200 bg-white p-2 shadow-soft", className)}
        sideOffset={8}
        {...props}
      />
    </DropdownMenu.Portal>
  );
}

export function DropdownItem({ className, ...props }: DropdownMenu.DropdownMenuItemProps) {
  return (
    <DropdownMenu.Item
      className={cn("cursor-pointer select-none rounded-xl px-3 py-2 text-sm text-gray-800 outline-none hover:bg-gray-50", className)}
      {...props}
    />
  );
}
