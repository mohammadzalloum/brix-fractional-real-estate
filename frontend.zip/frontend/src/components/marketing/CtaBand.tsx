import Link from "next/link";

export function CtaBand({
  title,
  subtitle,
  primaryHref = "/auth/register",
  primaryLabel = "إنشاء حساب",
  secondaryHref = "/marketplace",
  secondaryLabel = "استعرض الفرص",
}: {
  title: string;
  subtitle: string;
  primaryHref?: string;
  primaryLabel?: string;
  secondaryHref?: string;
  secondaryLabel?: string;
}) {
  return (
    <section className="container py-12">
      <div className="surface p-6 md:p-8">
        <div className="grid gap-6 md:grid-cols-[1fr_auto] items-center">
          <div>
            <h3 className="text-xl md:text-2xl font-extrabold tracking-tight text-metal-900">{title}</h3>
            <p className="mt-2 text-metal-600 leading-relaxed">{subtitle}</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Link href={primaryHref} className="btn btn-primary">{primaryLabel}</Link>
            <Link href={secondaryHref} className="btn btn-ghost">{secondaryLabel}</Link>
          </div>
        </div>
      </div>
    </section>
  );
}
