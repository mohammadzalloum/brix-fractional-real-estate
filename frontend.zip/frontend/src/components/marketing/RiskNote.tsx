import Link from "next/link";

export function RiskNote() {
  return (
    <section className="container pb-12">
      <div className="rounded-3xl border border-metal-200/70 bg-white/70 backdrop-blur p-5 text-sm text-metal-600">
        <div className="font-semibold text-metal-900">إفصاحات مهمة</div>
        <p className="mt-2 leading-relaxed">
          الاستثمار في العقار قد ينطوي على مخاطر، وقد تكون الأصول غير سائلة، وقد تخسر جزءًا أو كامل رأس المال.
          هذه الواجهة لأغراض تعليمية/تجريبية ولا تشكّل عرضًا أو توصية.
        </p>
        <div className="mt-3">
          <Link className="underline underline-offset-4" href="/legal/risk">اقرأ إفصاح المخاطر</Link>
        </div>
      </div>
    </section>
  );
}
