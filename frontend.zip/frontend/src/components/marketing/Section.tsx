import React from "react";
import type { ReactNode } from "react";

export function Section({
  title,
  subtitle,
  children,
  className = "",
}: {
  title?: string;
  subtitle?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={`container py-12 ${className}`}>
      {(title || subtitle) && (
        <div className="max-w-3xl">
          {title && <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-metal-900">{title}</h2>}
          {subtitle && <p className="mt-3 text-metal-600 leading-relaxed">{subtitle}</p>}
        </div>
      )}
      <div className={title || subtitle ? "mt-8" : ""}>{children}</div>
    </section>
  );
}