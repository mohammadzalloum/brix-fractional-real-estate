import Link from "next/link";
import Image from "next/image";
import React from "react";

export function PageHero({
  eyebrow,
  title,
  subtitle,
  ctaHref,
  ctaLabel,
  secondaryHref,
  secondaryLabel,
  imageSrc = "/images/hero.jpg",
}: {
  eyebrow?: string;
  title: string;
  subtitle: string;
  ctaHref?: string;
  ctaLabel?: string;
  secondaryHref?: string;
  secondaryLabel?: string;
  imageSrc?: string;
}) {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 bg-brix-radial" />
      <div className="absolute inset-0 opacity-40 bg-grid" />
      <div className="container relative py-12 md:py-12">
        <div className="grid gap-10 lg:grid-cols-[1.05fr_.95fr] items-center">
          <div className="max-w-2xl">
            {eyebrow && <div className="badge badge-gold w-fit">{eyebrow}</div>}
            <h1 className="mt-4 text-4xl md:text-5xl font-extrabold tracking-tight text-metal-900">
              {title}
            </h1>
            <p className="mt-4 text-metal-600 leading-relaxed">{subtitle}</p>

            {(ctaHref || secondaryHref) && (
              <div className="mt-8 flex flex-wrap items-center gap-3">
                {ctaHref && (
                  <Link href={ctaHref} className="btn btn-primary">
                    {ctaLabel ?? "ابدأ الآن"}
                  </Link>
                )}
                {secondaryHref && (
                  <Link href={secondaryHref} className="btn btn-ghost">
                    {secondaryLabel ?? "اعرف المزيد"}
                  </Link>
                )}
              </div>
            )}

            <div className="mt-6 text-xs text-metal-500">
              ملاحظة: هذه واجهة استثمار تجريبية لعرض الفكرة—لا تمثل نصيحة مالية أو دعوة للاستثمار.
            </div>
          </div>

          <div className="relative">
            <div className="absolute -inset-8 rounded-[2.5rem] bg-gold-sheen opacity-70 pointer-events-none" />
            <div className="card overflow-hidden">
              <div className="relative h-[300px] md:h-[380px]">
                <Image src={imageSrc} alt="" fill className="object-cover" priority />
              </div>
              <div className="p-5">
                <div className="flex items-center gap-2">
                  <span className="badge badge-blue">Brix</span>
                  <span className="badge">DAO • Rent • Governance</span>
                </div>
                <div className="mt-3 text-sm text-metal-600">
                  استكشف فرصًا مختارة، تابع المقترحات، واطلب حصتك من الإيجار عبر تجربة منظمة.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
