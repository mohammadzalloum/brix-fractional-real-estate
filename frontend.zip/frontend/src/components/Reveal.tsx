"use client";

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

import type { ReactNode } from "react";

type RevealProps = {
  children: ReactNode;
  className?: string;
  delayMs?: number;
  once?: boolean;
  /**
   * 0..1 — how much of the element should be visible before revealing
   */
  threshold?: number;
};

export function Reveal({
  children,
  className,
  delayMs = 0,
  once = true,
  threshold = 0.18,
}: RevealProps) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const obs = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            setVisible(true);
            if (once) obs.unobserve(e.target);
          } else if (!once) {
            setVisible(false);
          }
        }
      },
      { threshold }
    );

    obs.observe(el);
    return () => obs.disconnect();
  }, [once, threshold]);

  return (
    <div
      ref={ref}
      style={{ transitionDelay: `${delayMs}ms` }}
      className={cn(
        "transition-all duration-700 ease-out will-change-transform",
        visible
          ? "opacity-100 translate-y-0 blur-0 scale-100"
          : "opacity-0 translate-y-6 blur-[2px] scale-[0.985]",
        className
      )}
    >
      {children}
    </div>
  );
}
