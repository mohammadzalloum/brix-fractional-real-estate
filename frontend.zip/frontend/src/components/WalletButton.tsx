"use client";

import { useAccount, useConnect, useDisconnect } from "wagmi";
import { injected } from "wagmi/connectors";
import { shortAddr } from "@/lib/utils";
import { Wallet, LogOut } from "lucide-react";

export function WalletButton() {
  const { address, isConnected } = useAccount();
  const { connect, isPending } = useConnect();
  const { disconnect } = useDisconnect();

  if (!isConnected) {
    return (
      <button
        className="btn btn-primary"
        onClick={() => connect({ connector: injected() })}
        disabled={isPending}
      >
        <Wallet className="h-4 w-4" />
        ربط المحفظة
      </button>
    );
  }

  return (
    <button className="btn btn-ghost" onClick={() => disconnect()}>
      <LogOut className="h-4 w-4" />
      {shortAddr(address)}
    </button>
  );
}
