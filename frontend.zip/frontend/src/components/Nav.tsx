"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Brand } from "./Brand";
import { UserMenu } from "./UserMenu";
import { WalletButton } from "./WalletButton";
import { Dialog, DialogTrigger, DialogContent } from "@/components/ui/Dialog";
import { Menu, ChevronDown } from "lucide-react";
import { AUTH_EVENT } from "@/lib/auth/client";
import { useI18n } from "@/i18n/I18nProvider";

const topLinks = (tr: (ar: string, en: string) => string) => [
  { href: "/marketplace", label: tr("السوق", "Marketplace") },
  { href: "/rm-1031-exchange", label: tr("تبادل 1031", "1031 Exchange") },
  { href: "/rm-communities", label: tr("المجتمعات", "Communities") },
];

const reitsLinks = (tr: (ar: string, en: string) => string) => [
  { href: "/investment-options/the-income-reit", label: tr("REIT الدخل", "Income REIT") },
  { href: "/investment-options/the-apartment-growth-reit", label: tr("REIT النمو", "Growth REIT") },
  { href: "/knowledge-center/why-reits", label: tr("لماذا REITs؟", "Why REITs") },
];

const researchLinks = (tr: (ar: string, en: string) => string) => [
  { href: "/due-diligence-process", label: tr("إجراءات التدقيق", "Due Diligence Process") },
  { href: "/investment-options", label: tr("خيارات الاستثمار", "Investment Options") },
  { href: "/rm-1031-exchange", label: tr("تبادل 1031", "1031 Exchange") },
  { href: "/private-credit-investments", label: tr("الائتمان الخاص", "Private Credit") },
  { href: "/knowledge-center/why-commercial-real-estate", label: tr("لماذا العقار التجاري؟", "Why Commercial Real Estate") },
  { href: "/knowledge-center", label: tr("مركز المعرفة", "Knowledge Center") },
];

const moreLinks = (tr: (ar: string, en: string) => string) => [
  { href: "/how-it-works", label: tr("كيف يعمل", "How it Works") },
  { href: "/our-story", label: tr("قصتنا", "Our Story") },
  { href: "/careers", label: tr("وظائف", "Careers") },
  { href: "/contact-us", label: tr("تواصل معنا", "Contact") },
  { href: "/financing/jv-equity", label: tr("التمويل", "Financing") },
  { href: "/apply-for-equity-capital", label: tr("طلب تمويل", "Apply for Equity") },
  { href: "/real-estate-investing-with-your-ira", label: tr("استثمار التقاعد", "Retirement Investing") },
  { href: "/knowledge-center/faqs", label: tr("الأسئلة الشائعة", "FAQs") },
  { href: "/knowledge-center/glossary", label: tr("المصطلحات", "Glossary") },
  { href: "/newsworthy", label: tr("الأخبار", "Newsworthy") },
];



type Me = { id: string; email: string; role: "investor" | "manager" | "admin"; wallet?: string | null } | null;

function HoverMenu({
  label,
  links,
  align = "left",
}: {
  label: string;
  links: { href: string; label: string }[];
  align?: "left" | "right";
}) {
  return (
    <div className="relative group">
      {/* Use button so it can be focused with keyboard too */}
      <button
        type="button"
        className="inline-flex items-center gap-1 text-[11px] font-semibold uppercase tracking-[0.26em] text-metal-600 hover:text-metal-900"
      >
        {label}
        <ChevronDown className="h-4 w-4 text-brand-600 transition-transform duration-200 group-hover:rotate-180 group-focus-within:rotate-180" />
      </button>

      {/* Hover-open (no click) */}
      <div
        className={[
          "absolute top-full z-50 pt-3",
          align === "right" ? "right-0" : "left-0",
          "opacity-0 invisible translate-y-1",
          "transition duration-150",
          "group-hover:opacity-100 group-hover:visible group-hover:translate-y-0",
          "group-focus-within:opacity-100 group-focus-within:visible group-focus-within:translate-y-0",
        ].join(" ")}
      >
        <div className="w-[320px] rounded-3xl border border-metal-200 bg-white shadow-xl overflow-hidden">
          <div className="px-5 py-4">
            <div className="text-[11px] font-semibold uppercase tracking-[0.26em] text-brand-700">
              {label}
            </div>
          </div>

          <div className="px-2 pb-2">
            {links.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className="block rounded-2xl px-4 py-3 text-sm text-metal-800 hover:bg-metal-50 hover:text-brand-700 transition"
              >
                {l.label}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export function Nav() {
  const { lang, toggleLang, tr } = useI18n();
  const [me, setMe] = useState<Me>(null);
  const [meLoading, setMeLoading] = useState(true);

  // Align dropdowns with the trigger depending on page direction.
  // RTL (Arabic): anchor to the right edge. LTR (English): anchor to the left edge.
  const menuAlign: "left" | "right" = lang === "ar" ? "right" : "left";

  const TOP = topLinks(tr);
  const REITS = reitsLinks(tr);
  const RESEARCH = researchLinks(tr);
  const MORE = moreLinks(tr);

  useEffect(() => {
    let alive = true;

    const load = async () => {
      try {
        const r = await fetch("/api/auth/me", { cache: "no-store" });
        const j = await r.json();
        if (!alive) return;
        setMe(j.user ?? null);
      } catch {
        if (!alive) return;
        setMe(null);
      } finally {
        if (!alive) return;
        setMeLoading(false);
      }
    };

    load();

    const onAuth = () => load();
    if (typeof window !== "undefined") window.addEventListener(AUTH_EVENT, onAuth);

    return () => {
      alive = false;
      if (typeof window !== "undefined") window.removeEventListener(AUTH_EVENT, onAuth);
    };
  }, []);

  return (
    <header className="sticky top-0 z-40 border-b border-metal-200/70 bg-white/70 backdrop-blur">
      <div className="h-[2px] w-full bg-gradient-to-r from-brand-600 via-brand-400 to-gold-500" />

      <div className="container flex items-center justify-between py-4">
        <div className="shrink-0">
          <Brand />
        </div>

        {/* Desktop */}
        <nav className="hidden md:flex items-center gap-7 text-sm text-metal-600">
          {TOP.map((i) => (
            <Link key={i.href} href={i.href} className="hover:text-metal-900">
              {i.label}
            </Link>
          ))}

          <HoverMenu label={tr("REITs", "REITs")} links={REITS} align={menuAlign} />
          <HoverMenu label={tr("الأبحاث", "Research")} links={RESEARCH} align={menuAlign} />
          <HoverMenu label={tr("المزيد", "More")} links={MORE} align={menuAlign} />
        </nav>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={toggleLang}
            className="btn btn-ghost hidden sm:inline-flex"
            aria-label="language"
            title={lang === "ar" ? "English" : "العربية"}
          >
            {lang === "ar" ? "EN" : "عربي"}
          </button>

          <UserMenu />
          {!meLoading && me ? <WalletButton /> : null}

          {/* Mobile menu */}
          <div className="md:hidden">
            <Dialog>
              <DialogTrigger asChild>
                <button className="btn btn-ghost" aria-label="menu">
                  <Menu className="h-5 w-5" />
                </button>
              </DialogTrigger>

              <DialogContent className="max-w-md">
                <div className="text-lg font-semibold">{tr("القائمة", "Menu")}</div>

                <button
                  type="button"
                  onClick={toggleLang}
                  className="btn btn-ghost mt-3 w-full"
                >
                  {lang === "ar" ? "Switch to English" : "التبديل للعربية"}
                </button>

                <div className="mt-4 grid gap-2">
                  <div className="text-xs font-semibold text-metal-500">{tr("الأساسي", "Main")}</div>
                  {TOP.map((i) => (
                    <Link key={i.href} href={i.href} className="btn btn-ghost justify-start">
                      {i.label}
                    </Link>
                  ))}

                  <div className="mt-3 text-xs font-semibold text-metal-500">{tr("REITs", "REITs")}</div>
                  {REITS.map((i) => (
                    <Link key={i.href} href={i.href} className="btn btn-ghost justify-start">
                      {i.label}
                    </Link>
                  ))}

                  <div className="mt-3 text-xs font-semibold text-metal-500">{tr("الأبحاث", "Research")}</div>
                  {RESEARCH.map((i) => (
                    <Link key={i.href} href={i.href} className="btn btn-ghost justify-start">
                      {i.label}
                    </Link>
                  ))}

                  <div className="mt-3 text-xs font-semibold text-metal-500">{tr("المزيد", "More")}</div>
                  {MORE.map((i) => (
                    <Link key={i.href} href={i.href} className="btn btn-ghost justify-start">
                      {i.label}
                    </Link>
                  ))}

                  {!meLoading && !me ? (
                    <>
                      <Link href="/auth/login" className="btn btn-ghost mt-2">
                        {tr("تسجيل الدخول", "Login")}
                      </Link>
                      <Link href="/auth/register" className="btn btn-primary">
                        {tr("إنشاء حساب", "Create account")}
                      </Link>
                    </>
                  ) : null}

                  {!meLoading && me ? (
                    <>
                      <Link href="/me" className="btn btn-ghost mt-2">
                        {tr("الصفحة الشخصية", "Profile")}
                      </Link>
                      {(me.role === "manager" || me.role === "admin") ? (
                        <Link href="/manager" className="btn btn-ghost">
                          {tr("لوحة المانيجر", "Manager dashboard")}
                        </Link>
                      ) : null}
                      {me.role === "admin" ? (
                        <Link href="/admin" className="btn btn-secondary">
                          {tr("لوحة الإدارة", "Admin panel")}
                        </Link>
                      ) : null}
                      <form
                        action="/api/auth/logout"
                        method="post"
                        onSubmit={(e) => {
                          e.preventDefault();
                          fetch("/api/auth/logout", { method: "POST" }).then(() => {
                            import("@/lib/flash").then(({ setFlash }) => {
                              setFlash({ message: tr("تم تسجيل الخروج ✅", "Logged out ✅"), variant: "success" });
                            });
                            import("@/lib/auth/client").then(({ emitAuthChanged }) => emitAuthChanged());
                            window.location.href = "/";
                          });
                        }}
                      >
                        <button type="submit" className="btn btn-ghost">
                          {tr("تسجيل الخروج", "Logout")}
                        </button>
                      </form>
                    </>
                  ) : null}
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>
    </header>
  );
}
