import Link from "next/link";
import Image from "next/image";

export function Brand() {
  return (
    <Link href="/" className="group inline-flex">
      <div className="flex flex-col items-center justify-center gap-1">
        <div className="relative h-10 w-10 transition group-hover:scale-[1.03]">
          <Image
            src="/brand/brix-logo.png"
            alt="Brix logo"
            fill
            className="object-contain"
            priority
          />
        </div>

        <div className="text-center leading-none">
          <div
            className="text-[15px] font-extrabold text-metal-900"
            style={{ letterSpacing: "0.34em" }}
          >
            BRIX
          </div>
        </div>
      </div>
    </Link>
  );
}
