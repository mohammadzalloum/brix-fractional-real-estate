import { mainnet, sepolia, polygon, arbitrum, localhost } from "viem/chains";
// Auto-generated deployments (local dev). This file may not exist until you run Truffle migrations.
// It is safe: the import is wrapped in try/catch.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let localDeployment: any = null;
try {
  // @ts-ignore
  localDeployment = require("./deployments/local.json");
} catch {
  localDeployment = null;
}

export const APP_NAME = "Brix • Real Estate DAO";
export const SUPPORT_EMAIL = "support@example.com";

// ✅ اختر الشبكة المستهدفة
export const CHAIN = localDeployment?.chainId === 1337 ? localhost : sepolia;

// ✅ ضع RPC موثوق (يفضل خاص). إن تُرك فارغاً سيعتمد viem على default RPC لبعض الشبكات.
export const RPC_URL: string | undefined = process.env.NEXT_PUBLIC_RPC_URL;

// نموذج تعريف عقار (Instance) المنشور على البلوك تشين
export type PropertyInstance = {
  id: string;
  title: string;
  location: string;
  coverImage: string; // static path under /public
  tags: string[];
  description: string;

  token: `0x${string}`;
  vault: `0x${string}`;
  distributor: `0x${string}`;
  governor: `0x${string}`;
  timelock: `0x${string}`;

  rentTokenSymbol: string; // USDT/USDC…
  docsUrl?: string; // رابط مستندات/ملف قانوني خارجياً
};

// ✳️ أضف عقاراتك هنا (عناوين مثال placeholder)
const BASE_PROPERTIES: PropertyInstance[] = [
  {
    id: "amman-residence",
    title: "شقق عمان • مجمع سكني",
    location: "الأردن • عمّان",
    coverImage: "/images/property-1.jpg",
    tags: ["سكني", "عوائد إيجار", "DAO"],
    description:
      "مجمع شقق سكنية في عمّان بهدف توزيع الإيجارات عبر RentDistributor، مع حوكمة on-chain لإدارة المصاريف والقرارات.",

    // استبدل هذه العناوين بعناوين العقود المنشورة على شبكتك
    token: "0x0000000000000000000000000000000000000001",
    vault: "0x0000000000000000000000000000000000000002",
    distributor: "0x0000000000000000000000000000000000000003",
    governor: "0x0000000000000000000000000000000000000004",
    timelock: "0x0000000000000000000000000000000000000005",

    rentTokenSymbol: "ETH",
    docsUrl: "https://example.com/docs/amman-residence",
  },
  {
    id: "aqaba-apartments",
    title: "شقق العقبة • قرب البحر",
    location: "الأردن • العقبة",
    coverImage: "/images/property-2.jpg",
    tags: ["سياحي", "إيجار موسمي", "DAO"],
    description:
      "شقق استثمارية في العقبة بعوائد موسمية. المانيجر يودِع صافي الإيجار في الـVault ليصبح قابلًا للمطالبة من المستثمرين.",

    token: "0x0000000000000000000000000000000000000011",
    vault: "0x0000000000000000000000000000000000000012",
    distributor: "0x0000000000000000000000000000000000000013",
    governor: "0x0000000000000000000000000000000000000014",
    timelock: "0x0000000000000000000000000000000000000015",

    rentTokenSymbol: "ETH",
    docsUrl: "https://example.com/docs/aqaba-apartments",
  },
  {
    id: "deadsea-villa",
    title: "فيلا البحر الميت • إطلالة بانورامية",
    location: "الأردن • البحر الميت",
    coverImage: "/images/property-3.jpg",
    tags: ["فاخر", "إيجار قصير", "DAO"],
    description:
      "عقار فاخر في البحر الميت. الحوكمة تتحكم بنسبة الاحتياطي (Reserve BPS) والمصاريف عبر Timelock لضمان الشفافية.",

    token: "0x0000000000000000000000000000000000000021",
    vault: "0x0000000000000000000000000000000000000022",
    distributor: "0x0000000000000000000000000000000000000023",
    governor: "0x0000000000000000000000000000000000000024",
    timelock: "0x0000000000000000000000000000000000000025",

    rentTokenSymbol: "ETH",
    docsUrl: "https://example.com/docs/deadsea-villa",
  },
];

// إذا تم إنشاء deployments/local.json بواسطة Truffle migrations، سيتم استبدال العناوين تلقائيًا هنا.
export const PROPERTIES: PropertyInstance[] =
  localDeployment?.properties?.length
    ? BASE_PROPERTIES.map((p) => {
        const ov = localDeployment.properties.find((x: any) => x.id === p.id);
        return ov ? { ...p, ...ov } : p;
      })
    : BASE_PROPERTIES;


// روابط سريعة
export const SOCIAL = {
  x: "https://x.com/",
  telegram: "https://t.me/",
  github: "https://github.com/",
};