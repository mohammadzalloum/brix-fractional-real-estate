This folder is auto-populated by Truffle migrations (local.json).
