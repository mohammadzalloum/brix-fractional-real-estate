# Real Estate DAO Portal (MVP)

بوابة ويب احترافية لعرض/إدارة استثمار عقاري مُجزّأ (Fractional Real Estate DAO) بناءً على العقود التي شاركتها:
- FractionToken (ERC20Votes)
- PropertyVault
- RentDistributor
- PropertyGovernor + Timelock

> ⚠️ ملاحظة مهمة: الموقع يقرأ ويتفاعل مع عقود تم نشرها مسبقًا.  
> عقد `PropertyFactory` في الكود الذي أرسلته يحتوي على مقاطع ناقصة/غير مكتملة (تعريف arrays)، لذا هذا المشروع يعتمد على **عناوين عقود منشورة** لكل عقار.

## المتطلبات
- Node.js 18+ (يفضل 20+)
- محفظة متصفح (MetaMask أو غيرها)

## التشغيل
1) انسخ المشروع:
```bash
npm install
npm run dev
```

2) إعداد الشبكة والعقارات:
- افتح: `src/config/properties.ts`
- عدّل:
  - `RPC_URL` (يفضل RPC خاص)
  - `chain` (مثل mainnet أو sepolia أو أي شبكة EVM)
  - أضف عقاراتك (token/vault/distributor/governor/timelock)

3) صفحات مهمة
- `/` الصفحة الرئيسية
- `/properties` قائمة العقارات
- `/properties/[id]` تفاصيل عقار (ملكية، توزيعات، حوكمة، خزنة)
- `/dashboard` لوحة المستثمر
- `/admin` لوحة مدير العقار/المنصّة (ميزات تظهر حسب الأدوار)
- `/docs` شرح كيف يعمل النظام + توثيق

## ملاحظة أمنية
- لا ترسل أموال/تواقيع إلا بعد التحقق من العناوين والشبكة.
- الموقع لا يجمع الإيجار من الواقع، فقط يتعامل مع الإيداع في `Vault` و المطالبات عبر `RentDistributor`.


## حل مشاكل npm على ويندوز (ESLint/Next)
إذا ظهر خطأ ERESOLVE بسبب ESLint:
- احذف `node_modules` و `package-lock.json`
- ثم أعد التثبيت:
```bash
npm install
npm run dev
```

بديل سريع (أقل تفضيلاً):
```bash
npm install --legacy-peer-deps
```


## إعدادات البيئة (RPC)
أنشئ ملف `.env.local` وضع:
```bash
NEXT_PUBLIC_RPC_URL=https://....
```


## إعادة تثبيت نظيفة (Windows)
```powershell
Remove-Item -Recurse -Force .\node_modules -ErrorAction SilentlyContinue
Remove-Item -Force .\package-lock.json -ErrorAction SilentlyContinue
npm install
npm run dev
```


## تسجيل الدخول والحسابات (MVP)
المشروع يدعم حسابات داخلية للموقع (Email/Password) لتقسيم الأدوار داخل الواجهة:
- Investor (مستخدم عادي)
- Manager (مدير العقار/المسؤول عن إيداع الإيجار)
- Admin (إدارة المستخدمين والأدوار)

> ملاحظة: صلاحيات العقود على البلوك تشين منفصلة (Roles داخل العقود) وتحتاج محفظة تملك ROLE المناسب.

### إعدادات البيئة
انسخ `.env.example` إلى `.env.local` وعدّل:
- `AUTH_SECRET` (مهم جداً)
- `ADMIN_EMAIL` و `ADMIN_PASSWORD` (اختياري للتوليد)
- `MANAGER_EMAIL` و `MANAGER_PASSWORD` (اختياري)

### التخزين
لأغراض الـ MVP يتم حفظ المستخدمين في `data/users.json`.
للنشر الإنتاجي يُفضّل نقلها لقاعدة بيانات (Postgres/SQLite) بدل الكتابة على الملفات.


## ملاحظات الإصلاح (v7)
- تم إصلاح خطأ Next.js: `metadata is defined multiple times` عبر توحيد `export const metadata` في `src/app/layout.tsx`.
- إذا ظهر خطأ كاش webpack على ويندوز: احذف مجلد `.next` ثم شغّل `npm run dev` مرة أخرى.

### أوامر ويندوز
```powershell
Remove-Item -Recurse -Force .\.next -ErrorAction SilentlyContinue
npm install
npm run dev
```


## إصلاح (v8)
- تم إصلاح Runtime Error: `Nav is not defined` عبر إضافة import صحيح لـ Nav و Footer في `src/app/layout.tsx`.


## Real Estate IA (RealtyMogul-inspired)
هذه النسخة تنظّم بنية الصفحات والتنقل بشكل مشابه عالي المستوى (Marketplace / REITs / Research / More) بدون نسخ نصوص أو تصميم حرفي.
المحتوى هنا أصلي وتجريبي ويمكن استبداله لاحقًا.


## Demo Accounts (الأدمن والمانيجر)
أسرع طريقة للتجربة هي الدخول بحسابات جاهزة:

**Login page:** `/auth/login`

**Admin**
- Email: `admin@demo.local`
- Password: `Admin12345!`

**Manager**
- Email: `manager@demo.local`
- Password: `Manager12345!`


## Nav Hover Menus
- تم تعديل القوائم (RESEARCH / MORE / REITS) لتفتح عند تمرير الماوس (hover) مثل المثال.


## Truffle (Deploy Local)
النشر المحلي أصبح داخل مجلد منفصل:
`../truffle`

بعد تنفيذ النشر من هناك، سيتم إنشاء ملف العناوين تلقائياً هنا:
`src/config/deployments/local.json`

### أوامر سريعة
1) شغّل السلسلة (Ganache) من داخل `brix/truffle`:
```bash
cd ../truffle
npm install
npm run chain
```

2) انشر العقود (سيكتب local.json تلقائياً داخل مشروع الويب):
```bash
npm run migrate
```

3) شغّل الواجهة من داخل `brix/web`:
```bash
cd ../web
npm install
npm run dev
```

> ملاحظة: إذا أردت النشر على شبكة عامة (Sepolia مثلاً)، سنحتاج إعداد Provider (HDWalletProvider) ومفتاح خاص / mnemonic بشكل آمن داخل `.env`.
